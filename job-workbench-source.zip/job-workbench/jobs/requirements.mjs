// Extract only explicitly titled passages. This does not infer eligibility.
const headings={required:['지원자격','자격요건','필수자격','필수조건','응시자격'],preferred:['우대사항','우대조건'],stages:['전형절차','채용절차','전형방법'],documents:['제출서류','지원서류','구비서류']};
const stops=['근무조건','모집분야','접수기간','급여','문의','기타','지원방법','유의사항','회사소개'];
export function extractRequirements(value){
  const result={},evidence={};let current=null;
  for(const original of String(value||'').slice(0,24000).replaceAll('\r','').replace(/(\[[^\]\n]{1,30}\])/g,'\n$1\n').split('\n')){
    const line=original.trim();if(!line)continue;
    const clean=line.replace(/^[■□●•◆▶※-]\s*/,'').replace(/^\d{1,2}[.)]\s*/,'');
    const bracket=clean.match(/^\[([^\]]{1,30})\]\s*[:：]?\s*(.*)$/),colon=clean.match(/^([^:：]{1,30})[:：]\s*(.*)$/);
    const candidate=(bracket?.[1]||colon?.[1]||clean).replace(/\s/g,''),entry=Object.entries(headings).find(([,labels])=>labels.includes(candidate));
    if(entry){current=entry[0];result[current]||=[];evidence[current]||={heading:bracket?.[1]||colon?.[1]||clean,quotes:[],truncated:false};const rest=bracket?.[2]||colon?.[2];if(rest)add(rest);continue;}
    if(bracket||stops.includes(candidate)){current=null;continue;}
    if(current)add(line);
  }
  function add(line){if(result[current].length>=8){evidence[current].truncated=true;return;}const passage=line.replace(/^[-•]\s*/,'');if(!passage)return;result[current].push(passage.slice(0,500));evidence[current].quotes.push(passage.slice(0,500));if(passage.length>500)evidence[current].truncated=true;}
  for(const key of Object.keys(result))if(!result[key].length){delete result[key];delete evidence[key];}
  return {fields:result,evidence,method:'원문의 명시적 표제 아래 텍스트만 추출 · 이미지/OCR/자격 판정 미수행'};
}

export function compareProfile(record,profile){
  const sources={roles:[record.title,...record.roles],locations:record.locations,career:record.career,employment:record.employment,education:[record.education,...record.required],credentials:[...record.required,...record.preferred,record.detailText||''],exclude:[record.company,record.title,...record.roles,...record.locations,...record.employment]};
  return Object.entries(sources).flatMap(([field,source])=>String(profile[field]||'').split(/[,，\n]/).map(t=>t.trim()).filter(Boolean).slice(0,12).map(term=>{
    const escaped=term.normalize('NFKC').replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),ascii=/^[a-z\d]+$/i.test(term),pattern=new RegExp((ascii?'(?<![a-z\\d])':'')+escaped+(ascii?'(?![a-z\\d])':''),'i');
    const quote=source.find(value=>value&&pattern.test(String(value).normalize('NFKC')));
    return {field,term,status:quote?(field==='exclude'?'제외 문구 발견':'같은 문구 있음'):'원문 추가 확인',quote:quote?String(quote).normalize('NFKC').slice(Math.max(0,String(quote).normalize('NFKC').search(pattern)-60),String(quote).normalize('NFKC').search(pattern)+term.length+160):null};
  }));
}
