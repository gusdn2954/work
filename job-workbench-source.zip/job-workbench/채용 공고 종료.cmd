@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0jobs\stop-jobs.ps1"
if errorlevel 1 pause
