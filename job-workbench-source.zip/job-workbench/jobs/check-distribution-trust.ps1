param([Parameter(Mandatory=$true)][string]$Installer,[Parameter(Mandatory=$true)][string]$Payload)
$ErrorActionPreference='Stop'
# 읽기 전용 검사. 인증서를 생성/설치하거나 보안 설정을 변경하지 않는다.
$payloadRoot=(Resolve-Path -LiteralPath $Payload).Path
$targets=@((Resolve-Path -LiteralPath $Installer).Path)
foreach($file in @('jobs/runtime/node.exe','jobs/start-jobs.ps1','jobs/stop-jobs.ps1','jobs/windows-ocr.ps1')){$targets+=Join-Path $payloadRoot $file}
$inventory=@(foreach($target in $targets){$signature=Get-AuthenticodeSignature -LiteralPath $target;[pscustomobject]@{file=[IO.Path]::GetFileName($target);signatureStatus=[string]$signature.Status}})
$missing=@($inventory|Where-Object signatureStatus -NE 'Valid')
[pscustomobject]@{
  checkedAt=[DateTime]::UtcNow.ToString('o')
  signingPrerequisiteSatisfied=($missing.Count -eq 0)
  smartAppControlDeviceTested=$false
  result=$(if($missing.Count){'정식 배포 보류: 신뢰 가능한 서명이 없는 진입 파일이 있습니다.'}else{'서명 전제조건 통과. 스마트 앱 컨트롤이 켜진 별도 PC 검증은 추가로 필요합니다.'})
  files=$inventory
}|ConvertTo-Json -Depth 4
if($missing.Count){exit 1}
