import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {collectSaramin, searchPlan} from './saramin.mjs';
import './core.js';

const C = globalThis.JobsCore;
const SITE = JSON.parse(await fs.readFile(new URL('./settings-schema.json', import.meta.url))).sites.find(s => s.id === 'saramin');
const USER_URL = 'https://www.saramin.co.kr/zf_user/search?edu_min=8&edu_max=11&company_type=scale001%2Cscale002%2Cscale003&searchword=%ED%99%94%ED%95%99%EA%B3%B5%ED%95%99&exp_cd=1&search_optional_item=y&panel_count=y&recruitPage=1&recruitSort=reg_dt&recruitPageCount=40&inner_com_type=&company_cd=0%2C1%2C2%2C3%2C4%2C5%2C6%2C7%2C9%2C10&show_applied=&quick_apply=&except_read=&ai_head_hunting=&mainSearch=y';
const filter = (extra = {}) => ({enabled: true, keyword: '', roles: '', locations: '', career: '', employment: '', hiring: '', education: '', industry: '', companyType: '', exclude: '', nativeUrl: USER_URL, nativeNotes: '', includeUnknown: true, ...extra});

// 모의 사람인 페이지: 실제 서버가 아니라 구조만 흉내 낸 픽스처다.
const rowHtml = (id, title = '화학(공학) 연구원') => `<div class="item_recruit"><div class="area_corp"><strong class="corp_name"><a href="/c">회사${id}</a></strong></div><div class="area_job"><h2 class="job_tit"><a href="/zf_user/jobs/relay/view?rec_idx=${id}">${title}</a></h2><div class="job_condition"><span><a href="/jobs/list/domestic?loc_mcd=101000">서울</a></span><span>경력무관</span><span>대졸↑</span></div><div class="job_sector"><a>연구개발</a></div></div><div class="job_date"><span class="date">~ 10/30(금)</span></div></div>`;
const searchHtml = (total, ids) => `<html><body><div id="recruit_info"><span class="cnt_result">총 ${total}건</span></div>${ids.map(i => rowHtml(i)).join('')}</body></html>`;
const ok = html => new Response(html, {status: 200, headers: {'content-type': 'text/html'}});

function server(total, pages, {failPage, requests = []} = {}) {
  return async url => {
    const u = new URL(url); requests.push(u);
    if (u.pathname.endsWith('/search')) {
      const n = Number(u.searchParams.get('recruitPage'));
      if (n === failPage) return new Response('x', {status: 503});
      return ok(searchHtml(total, pages[n - 1] || []));
    }
    return ok('<html><body>접수기간 : 2026년 10월 1일 ~ 2026년 10월 30일</body></html>');
  };
}
const range = (a, b) => Array.from({length: b - a + 1}, (_, i) => String(a + i));
async function run(fetcher, opts = {}) {
  const runtime = await fs.mkdtemp(path.join(os.tmpdir(), 'saramin-eq-'));
  try { return await collectSaramin({filter: filter(opts.filter), runtime, runId: 'r1', fetcher, pageDelayMs: 0, detailDelayMs: 0, ...opts.args}); }
  finally { await fs.rm(runtime, {recursive: true, force: true}); }
}

test('사용자 URL의 신입·학력 범위(edu_max 11 포함)·기업형태를 그대로 읽는다', () => {
  const q = C.saraminQuery(USER_URL);
  assert.equal(q.ok, true);
  assert.deepEqual(q.params, {searchword: '화학공학', exp_cd: '1', edu_min: '8', edu_max: '11', company_type: 'scale001,scale002,scale003', company_cd: '0,1,2,3,4,5,6,7,9,10', recruitSort: 'reg_dt'});
  assert.deepEqual(q.covered, ['keyword', 'career', 'education', 'companyType']);
  const plan = searchPlan(filter());
  const sent = new URL(plan.url).searchParams;
  assert.equal(sent.get('edu_max'), '11'); assert.equal(sent.get('edu_min'), '8');
  assert.equal(sent.get('company_type'), 'scale001,scale002,scale003'); assert.equal(sent.get('recruitPageCount'), '40');
});

test('사람인 공식 HTTPS 검색 주소와 알려진 파라미터만 받는다', () => {
  for (const bad of ['http://www.saramin.co.kr/zf_user/search?searchword=a', 'https://evil.example/zf_user/search?searchword=a', 'https://user:pw@www.saramin.co.kr/zf_user/search?searchword=a', 'https://www.saramin.co.kr/zf_user/member/login?searchword=a', 'https://www.saramin.co.kr/zf_user/search?searchword=a&token=1', 'https://www.saramin.co.kr/zf_user/search?searchword=a&exp_cd=x1'])
    assert.equal(C.saraminQuery(bad).ok, false, bad);
  assert.equal(C.saraminQuery(''), null);
});

test('URL이 덮는 항목에 로컬 값이 따로 있으면 조용히 합치지 않고 충돌로 기록한다', () => {
  const plan = searchPlan(filter({career: '경력', education: '석사'}));
  assert.deepEqual(plan.conflicts.sort(), ['career', 'education']);
});

test('페이지를 순회해 총건수 안의 모든 공고를 읽고 중복은 한 번만 저장한다', async () => {
  const requests = [];
  const pages = [range(1, 40), range(41, 80), range(80, 85)]; // 80은 페이지 경계 중복
  const result = await run(server(85, pages, {requests}));
  assert.equal(result.scan.siteTotal, 85); assert.equal(result.scan.pagesRead, 3); assert.equal(result.scan.unique, 85);
  assert.equal(result.scan.duplicates, 1); assert.equal(result.scan.complete, true); assert.equal(result.scan.stopReason, null);
  assert.equal(result.records.length, 85);
  assert.equal(requests.filter(u => u.pathname.endsWith('/search')).length, 3);
  assert.ok(result.records.every(r => r.remoteMatches?.[0]?.fields.includes('education')));
}, {timeout: 60000});

test('후속 페이지가 실패하면 재시도 없이 멈추고 앞 페이지 결과를 남긴다', async () => {
  const requests = [];
  const result = await run(server(85, [range(1, 40), range(41, 80), range(81, 85)], {failPage: 2, requests}));
  assert.equal(result.scan.stopReason, 'page-failed'); assert.equal(result.scan.complete, false);
  assert.equal(result.records.length, 40); assert.match(result.scan.stopMessage, /2페이지 실패/);
  assert.equal(requests.filter(u => u.searchParams.get('recruitPage') === '2').length, 1);
}, {timeout: 60000});

test('빈 페이지와 반복 페이지에서 멈춘다', async () => {
  let r = await run(server(85, [range(1, 40), []]));
  assert.equal(r.scan.stopReason, 'empty-page'); assert.equal(r.records.length, 40);
  r = await run(server(85, [range(1, 40), range(1, 40)]));
  assert.equal(r.scan.stopReason, 'repeated-page'); assert.equal(r.records.length, 40);
}, {timeout: 60000});

test('건수 상한이 있으면 그 범위만 확인하고 사이트 총건수와 함께 제한을 알린다', async () => {
  const requests = [];
  const r = await run(server(600, [range(1, 40), range(41, 80), range(81, 120)], {requests}), {args: {limit: 45}});
  assert.equal(r.scan.siteTotal, 600); assert.equal(r.scan.stopReason, 'limit'); assert.equal(r.scan.complete, false);
  assert.equal(r.records.length, 45); assert.equal(r.scan.pagesPlanned, 2);
  assert.equal(requests.filter(u => u.pathname.endsWith('/search')).length, 2);
  assert.match(r.scan.stopMessage, /상한/);
}, {timeout: 60000});

test('수집 중지 신호가 오면 다음 페이지를 요청하지 않고 중단한다', async () => {
  const controller = new AbortController(); const requests = [];
  const base = server(85, [range(1, 40), range(41, 80), range(81, 85)], {requests});
  const fetcher = async url => { const res = await base(url); if (new URL(url).searchParams.get('recruitPage') === '1') setTimeout(() => controller.abort(), 0); return res; };
  await assert.rejects(run(fetcher, {args: {signal: controller.signal, pageDelayMs: 200}}));
  assert.equal(requests.filter(u => u.searchParams.get('recruitPage') === '2').length, 0);
}, {timeout: 60000});

test('원격 조건으로 확정된 공고는 로컬 문구 검사(화학(공학), 경력무관)로 다시 탈락하지 않는다', async () => {
  const r = await run(server(2, [['1', '2']]));
  const f = filter({keyword: '화학공학'}), rec = r.records[0];
  assert.equal(rec.title, '화학(공학) 연구원');
  assert.equal(C.matches(rec, f, SITE), true);
  // 같은 공고라도 이 URL 조건으로 확인되지 않은 기존 자료에는 로컬 검사를 그대로 적용한다.
  const old = {...rec, remoteMatches: undefined};
  assert.equal(C.matches(old, f, SITE), false);
}, {timeout: 60000});

// ---- 기업형태 선택값 ↔ 사람인 company_type 동기화 ----
const TYPES = '대기업, 매출1000대기업, 중견기업';
test('기업형태 선택값이 비어 있으면 주소의 company_type을 그대로 쓴다 (이전 저장 호환)', () => {
  const q = C.saraminQuery(USER_URL, '');
  assert.equal(q.params.company_type, 'scale001,scale002,scale003'); assert.equal(q.companyTypeSource, 'url'); assert.deepEqual(q.notes, []);
});
test('주소 없이 기업형태 선택값만 있어도 company_type이 요청에 실린다', () => {
  const plan = searchPlan(filter({nativeUrl: '', keyword: '화학공학', companyType: '중견기업, 대기업'}));
  assert.equal(new URL(plan.url).searchParams.get('company_type'), 'scale001,scale003'); assert.equal(plan.companyTypeSource, 'selection');
  assert.deepEqual(plan.local, []);
});
test('선택값이 주소와 다르면 선택값을 쓰고 조용히 넘어가지 않고 notes에 남긴다', () => {
  const plan = searchPlan(filter({companyType: '대기업'}));
  assert.equal(new URL(plan.url).searchParams.get('company_type'), 'scale001'); assert.equal(plan.notes.length, 1);
  assert.deepEqual(plan.conflicts, []);
});
test('선택값과 주소가 같으면 같은 key라 URL로 확인된 기존 공고가 그대로 유지된다', () => {
  assert.equal(C.saraminQuery(USER_URL, '').key, C.saraminQuery(USER_URL, TYPES).key);
  assert.equal(C.saraminQuery(USER_URL, '중견기업, 대기업, 매출1000대기업').key, C.saraminQuery(USER_URL, '').key);
});
test('코드를 알 수 없는 기업형태 선택값은 버리지 않고 오류로 알린다', () => {
  assert.equal(C.saraminQuery(USER_URL, '대기업, 없는형태').ok, false);
  assert.throws(() => searchPlan(filter({companyType: '없는형태'})), /기업형태/);
});
test('기업형태를 해제한(주소에서도 지운) 요청에는 company_type이 없다', () => {
  const noType = USER_URL.replace(/company_type=[^&]*&/, '');
  const plan = searchPlan(filter({nativeUrl: noType, companyType: ''}));
  assert.equal(new URL(plan.url).searchParams.has('company_type'), false); assert.equal(plan.urlCovered.includes('companyType'), false);
});
test('사람인 요청 조건이 있으면 그 조건으로 확인된 공고만 남는다(사람인 검색 결과와 같은 목록)', () => {
  const site = {id: 'saramin', fields: SITE.fields};
  const base = {company: 'a', title: '화학공학 연구원', roles: ['미확인'], locations: ['서울'], career: ['신입'], employment: ['정규직'], education: '대졸', industry: '미확인', companyType: '중소기업', sources: []};
  const f = filter({companyType: TYPES});
  const remote = C.saraminQuery(f.nativeUrl, f.companyType);
  assert.equal(C.matches({...base, remoteMatches: [{key: remote.key}]}, f, site), true);
  assert.equal(C.matches(base, f, site), false);
  assert.equal(C.matches({...base, companyType: '미확인'}, f, site), false);
  assert.equal(C.matches({...base, remoteMatches: [{key: 'company_type=scale004'}]}, f, site), false);
});

// ---- 사람인 기업형태 전체 선택지 ----
test('기업형태 선택지 14개는 모두 코드로 읽히고 이름에 저장 구분자(쉼표)가 없다', () => {
  const names = Object.values(C.sarCompanyTypes);
  assert.equal(names.length, 14);
  for (const name of names) { assert.doesNotMatch(name, /[,，]/); assert.equal(C.saraminCompanyCodes(name).codes.length, 1, name); }
  assert.deepEqual(C.saraminCompanyCodes(names.join(', ')).unknown, []);
  assert.deepEqual(C.saraminCompanyCodes('공사·공기업, 병원,의료기관').codes.includes('public'), true);
});
test('주소에만 있는 미확인 기업형태 코드는 선택값과 함께 보내고 알린다', () => {
  const url = USER_URL.replace('scale003', 'scale003%2Ckosdaq');
  const plain = C.saraminQuery(url, '');
  assert.equal(plain.ok, true); assert.equal(plain.params.company_type, 'scale001,scale002,scale003,kosdaq'); assert.equal(plain.notes.length, 1);
  const chosen = C.saraminQuery(url, '대기업, 공사/공기업');
  assert.equal(chosen.params.company_type, 'scale001,public,kosdaq');
});

test('주소 없이 화면에서 고른 검색어·신입·대졸·기업형태도 사용자 주소와 같은 요청 조건으로 보낸다', () => {
  const chosen = filter({nativeUrl: '', keyword: '화학공학', career: '신입', education: '대졸', employment: '정규직, 계약직, 인턴', companyType: '대기업, 매출1000대기업, 중견기업'});
  const plan = searchPlan(chosen), sent = new URL(plan.url).searchParams, user = new URL(USER_URL).searchParams;
  for (const key of ['searchword', 'exp_cd', 'edu_min', 'edu_max', 'company_type']) assert.equal(sent.get(key), user.get(key), key);
  assert.deepEqual(plan.urlCovered, ['keyword', 'career', 'education', 'companyType']);
  assert.deepEqual(plan.local, ['employment']);assert.deepEqual(plan.conflicts, []);
  // 같은 조건으로 확인된 공고는 검색어·경력·학력 문구가 달라도 로컬에서 다시 탈락시키지 않는다(고용형태만 로컬 검사).
  const record = {company: 'A', title: '고분자 연구', roles: [], locations: [], career: ['경력무관'], employment: ['정규직'], education: '고졸↑', industry: '', companyType: '미확인', sources: [{site: '사람인'}], remoteMatches: [{key: plan.remoteKey}]};
  assert.equal(C.matches(record, chosen, SITE), true);
  assert.equal(C.matches({...record, employment: ['아르바이트']}, chosen, SITE), false);
  assert.equal(C.matches({...record, remoteMatches: undefined}, chosen, SITE), false);
});

test('사람인 코드가 확인되지 않은 경력·학력 선택이나 여러 값은 요청에 넣지 않고 로컬 검사로 남긴다', () => {
  for (const [career, education] of [['경력무관', ''], ['신입, 경력', ''], ['', '고졸'], ['', '대졸, 석사']]) {
    const plan = searchPlan(filter({nativeUrl: '', keyword: '화학공학', career, education}));
    const sent = new URL(plan.url).searchParams;
    if (career) { assert.equal(sent.get('exp_cd'), null, career); assert.ok(plan.local.includes('career')); }
    if (education) { assert.equal(sent.get('edu_min'), null, education); assert.ok(plan.local.includes('education')); }
  }
  // 주소에 같은 조건이 있으면 주소 값이 우선한다.
  const plan = searchPlan(filter({keyword: '다른말', career: '경력', education: '대졸'}));
  assert.equal(new URL(plan.url).searchParams.get('exp_cd'), '1');assert.equal(new URL(plan.url).searchParams.get('searchword'), '화학공학');
});
