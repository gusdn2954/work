import http from 'node:http';
import net from 'node:net';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomUUID,createHash} from 'node:crypto';
import './core.js';
import {collectSaramin, searchPlan} from './saramin.mjs';
import {collectPublicSite,sitePlan,directJasoseolPlan} from './public-sites.mjs';
import {compareProfile} from './requirements.mjs';

const assets = path.dirname(fileURLToPath(import.meta.url));
const buildFiles=['server.mjs','saramin.mjs','public-sites.mjs','requirements.mjs','detail-body.mjs','browser.mjs','image-ocr.mjs','windows-ocr.ps1','dashboard.js','dashboard.html','dashboard.css','core.js','ui-fonts.js'];
const C = globalThis.JobsCore;
const now = () => new Date().toISOString();
const profileFields = ['roles','locations','career','employment','education','credentials','exclude'];
const blankProfile = () => Object.fromEntries(profileFields.map(k => [k,'']));
const blankSchedule = () => ({enabled:false,intervalMinutes:60,sites:[],nextRunAt:null,lastRunAt:null,message:'예약 수집을 켜지 않았습니다.'});
function normalizeSchedule(value){
  if(!value||typeof value.enabled!=='boolean'||!Number.isInteger(value.intervalMinutes)||value.intervalMinutes<30||value.intervalMinutes>1440||!Array.isArray(value.sites)||value.sites.length>4||value.sites.some(s=>!['catch','jasoseol','saramin','jobkorea'].includes(s)))throw fail('예약 주기는 30~1,440분, 사이트는 네 채용 사이트 안에서 선택해주세요.');
  const sites=[...new Set(value.sites)];if(value.enabled&&!sites.length)throw fail('예약 수집할 사이트를 선택해주세요.');
  return {...blankSchedule(),enabled:value.enabled,intervalMinutes:value.intervalMinutes,sites};
}
async function read(file, fallback) { try { return JSON.parse((await fs.readFile(file,'utf8')).replace(/^\uFEFF/,'')); } catch(e) { if(e.code === 'ENOENT' && fallback !== undefined) return fallback;if(e instanceof SyntaxError)throw fail(path.basename(file)+': 저장 형식을 읽지 못했습니다. 원본을 보존했습니다.',500);throw e; } }
async function atomic(file, value) {
  const tmp = file + '.' + randomUUID() + '.tmp';
  await fs.mkdir(path.dirname(file), {recursive:true});
  try { await fs.writeFile(tmp, JSON.stringify(value,null,2) + '\n'); await fs.rename(tmp,file); }
  finally { await fs.rm(tmp,{force:true}).catch(()=>{}); }
}
const fail = (message,status=400) => Object.assign(new Error(message),{status});
function normalizeProfile(value) {
  if(!value || typeof value !== 'object' || Array.isArray(value)) throw fail('내 조건을 확인해주세요.');
  const result=blankProfile();
  for(const key of profileFields) { if(typeof value[key] !== 'string' || value[key].length > 1000) throw fail('내 조건은 항목당 1,000자 이내로 입력해주세요.'); result[key]=value[key].trim(); }
  return result;
}
export function validateWorkspace(value,schema){
  if(!value||value.schemaVersion!==1||!Number.isSafeInteger(value.revision)||value.revision<0||!Array.isArray(value.collected)||!Array.isArray(value.runs))throw fail('저장 상태 형식이 올바르지 않습니다. 원본 파일을 보존했습니다.');
  normalizeProfile(value.profile);C.normalizeSettings(value.settings,schema);
  const ids=new Set();for(const row of value.collected){if(!row||typeof row.id!=='string'||ids.has(row.id)||typeof row.company!=='string'||typeof row.title!=='string'||!row.deadline||typeof row.deadline.label!=='string'||!['roles','locations','career','employment','required','preferred','stages','documents','prep'].every(k=>Array.isArray(row[k])&&row[k].every(s=>typeof s==='string'))||!Array.isArray(row.sources)||!row.sources.every(s=>s&&typeof s.site==='string'&&C.safeUrl(s.url)))throw fail('저장된 공고 형식이 올바르지 않습니다. 원본 파일을 보존했습니다.');ids.add(row.id);}
  if(value.runs.some(r=>!r||typeof r.id!=='string'||!['running','stopping','stopped','failed','completed','partial','interrupted'].includes(r.status)))throw fail('실행 기록 형식이 올바르지 않습니다. 원본 파일을 보존했습니다.');
  if(value.annotations!==undefined&&(typeof value.annotations!=='object'||!value.annotations||Array.isArray(value.annotations)||Object.values(value.annotations).some(a=>!a||!Number.isSafeInteger(a.revision)||a.revision<1||typeof a.notes!=='string'||a.notes.length>5000||!['checkedTasks','checkedDocuments'].every(k=>Array.isArray(a[k])&&a[k].every(s=>typeof s==='string')))))throw fail('준비 기록 형식이 올바르지 않습니다. 원본 파일을 보존했습니다.');
  if(value.schedule!==undefined)normalizeSchedule(value.schedule);
  if(value.notifications!==undefined&&(!Array.isArray(value.notifications)||value.notifications.some(n=>!n||typeof n.id!=='string'||typeof n.message!=='string'||typeof n.read!=='boolean')))throw fail('알림 기록 형식이 올바르지 않습니다. 원본 파일을 보존했습니다.');
  if(value.batch!==undefined&&value.batch!==null){
    const batch=value.batch,sites=new Set(schema.sites.map(s=>s.id));
    if(typeof batch.id!=='string'||!['running','stopping','stopped','completed','partial','failed','interrupted'].includes(batch.status)||!Array.isArray(batch.sites)||!batch.sites.length||batch.sites.length>4||batch.sites.some(s=>!sites.has(s))||new Set(batch.sites).size!==batch.sites.length||!Array.isArray(batch.results)||batch.results.length>batch.sites.length||batch.results.some(r=>!r||!batch.sites.includes(r.site)||!['completed','partial','failed','stopped'].includes(r.status))||new Set(batch.results.map(r=>r.site)).size!==batch.results.length||typeof batch.message!=='string')throw fail('여러 사이트 수집 기록 형식이 올바르지 않습니다. 원본 파일을 보존했습니다.');
  }
  return true;
}
export function postingIdentity(value) {
  try{
    const u=new URL(value),host=u.hostname.toLowerCase();
    if(host==='www.saramin.co.kr'&&/^\d+$/.test(u.searchParams.get('rec_idx')||''))return 'saramin:'+u.searchParams.get('rec_idx');
    for(const[domain,pattern,site]of [['www.catch.co.kr',/^\/NCS\/RecruitInfoDetails\/(\d+)\/?$/i,'catch'],['jasoseol.com',/^\/recruit\/(\d+)\/?$/,'jasoseol'],['www.jobkorea.co.kr',/^\/Recruit\/GI_Read\/(\d+)\/?$/i,'jobkorea']]){const match=u.pathname.match(pattern);if(host===domain&&match)return site+':'+match[1];}
  }catch{}return value;
}
export function duplicateCandidates(records) {
  const groups=new Map(),result={};
  const normalize=value=>String(value||'').normalize('NFKC').toLocaleLowerCase('ko').replace(/[^\p{L}\p{N}]/gu,'');
  for(const r of records){const company=normalize(r.company.replace(/㈜|\(주\)|주식회사/g,'')),title=normalize(r.title);if(company.length<2||title.length<6)continue;const key=company+'|'+title;groups.set(key,[...(groups.get(key)||[]),r.id]);}
  for(const ids of groups.values())if(ids.length>1)for(const id of ids)result[id]=ids.filter(x=>x!==id);
  return result;
}
export function mergedRecords(seed, collected) {
  const rows=structuredClone(seed);
  for(const row of collected) {
    const idx=rows.findIndex(r=>r.id===row.id || r.sources.some(a=>row.sources.some(b=>postingIdentity(a.url)===postingIdentity(b.url))));
    if(idx<0) { rows.push(structuredClone(row)); continue; }
    const previous=rows[idx];
    if(row.partial && !previous.partial) {
      previous.latestObservation={checkedAt:row.checkedAt,title:row.title,deadlineLabel:row.deadline.label,detailText:row.detailText,detailFetch:row.detailFetch,sources:row.sources,bodyImages:row.bodyImages,imageOcr:row.imageOcr};
      previous.evidenceNotes=[...(previous.evidenceNotes||[]).filter(x=>!x.startsWith('새 목록 관찰:')),`새 목록 관찰: ${row.checkedAt}. 기존 수동 확인 자격·마감은 자동 덮어쓰지 않았습니다.`];
    } else rows[idx]={...previous,...structuredClone(row),discoveredAt:previous.discoveredAt||row.discoveredAt};
  }
  return rows;
}

// 수집이 끝난 뒤 저장 공고를 사이트 검색 결과에 맞춰 정리한다.
// ① 마감일이 명시되어 이미 지난 사이트 수집 공고는 지운다(마감일이 없는 상시·채용시 공고는 유지).
// ② 이번 수집이 끝까지 성공했을 때만, 이번 검색 결과에 없는 같은 사이트의 공고(조기 마감·삭제·옛 조건 수집분)를 지운다.
//    직접 주소로 추가한 공고(manualAdd)와 사이트 수집이 아닌 수동 정리 표본은 건드리지 않는다.
// 안전장치: 목록을 끝까지 읽지 못했거나(scan.complete가 아님) 결과가 0건이거나, 같은 조건의 직전 수집보다 절반 아래로 줄었으면 ②는 하지 않는다.
export const COLLECTED_SITE_PREFIX={saramin:'saramin-',catch:'catch-',jasoseol:'jasoseol-',jobkorea:'jobkorea-'};
export function pruneCollected(collected,{site,runId,runs=[],plan,records,scan,directUrls=false,nowMs=Date.now()}){
  const prefixes=Object.values(COLLECTED_SITE_PREFIX),isSiteRecord=r=>prefixes.some(p=>String(r.id).startsWith(p));
  const isClosed=r=>{const at=r.deadline?.at?Date.parse(r.deadline.at):NaN;return Number.isFinite(at)&&at<nowMs;};
  const removed=[];let skipped=null;
  const keepIds=new Set(records.map(r=>r.id));
  const planKey=String(plan?.remoteKey||plan?.url||'');
  const previous=runs.find(r=>r.site===site&&r.id!==runId&&r.status==='completed'&&String(r.plan?.remoteKey||r.plan?.url||'')===planKey&&Number(r.count)>0);
  if(directUrls)skipped='직접 주소 추가는 정리하지 않음';
  else if(scan?.complete!==true||scan?.stopReason)skipped='검색 결과를 끝까지 읽지 못해 사라진 공고는 정리하지 않음';
  else if(!records.length)skipped='이번 결과가 0건이라 사라진 공고는 정리하지 않음';
  else if(previous&&records.length<previous.count*0.5)skipped='같은 조건의 직전 수집보다 절반 아래로 줄어 사라진 공고는 정리하지 않음';
  const prefix=COLLECTED_SITE_PREFIX[site],next=[];
  for(const r of collected){
    if(isSiteRecord(r)&&!r.manualAdd&&isClosed(r)&&!keepIds.has(r.id)){removed.push({reason:'마감',record:r});continue;}
    if(!skipped&&prefix&&String(r.id).startsWith(prefix)&&!r.manualAdd&&!keepIds.has(r.id)){removed.push({reason:'사이트 검색 결과에서 사라짐',record:r});continue;}
    next.push(r);
  }
  return {collected:next,removed,skipped};
}
export function updateObservation(previous,row) {
  const next={...structuredClone(row),discoveredAt:previous?.discoveredAt||row.discoveredAt};
  if(previous && row.detailFetch?.status==='failed') {
    next.detailText=previous.detailText;
    next.imageOcr=previous.imageOcr;
    for(const key of ['required','preferred','stages','documents','requirementsEvidence','extractionMethod'])if(previous[key]!==undefined)next[key]=structuredClone(previous[key]);
    if(next.education==='미확인'&&previous.education)next.education=previous.education;
    next.sources=structuredClone(previous.sources);
    next.detailCheckedAt=previous.detailCheckedAt||previous.checkedAt;
    next.latestObservation={checkedAt:row.checkedAt,title:row.title,deadlineLabel:row.deadline.label,detailFetch:row.detailFetch,sources:row.sources};
    next.evidenceNotes=[...(previous.evidenceNotes||[]),`최신 상세 조회 실패: ${row.detailFetch.error}. 이전 상세와 근거를 보존했습니다.`].slice(-20);
  }
  return next;
}

export async function createJobsApp({root=path.resolve(assets,'..'),collector=collectSaramin,collectors={}}={}) {
  const buildHash=createHash('sha256');for(const name of buildFiles)buildHash.update(await fs.readFile(path.join(assets,name)));const buildId=buildHash.digest('hex');
  root=path.resolve(root);const canonicalRoot=await fs.realpath(root),projectId=createHash('sha256').update(process.platform==='win32'?canonicalRoot.toLowerCase():canonicalRoot).digest('hex').slice(0,20);
  const jobs=path.join(root,'jobs'),runtime=path.join(root,'.runtime','jobs'),file=path.join(runtime,'workspace.json');
  await fs.mkdir(runtime,{recursive:true});
  const lease=net.createServer(socket=>socket.destroy()),leasePath=process.platform==='win32'?'\\\\.\\pipe\\local-job-desk-'+projectId:process.platform==='linux'?'\0local-job-desk-'+projectId:path.join(runtime,'instance.sock');
  await new Promise((resolve,reject)=>{lease.once('error',e=>reject(fail('이 프로젝트는 이미 실행 중이거나 실행 잠금을 사용할 수 없습니다. 기존 서버와 저장본은 변경하지 않았습니다. ('+e.code+')',409)));lease.listen(leasePath,resolve);});
  try{
  const [seed,schema,initial]=await Promise.all([read(path.join(jobs,'data.json')),read(path.join(jobs,'settings-schema.json')),read(path.join(jobs,'search-settings.json'))]);
  validateWorkspace({schemaVersion:1,revision:0,profile:blankProfile(),settings:C.normalizeSettings(initial,schema),collected:seed.records,runs:[]},schema);
  let state=await read(file,{schemaVersion:1,revision:0,profile:blankProfile(),settings:C.normalizeSettings(initial,schema),collected:[],runs:[]});
  validateWorkspace(state,schema);
  state.settings=C.normalizeSettings(state.settings,schema); state.profile=normalizeProfile(state.profile);
  state.schedule=state.schedule?{...normalizeSchedule(state.schedule),nextRunAt:state.schedule.nextRunAt,lastRunAt:state.schedule.lastRunAt,message:state.schedule.message}:blankSchedule();
  state.notifications=Array.isArray(state.notifications)?state.notifications:[];state.deadlineNotified=state.deadlineNotified||{};
  state.annotations=state.annotations||{};state.stateVersion=Number.isSafeInteger(state.stateVersion)?state.stateVersion:0;
  if(state.schedule.enabled&&!Number.isFinite(Date.parse(state.schedule.nextRunAt)))state.schedule.nextRunAt=new Date(Date.now()+state.schedule.intervalMinutes*60000).toISOString();
  const available={saramin:collector,catch:args=>collectPublicSite('catch',args),jasoseol:args=>collectPublicSite('jasoseol',args),jobkorea:args=>collectPublicSite('jobkorea',args),...collectors};
  let queue=Promise.resolve(),active=null,batchTask=null,schedulerBusy=false,schedulerError=null,schedulerPromise=null,closing=false,closePromise=null,storageError=null;
  const mutate=fn=>{const job=queue.catch(()=>{}).then(async()=>{const next=structuredClone(state);const value=await fn(next);next.stateVersion=state.stateVersion+1;validateWorkspace(next,schema);await atomic(path.join(runtime,'workspace.previous.json'),state);await atomic(file,next);state=next;return value;});queue=job;return job;};
  const notify=(next,type,message,extra={})=>{next.notifications.unshift({id:randomUUID(),type,message,createdAt:now(),read:false,...extra});next.notifications=next.notifications.slice(0,100);};
  if(state.runs.some(r=>['running','stopping'].includes(r.status))||['running','stopping'].includes(state.batch?.status)) await mutate(next=>{
    for(const r of next.runs)if(['running','stopping'].includes(r.status)){r.status='interrupted';r.finishedAt=now();r.message='프로그램 재시작으로 중단됨 · 기존 결과 보존';}
    if(['running','stopping'].includes(next.batch?.status))Object.assign(next.batch,{status:'interrupted',currentSite:null,finishedAt:now(),message:'프로그램 재시작으로 중단됨 · 완료한 결과는 보존했고 남은 사이트는 자동 실행하지 않습니다.'});
  });
  function snapshot() { const records=mergedRecords(seed.records,state.collected).map(r=>({...r,comparison:compareProfile(r,state.profile)}));return {name:'local-job-desk',version:'0.2.0',buildId,projectId,schema,revision:state.revision,stateVersion:state.stateVersion,profile:state.profile,settings:state.settings,schedule:{...state.schedule,error:schedulerError},storageError,batch:state.batch||null,batchActive:Boolean(batchTask&&state.batch?.id===batchTask.id),notifications:state.notifications,annotations:state.annotations,data:{...seed,records,duplicates:duplicateCandidates(records)},runs:state.runs,active:active?{id:active.id,site:active.site,message:active.message,progress:active.progress,status:active.controller.signal.aborted?'stopping':'running'}:null,capabilities:{saramin:true,catch:true,jasoseol:true,jobkorea:true,scheduled:true,batchCollection:true,directJasoseolUrls:true,notifications:true,notificationChannels:['in-app'],remoteAccess:false}}; }
  async function startCollection(site='saramin',trigger='manual',directUrls=null,context={}) {
    if(closing)throw fail('프로그램이 종료 중입니다.',503);
    if(!Object.hasOwn(available,site)||typeof available[site]!=='function')throw fail('지원하지 않는 수집 사이트입니다.');
    if(active||(batchTask&&context.batchId!==batchTask.id)||(schedulerBusy&&trigger!=='scheduled')) throw fail('수집 중입니다. 완료하거나 중지한 뒤 다시 실행해주세요.',409);
    const filter=structuredClone(context.filter||state.settings.sites[site]),plan=directUrls?directJasoseolPlan(filter,directUrls):site==='saramin'?searchPlan(filter):sitePlan(site,filter),id=randomUUID(),controller=new AbortController();
    const entry={id,site,controller,message:'수집 준비 중',progress:{phase:'prepare',completed:0,total:null},promise:null}; active=entry;
    try { entry.ready=mutate(async next=>{next.runs.unshift({id,site,trigger,...context.batchId?{batchId:context.batchId}:{},status:'running',startedAt:now(),message:'수집 준비 중',plan});for(const old of next.runs.slice(40)){const key=createHash('sha256').update(old.id).digest('hex'),date=Number.isFinite(Date.parse(old.startedAt))?new Date(old.startedAt).toISOString().replace(/[^0-9]/g,''):'00000000000000000';await atomic(path.join(runtime,'history',date+'-'+key+'.json'),old);}next.runs=next.runs.slice(0,40);});await entry.ready; }
    catch { if(active===entry)active=null; throw fail('실행 기록을 저장하지 못했습니다. 수집을 시작하지 않았습니다.',500); }
    entry.promise=(async()=>{
      try {
        controller.signal.throwIfAborted();
        const result=await available[site]({filter,runtime,runId:id,directUrls,signal:controller.signal,progress:(message,detail)=>{entry.message=String(message).slice(0,500);if(detail&&['prepare','list','detail'].includes(detail.phase)){const total=Number.isSafeInteger(detail.total)&&detail.total>0?detail.total:null;entry.progress={phase:detail.phase,completed:Number.isSafeInteger(detail.completed)?Math.max(0,total?Math.min(total,detail.completed):detail.completed):0,total};}else entry.progress=null;}});
        controller.signal.throwIfAborted();
        entry.message='수집 결과를 저장하고 있습니다.';entry.progress={phase:'saving',completed:0,total:null};
        let cleanupInfo=null;
        await mutate(next=>{
          controller.signal.throwIfAborted();
          let added=0,updated=0;
          for(const row of result.records){const idx=next.collected.findIndex(r=>r.id===row.id);if(idx<0){next.collected.push(row);if(seed.records.some(r=>r.id===row.id||r.sources.some(a=>row.sources.some(b=>postingIdentity(a.url)===postingIdentity(b.url)))))updated++;else added++;}else{next.collected[idx]=updateObservation(next.collected[idx],row);updated++;}}
          if(directUrls)for(const row of result.records){const hit=next.collected.find(r=>r.id===row.id);if(hit)hit.manualAdd=true;}
          cleanupInfo=pruneCollected(next.collected,{site,runId:id,runs:next.runs,plan,records:result.records,scan:result.scan,directUrls:Boolean(directUrls)});next.collected=cleanupInfo.collected;
          const detailFailures=result.records.filter(r=>r.detailFetch?.status==='failed').length;
          Object.assign(next.runs.find(r=>r.id===id),{status:detailFailures||result.scan?.stopReason==='page-failed'?'partial':'completed',finishedAt:now(),message:`${result.records.length}건 확인 · 신규 ${added} · 재확인 ${updated}`+(detailFailures?` · 상세 실패 ${detailFailures}건 (이전 상세 보존)`:'')+(result.scan?` · 사이트 검색 총 ${result.scan.siteTotal??'미확인'}건 중 ${result.scan.unique}건 확인`+(result.scan.stopMessage?` · ${result.scan.stopMessage}`:''):'')+(cleanupInfo.removed.length?` · 정리 ${cleanupInfo.removed.length}건(마감 ${cleanupInfo.removed.filter(x=>x.reason==='마감').length}·사이트에서 사라짐 ${cleanupInfo.removed.filter(x=>x.reason!=='마감').length})`:'')+(cleanupInfo.skipped?` · ${cleanupInfo.skipped}`:''),count:result.records.length,added,updated,detailFailures,checkedAt:result.checkedAt,plan:result.plan,...result.scan?{scan:result.scan}:{}});
          if(added||detailFailures)notify(next,detailFailures?'partial':'new',schema.sites.find(s=>s.id===site).name+`: 신규 ${added}건`+(detailFailures?` · 상세 실패 ${detailFailures}건`:''),{runId:id});
        });storageError=null;
        if(cleanupInfo?.removed.length){try{await fs.mkdir(path.join(runtime,'cleanup-log'),{recursive:true});await atomic(path.join(runtime,'cleanup-log',new Date().toISOString().replace(/[^0-9]/g,'').slice(0,14)+'-'+site+'-'+id.slice(0,8)+'.json'),{site,runId:id,removedAt:now(),removed:cleanupInfo.removed});}catch{}}
      } catch(e) { await mutate(next=>{Object.assign(next.runs.find(r=>r.id===id),{status:controller.signal.aborted?'stopped':'failed',finishedAt:now(),message:controller.signal.aborted?'중지됨 · 이번 미완료 결과를 적용하지 않았습니다.':String(e.message).slice(0,500)});notify(next,controller.signal.aborted?'stopped':'failed',schema.sites.find(s=>s.id===site).name+' · '+(controller.signal.aborted?'수집 중지':'수집 실패: '+String(e.message).slice(0,200)),{runId:id});}); }
    })().finally(()=>{if(active===entry)active=null;});
    entry.promise.catch(e=>{storageError='수집 결과나 종료 기록을 저장하지 못했습니다. 이전 저장본을 유지했습니다. '+String(e.message).slice(0,200);}); return {id,status:'running'};
  }
  async function startBatch(data){
    if(closing)throw fail('프로그램이 종료 중입니다.',503);
    if(active||batchTask||schedulerBusy)throw fail('수집 중입니다. 완료하거나 중지한 뒤 다시 실행해주세요.',409);
    const sites=data.sites;
    if(!Array.isArray(sites)||!sites.length||sites.length>4||new Set(sites).size!==sites.length||sites.some(site=>!schema.sites.some(s=>s.id===site)))throw fail('수집할 사이트를 1~4개 선택해주세요.');
    const filters={};
    for(const site of sites){filters[site]=structuredClone(state.settings.sites[site]);try{site==='saramin'?searchPlan(filters[site]):sitePlan(site,filters[site]);}catch(e){throw fail(schema.sites.find(s=>s.id===site).name+': '+e.message);}}
    const entry={id:randomUUID(),controller:new AbortController(),ready:null,promise:null};batchTask=entry;
    try{
      entry.ready=mutate(next=>{
        if(data.revision!==next.revision)throw fail('다른 화면에서 조건이 바뀌었습니다. 최신 저장본을 확인한 뒤 다시 실행해주세요.',409);
        next.batch={id:entry.id,status:'running',sites:[...sites],revision:next.revision,startedAt:now(),finishedAt:null,currentSite:null,results:[],message:'선택한 '+sites.length+'개 사이트를 차례대로 확인합니다.'};
      });await entry.ready;
    }catch(e){if(batchTask===entry)batchTask=null;throw e;}
    entry.promise=(async()=>{
      let failure=null;
      try{
        for(const site of sites){
          if(closing||entry.controller.signal.aborted)break;
          await mutate(next=>{next.batch.currentSite=site;});
          if(closing||entry.controller.signal.aborted)break;
          const run=await startCollection(site,'batch',null,{batchId:entry.id,filter:filters[site]});
          await active?.promise;
          const result=state.runs.find(r=>r.id===run.id);
          await mutate(next=>{next.batch.results.push({site,runId:run.id,status:result.status,count:result.count||0,added:result.added||0,updated:result.updated||0,message:result.message});});
          if(result.status==='stopped')break;
        }
      }catch(e){failure=e;}
      const stopped=closing||entry.controller.signal.aborted;
      await mutate(next=>{
        const batch=next.batch,failed=batch.results.filter(r=>r.status==='failed').length,partial=batch.results.some(r=>r.status==='partial'),done=batch.results.filter(r=>['completed','partial'].includes(r.status)).length;
        batch.status=stopped?'stopped':failure?'failed':failed?(done?'partial':'failed'):partial?'partial':'completed';batch.currentSite=null;batch.finishedAt=now();
        batch.message=(stopped?'중지 확인':failure?'수집을 마치지 못했습니다.':failed||partial?'일부 사이트 확인 필요':'여러 사이트 수집 완료')+' · 완료 '+done+'/'+sites.length+' · 신규 '+batch.results.reduce((n,r)=>n+r.added,0)+' · 재확인 '+batch.results.reduce((n,r)=>n+r.updated,0)+(failed?' · 실패 '+failed+'개':'')+(stopped?' · 남은 사이트는 시작하지 않았습니다.':'')+(failure?' '+String(failure.message).slice(0,200):'');
      });
    })().finally(()=>{if(batchTask===entry)batchTask=null;});
    entry.promise.catch(e=>{storageError='여러 사이트 수집 기록을 저장하지 못했습니다. 완료한 결과와 이전 저장본을 유지했습니다. '+String(e.message).slice(0,200);});
    return {id:entry.id,status:'running'};
  }
  async function runScheduled(at=Date.now()){
    if(closing||schedulerBusy||active||batchTask||!state.schedule.enabled||Date.parse(state.schedule.nextRunAt)>at)return false;
    schedulerBusy=true;let settled;schedulerPromise=new Promise(resolve=>{settled=resolve;});const sites=[...state.schedule.sites],messages=[];
    try{
      await mutate(next=>{next.schedule.lastRunAt=new Date(at).toISOString();next.schedule.nextRunAt=new Date(at+next.schedule.intervalMinutes*60000).toISOString();next.schedule.message='예약 수집 실행 중';});
      for(const site of sites){
        if(closing||!state.schedule.enabled)break;if(!state.schedule.sites.includes(site))continue;
        try{const run=await startCollection(site,'scheduled');await active?.promise;const result=state.runs.find(r=>r.id===run.id);messages.push(schema.sites.find(s=>s.id===site).name+': '+result?.message);if(result?.status==='stopped')break;}
        catch(e){messages.push(schema.sites.find(s=>s.id===site).name+': '+e.message);}
      }
      await mutate(next=>{next.schedule.message=messages.join(' / ')||'예약 수집이 해제되었습니다.';});schedulerError=null;return true;
    }catch(e){schedulerError='예약 실행 기록을 저장하지 못했습니다. '+e.message;return false;}
    finally{schedulerBusy=false;settled();schedulerPromise=null;}
  }
  async function checkDeadlines(at=Date.now()){
    if(closing)return 0;
    const rows=mergedRecords(seed.records,state.collected).filter(r=>C.state(r,at)==='urgent'&&!state.deadlineNotified[r.id+'|'+r.deadline.at]);
    if(!rows.length)return 0;
    return mutate(next=>{let count=0;for(const row of rows){const key=row.id+'|'+row.deadline.at;if(next.deadlineNotified[key])continue;next.deadlineNotified[key]=row.deadline.at;notify(next,'deadline',row.company+' · '+row.title+' · 7일 이내 마감 (원문 재확인)',{recordId:row.id});count++;}for(const[key,value]of Object.entries(next.deadlineNotified))if(Date.parse(value)<=at)delete next.deadlineNotified[key];return count;});
  }
  const scheduleTimer=setInterval(()=>{void runScheduled().then(()=>checkDeadlines()).catch(e=>{schedulerError=e.message;});},30000);scheduleTimer.unref();
  const send=(res,status,value)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(value));};
  async function history(cursor){
    const recent=structuredClone(state.runs),hash=id=>createHash('sha256').update(id).digest('hex'),known=new Set(recent.map(r=>hash(r.id)));let files=[];try{files=(await fs.readdir(path.join(runtime,'history'),{withFileTypes:true})).filter(e=>e.isFile()&&/^\d{17}-[a-f0-9]{64}\.json$/.test(e.name)).map(e=>e.name).sort().reverse().filter(name=>!known.has(name.slice(18,-5)));}catch(e){if(e.code!=='ENOENT')throw e;}
    const rows=[...recent.map(run=>({key:hash(run.id),run})),...files.map(name=>({key:name.slice(18,-5),name}))];let start=0;if(cursor){if(!/^[a-f0-9]{64}$/.test(cursor))throw fail('실행 기록 위치를 확인해주세요.');const index=rows.findIndex(r=>r.key===cursor);if(index<0)throw fail('실행 기록이 바뀌었습니다. 처음부터 다시 확인해주세요.',409);start=index+1;}
    const selected=rows.slice(start,start+20),runs=[];for(const row of selected){if(row.run)runs.push(row.run);else try{runs.push(await read(path.join(runtime,'history',row.name)));}catch{runs.push({id:row.key,status:'unreadable',message:'보관된 실행 기록을 읽지 못했습니다. 원본은 보존했습니다.'});}}
    return {projectId,total:rows.length,runs,nextCursor:start+selected.length<rows.length?selected.at(-1)?.key:null};
  }
  async function body(req) {
    if(!/^application\/json(?:;|$)/i.test(req.headers['content-type']||'')) throw fail('JSON 요청만 허용합니다.',415);
    const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>200000)throw fail('요청이 너무 큽니다.',413);chunks.push(chunk);}
    try{return JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{throw fail('요청 형식이 올바르지 않습니다.');}
  }
  const server=http.createServer(async(req,res)=>{
    try{
      const host=req.headers.host||'',expected=new Set([`127.0.0.1:${server.address()?.port}`,`localhost:${server.address()?.port}`]);
      if(!expected.has(host))throw fail('이 컴퓨터에서만 사용할 수 있습니다.',403);
      if(req.headers['x-job-desk-project']&&req.headers['x-job-desk-project']!==projectId)throw fail('서버의 프로젝트가 바뀌었습니다. 기존 초안을 보관하고 프로젝트를 확인한 뒤 새로고침해주세요.',409);
      const origin=`http://${host}`;
      if(req.headers.origin && req.headers.origin!==origin)throw fail('다른 사이트의 요청은 허용하지 않습니다.',403);
      const url=new URL(req.url,origin);if(closing&&req.method==='POST'&&url.pathname!=='/api/shutdown')throw fail('프로그램 종료 중입니다. 입력 초안을 보관하고 다시 실행해주세요.',503);
      if(req.method==='GET'&&url.pathname==='/api/health')return send(res,200,{name:'local-job-desk',version:'0.2.0',buildId,pid:process.pid,root});
      if(req.method==='GET'&&url.pathname==='/api/history')return send(res,200,await history(url.searchParams.get('cursor')));
      if(req.method==='GET'&&url.pathname==='/api/state')return send(res,200,snapshot());
      if(req.method==='POST'&&url.pathname==='/api/shutdown'){if(req.headers['x-job-desk-project']!==projectId)throw fail('종료할 프로젝트를 먼저 확인해주세요.',403);await body(req);send(res,202,{status:'stopping'});setImmediate(()=>{void close();});return;}
      if(req.method==='POST'&&url.pathname==='/api/preferences'){
        const data=await body(req),settings=C.normalizeSettings(data.settings,schema),profile=normalizeProfile(data.profile);
        await mutate(next=>{if(data.revision!==next.revision)throw fail('다른 화면에서 조건이 바뀌었습니다. 새로 불러온 뒤 저장해주세요.',409);next.settings=settings;next.profile=profile;next.revision++;});
        return send(res,200,snapshot());
      }
      if(req.method==='POST'&&url.pathname==='/api/schedule'){
        const data=await body(req),schedule=normalizeSchedule(data.schedule);
        if(schedule.enabled)for(const site of schedule.sites){const filter=state.settings.sites[site];site==='saramin'?searchPlan(filter):sitePlan(site,filter);}
        await mutate(next=>{if(data.revision!==next.revision)throw fail('다른 화면에서 설정이 바뀌었습니다. 최신 상태를 확인한 뒤 저장해주세요.',409);next.schedule={...schedule,nextRunAt:schedule.enabled?new Date(Date.now()+schedule.intervalMinutes*60000).toISOString():null,message:schedule.enabled?'예약 수집 대기 중':'예약 수집을 껐습니다. 실행 중인 수집은 중지 버튼으로 멈출 수 있습니다.'};next.revision++;});
        return send(res,200,snapshot());
      }
      if(req.method==='POST'&&url.pathname==='/api/notifications/read'){
        const data=await body(req);await mutate(next=>{const index=next.notifications.findIndex(n=>n.id===data.upTo);if(index<0)throw fail('알림 목록이 바뀌었습니다. 다시 확인해주세요.',409);for(const item of next.notifications.slice(index))item.read=true;});return send(res,200,snapshot());
      }
      if(req.method==='POST'&&url.pathname==='/api/annotation'){
        const data=await body(req);
        if(typeof data.notes!=='string'||data.notes.length>5000||!Number.isInteger(data.revision)||!Array.isArray(data.checkedTasks)||!Array.isArray(data.checkedDocuments)||[...data.checkedTasks,...data.checkedDocuments].some(s=>typeof s!=='string'||s.length>500)||data.checkedTasks.length>30||data.checkedDocuments.length>30)throw fail('메모는 5,000자 이내로 입력하고 준비 항목을 확인해주세요.');
        await mutate(next=>{const row=mergedRecords(seed.records,next.collected).find(r=>r.id===data.id);if(!row)throw fail('저장된 공고를 찾지 못했습니다.',404);const previous=next.annotations[data.id]||{revision:0};if(data.revision!==previous.revision)throw fail('다른 화면에서 준비 기록이 바뀌었습니다. 초안을 보관하고 최신 기록을 확인해주세요.',409);
          if(data.checkedTasks.some(v=>!row.prep.includes(v))||data.checkedDocuments.some(v=>!row.documents.includes(v)||/미확인|확인 필요/.test(v)))throw fail('공고의 준비 항목이 바뀌었습니다. 원문과 최신 항목을 확인해주세요.',409);
          next.annotations[data.id]={revision:previous.revision+1,notes:data.notes,checkedTasks:[...new Set(data.checkedTasks)],checkedDocuments:[...new Set(data.checkedDocuments)],savedAt:now()};});return send(res,200,snapshot());
      }
      if(req.method==='POST'&&url.pathname==='/api/import-urls'){const data=await body(req),plan=directJasoseolPlan(state.settings.sites.jasoseol,data.urls);return send(res,202,await startCollection('jasoseol','direct-urls',plan.urls));}
      if(req.method==='POST'&&url.pathname==='/api/collect'){const data=await body(req);return send(res,202,await startCollection(data.site||'saramin'));}
      if(req.method==='POST'&&url.pathname==='/api/collect-batch'){return send(res,202,await startBatch(await body(req)));}
      if(req.method==='POST'&&url.pathname==='/api/stop'){
        const data=await body(req);if(data.id!==active?.id&&data.id!==batchTask?.id||!data.id)throw fail('중지할 수집 실행을 찾지 못했습니다.',409);
        const current=active,batch=batchTask;batch?.controller.abort();current?.controller.abort();await mutate(next=>{const r=next.runs.find(r=>r.id===current?.id);if(r&&r.status==='running')r.status='stopping';if(batch&&next.batch?.id===batch.id&&['running','stopping'].includes(next.batch.status))next.batch.status='stopping';});
        return send(res,202,{id:data.id,status:'stopping'});
      }
      if(req.method==='GET'){
        const files={'/':'dashboard.html','/dashboard.html':'dashboard.html','/dashboard.css':'dashboard.css','/dashboard.js':'dashboard.js','/core.js':'core.js','/ui-fonts.js':'ui-fonts.js','/site-tables/saramin.json':'site-tables/saramin.json','/site-tables/catch.json':'site-tables/catch.json','/site-tables/jasoseol.json':'site-tables/jasoseol.json','/site-tables/jobkorea.json':'site-tables/jobkorea.json','/legacy':'index.html','/index.html':'index.html','/styles.css':'styles.css','/app.js':'app.js','/data.js':'data.js','/schema.js':'schema.js'};
        const name=files[url.pathname];if(name){res.writeHead(200,{'Content-Type':({'html':'text/html','css':'text/css','js':'application/javascript','json':'application/json'})[name.split('.').pop()]+'; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'"});res.end(await fs.readFile(path.join(assets,name)));return;}
      }
      send(res,404,{error:'페이지를 찾을 수 없습니다.'});
    }catch(e){const storageFailure=['EACCES','EPERM','ENOSPC','EIO','EROFS','EBUSY','EISDIR'].includes(e.code);send(res,storageFailure?500:e.status||400,{error:storageFailure?'저장 파일을 처리하지 못했습니다. 폴더 권한과 저장 공간을 확인해주세요. 기존 자료는 보존했습니다.':e.message});}
  });
  function close(){if(closePromise)return closePromise;closing=true;clearInterval(scheduleTimer);closePromise=(async()=>{const current=active,batch=batchTask;batch?.controller.abort();current?.controller.abort();await current?.ready?.catch(()=>{});await current?.promise?.catch(()=>{});await batch?.ready?.catch(()=>{});await batch?.promise?.catch(()=>{});await schedulerPromise;await queue.catch(()=>{});if(server.listening)await new Promise(resolve=>server.close(resolve));if(lease.listening)await new Promise(resolve=>lease.close(resolve));})();return closePromise;}
  server.headersTimeout=10000;server.requestTimeout=30000;
  return {server,snapshot,runScheduled,checkDeadlines,close};
  }catch(e){if(lease.listening)await new Promise(resolve=>lease.close(resolve));throw e;}
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  const app=await createJobsApp(),port=Number(process.env.JOB_DESK_PORT||42637);
  app.server.on('error',error=>{console.error(error.message);process.exitCode=1;});
  app.server.listen(port,'127.0.0.1',()=>console.log(`채용공고 작업실: http://127.0.0.1:${port}`));
  for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>{void app.close().then(()=>process.exit());});
}
