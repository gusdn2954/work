import test from 'node:test';
import assert from 'node:assert/strict';
import {parseListDeadline,parseDetailDeadline} from './saramin.mjs';
const now='2026-10-27T05:00:00Z';
test('목록 마감 표기는 요일이 맞는 연도만 적용한다',()=>{
  let d=parseListDeadline('~ 10/30(금)',now);assert.equal(d.at,'2026-10-30T23:59:59+09:00');assert.equal(d.precision,'date');
  d=parseListDeadline('~ 11/01(일)',now);assert.equal(d.at,'2026-11-01T23:59:59+09:00');
  d=parseListDeadline('~ 10/30(월)',now);assert.equal(d.at,null);assert.equal(d.label,'~ 10/30(월)');
  d=parseListDeadline('~ 01/02(토)',now);assert.equal(d.at,'2027-01-02T23:59:59+09:00');
  d=parseListDeadline('~ 02/29(월)',now);assert.equal(d.at,null);
});
test('오늘마감은 확인일 기준, 채용시·상시는 마감 계산하지 않는다',()=>{
  assert.equal(parseListDeadline('오늘마감',now).at,'2026-10-27T23:59:59+09:00');
  assert.equal(parseListDeadline('오늘마감','2026-10-27T16:30:00Z').at,'2026-10-28T23:59:59+09:00');
  for(const v of ['채용시','상시채용','','~ 마감'])assert.equal(parseListDeadline(v,now).at,null);
});
test('상세 접수기간은 종료일과 명시된 시각만 읽는다',()=>{
  let d=parseDetailDeadline('접수기간 및 방법\n접수기간 : 2026년 9월 30일(수) ~ 2026년 10월 30일(금)\n접수방법');assert.equal(d.day.label,'2026-10-30');assert.equal(d.time,null);
  d=parseDetailDeadline('접수기간 : 2026년 10월 1일 10시 ~ 2026년 10월 29일(목) 22시');assert.deepEqual(d.time,{hour:22,minute:0});
  assert.equal(parseDetailDeadline('접수기간 : 2026년 9월 30일 ~ 2026년 10월 30일(월)'),null);
  assert.equal(parseDetailDeadline('접수기간 및 방법\n온라인 접수'),null);
});
test('수집 실패 메시지는 사용자 조치 안내로 분류하되 성공 기록에는 붙이지 않는다',async()=>{
  await import('./core.js');const {recoveryHint}=globalThis.JobsCore;
  assert.equal(recoveryHint({status:'completed',message:'ok'}),'');
  assert.match(recoveryHint({status:'failed',message:'공개 페이지 응답 429: 기존 결과를 유지했습니다.'}),/제한/);
  assert.match(recoveryHint({status:'failed',message:'목록 구조를 확인하지 못했습니다.'}),/0건 성공/);
  assert.match(recoveryHint({status:'failed',message:'fetch failed'}),/네트워크/);
  assert.match(recoveryHint({status:'partial',message:'1건 상세 실패'}),/이전 본문/);
});
