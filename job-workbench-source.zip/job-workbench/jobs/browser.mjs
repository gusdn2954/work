import path from 'node:path';
import os from 'node:os';
import fs from 'node:fs/promises';
import {pathToFileURL} from 'node:url';

export async function launchBrowser() {
  let chromium;
  try { ({chromium} = await import('playwright')); }
  catch {
    const moduleFile = process.env.AI_WORKBENCH_PLAYWRIGHT_MODULE || path.join(os.homedir(), '.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs');
    try { ({chromium} = await import(pathToFileURL(moduleFile).href)); }
    catch { throw new Error('수집용 브라우저가 없습니다. jobs 폴더에서 npm install 후 npx playwright install chromium을 실행하세요.'); }
  }
  let executablePath = process.env.AI_WORKBENCH_BROWSER_EXE;
  if (!executablePath && process.platform === 'win32') {
    const chrome = 'C:/Program Files/Google/Chrome/Application/chrome.exe';
    try { await fs.access(chrome); executablePath = chrome; } catch {}
  }
  return chromium.launch({headless: true, ...(executablePath ? {executablePath} : {})});
}
