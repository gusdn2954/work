import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import './core.js';

// 배포 파일은 허용 목록으로만 구성한다. 작업 폴더/.runtime/사용자 설정은 복사하지 않는다.
const source=path.dirname(fileURLToPath(import.meta.url));
const output=process.argv[2]&&path.resolve(process.argv[2]);
if(!output)throw new Error('사용법: node jobs/build-portable.mjs 새_배포폴더_절대경로');
try{await fs.access(output);throw new Error('기존 폴더를 덮어쓰지 않습니다: '+output);}catch(e){if(e.code!=='ENOENT')throw e;}
const files=['server.mjs','saramin.mjs','public-sites.mjs','requirements.mjs','detail-body.mjs','browser.mjs','image-ocr.mjs','windows-ocr.ps1','dashboard.js','dashboard.html','dashboard.css','core.js','ui-fonts.js','FONT-LICENSE.txt','settings-schema.json','start-jobs.ps1','stop-jobs.ps1','index.html','styles.css','app.js','schema.js'];
const schema=JSON.parse(await fs.readFile(path.join(source,'settings-schema.json'),'utf8'));schema.project='내 공고 작업실';
const settings=globalThis.JobsCore.defaults(schema);for(const site of Object.values(settings.sites))site.enabled=false;
const seed={schemaVersion:1,project:schema.project,generatedAt:new Date().toISOString(),collectedAt:null,timezone:'Asia/Seoul',scope:'사용자가 선택한 조건으로 직접 수집한 공고를 이 PC에 저장합니다.',profile:{status:'미입력',confirmed:[],questions:[]},method:'공개 채용공고 수집',deduplication:'출처 중복 및 같은 채용 묶음',limitations:['공고별 원문과 지원 자격을 직접 확인하세요.'],records:[]};
const bundledModules=path.resolve(process.env.JOB_DESK_PACKAGE_MODULES||path.join(source,'node_modules'));
const pw=JSON.parse(await fs.readFile(path.join(bundledModules,'playwright/package.json'),'utf8'));
const licenseResponse=await fetch('https://raw.githubusercontent.com/nodejs/node/'+process.version+'/LICENSE');
if(!licenseResponse.ok)throw new Error('동봉 Node 버전의 공식 라이선스를 받지 못했습니다.');
const nodeLicense=await licenseResponse.text();
await fs.mkdir(path.join(output,'jobs/runtime'),{recursive:true});
for(const file of files)await fs.copyFile(path.join(source,file),path.join(output,'jobs',file));
const htmlFile=path.join(output,'jobs/dashboard.html');
await fs.writeFile(htmlFile,(await fs.readFile(htmlFile,'utf8')).replace('<div id="app-message"',`<section class="card first-run-guide" aria-label="처음 사용 안내"><h2>처음 시작하기</h2><p>① <a href="#major-preset">내 전공</a>을 고르세요. ② <a href="#condition-board">검색할 사이트</a>를 체크하고 ‘양식 펼치기’에서 검색 조건을 선택·저장하세요. ③ ‘공고 가져오기’를 누르면 목록이 채워집니다.</p><p>설정과 공고는 이 컴퓨터에 자동 보관됩니다. 다음부터는 바탕화면 ‘내 공고 작업실’을 누르세요.</p></section><div id="app-message"`));
await fs.cp(path.join(source,'site-tables'),path.join(output,'jobs/site-tables'),{recursive:true});
await fs.appendFile(path.join(output,'jobs/dashboard.css'),'\n.first-run-guide{margin:0 auto 16px;max-width:1400px}.first-run-guide p{overflow-wrap:anywhere}\n');
await fs.writeFile(path.join(output,'jobs/settings-schema.json'),JSON.stringify(schema,null,2));
await fs.writeFile(path.join(output,'jobs/search-settings.json'),JSON.stringify(settings,null,2));
await fs.writeFile(path.join(output,'jobs/data.json'),JSON.stringify(seed,null,2));
await fs.writeFile(path.join(output,'jobs/data.js'),'globalThis.JOBS_DATA = '+JSON.stringify(seed)+';\n');
await fs.writeFile(path.join(output,'jobs/package.json'),JSON.stringify({name:'local-job-desk-portable',version:'0.2.0',private:true,type:'module',dependencies:{playwright:pw.version}},null,2));
await fs.copyFile(process.execPath,path.join(output,'jobs/runtime/node.exe'));
await fs.mkdir(path.join(output,'licenses'),{recursive:true});
await fs.writeFile(path.join(output,'licenses/Node-LICENSE.txt'),nodeLicense);
for(const name of ['playwright','playwright-core'])await fs.cp(path.join(bundledModules,name),path.join(output,'jobs/node_modules',name),{recursive:true});
// 개발 PC 전용 경로를 제거하고 동봉한 의존성만 사용한다.
await fs.writeFile(path.join(output,'jobs/browser.mjs'),`import fs from 'node:fs/promises';
import {chromium} from 'playwright';
export async function launchBrowser(){
 let executablePath=process.env.AI_WORKBENCH_BROWSER_EXE;
 if(!executablePath){for(const root of [process.env.ProgramFiles,process.env['ProgramFiles(x86)'],process.env.LOCALAPPDATA].filter(Boolean)){for(const relative of ['Google/Chrome/Application/chrome.exe','Microsoft/Edge/Application/msedge.exe']){const file=root+'/'+relative;try{await fs.access(file);executablePath=file;break;}catch{}}if(executablePath)break;}}
 if(!executablePath)throw new Error('공고 수집에는 Chrome 또는 Edge가 필요합니다. 브라우저 설치 후 다시 실행하세요.');
 return chromium.launch({headless:true,executablePath});
}
`);
for(const name of ['start-jobs.ps1','stop-jobs.ps1','server.mjs']){
 const file=path.join(output,'jobs',name);let content=await fs.readFile(file,'utf8');content=content.replaceAll('42637','42638');
 if(name==='start-jobs.ps1')content=content.replace(/^.*codex-runtimes.*\r?\n/gm,'').replace("    $env:JOB_DESK_NODE_EXE","    (Join-Path $PSScriptRoot 'runtime\\node.exe')\n    $env:JOB_DESK_NODE_EXE");
 await fs.writeFile(file,content);
}
const cmd=action=>`@echo off\r\ncd /d "%~dp0"\r\npowershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0jobs\\${action}-jobs.ps1"${action==='start'?' -Open':''}\r\nif errorlevel 1 (\r\n echo.\r\n echo Failed. See the message above.\r\n pause\r\n)\r\n`;
await fs.writeFile(path.join(output,'채용 공고 실행.cmd'),cmd('start'));
await fs.writeFile(path.join(output,'채용 공고 종료.cmd'),cmd('stop'));
await fs.writeFile(path.join(output,'처음 읽어주세요.txt'),`내 공고 작업실 · Windows 64비트 체험 배포본\r\n\r\n1. 이 폴더 전체를 원하는 쓰기 가능한 위치에 복사하세요. ZIP으로 받았다면 먼저 전부 압축 해제하세요.\r\n2. '채용 공고 실행.cmd'를 더블클릭하세요. 주소는 http://127.0.0.1:42638/ 입니다.\r\n3. 처음에는 공고가 0개이고 사이트 선택도 꺼져 있습니다. 전공을 고르고 사이트별 검색조건을 설정·저장한 뒤 원하는 사이트를 선택하여 수집하세요.\r\n4. 종료는 '채용 공고 종료.cmd'를 실행하세요.\r\n\r\n실행 환경: Windows 10/11 64비트, 설치된 Chrome 또는 Edge, 인터넷 연결. Node ${process.version}와 Playwright ${pw.version}는 동봉했으므로 별도 Node/npm 설치는 필요 없습니다. 브라우저 본체는 동봉하지 않았습니다. 이미지 인식은 Windows OCR과 한국어 인식 언어 설치 상태에 따라 달라집니다.\r\n\r\n개인정보: 배포본에는 제작자의 공고·검색조건·메모·경험·로그·계정정보가 없습니다. 사용 후 생성되는 .runtime 폴더에는 본인의 기록이 저장됩니다. 사용한 폴더를 다른 사람에게 그대로 전달하지 말고, 처음 받은 깨끗한 원본을 전달하세요. 브라우저에도 필터·읽음·초안이 저장될 수 있습니다.\r\n\r\n개발용 기본 주소 42637과 별도 주소를 사용합니다. 같은 PC에서는 이 배포본 한 개만 실행하세요. 포트 충돌 시 다른 서버를 강제 종료하지 않습니다. 외부 공개 웹서비스가 아니며 다른 PC는 이 주소로 접속할 수 없습니다.\r\n\r\n확인 범위와 미확인 사항은 검증결과.json 및 인수인계.md를 참고하세요.\r\n`);
await fs.writeFile(path.join(output,'AGENTS.md'),`# 배포본 작업 규칙\n\n- Codex 또는 Claude 중 사용자가 이번 작업에 지정한 쪽이 담당한다. 고정 메인은 없으며 한 번에 한 명만 수정한다. 상대 AI를 자동 호출하지 않는다.\n- 시작 시 인수인계.md와 변경기록.md를 읽는다. 완료 시 변경·검증·미검증 사항을 변경기록.md에 기록한다.\n- 사용자의 .runtime, 공고, 경험, 메모, 검색조건은 보존한다. 공유용 원본에는 개인 자료를 포함하지 않는다.\n- 이 폴더는 체험 배포본이다. 가능한 한 개발 원본에서 수정 후 새 배포본을 생성한다. 배포본만 긴급 수정한 경우 변경 파일과 재생성 시 필요한 사항을 인계한다.\n- 커밋·푸시·외부 게시·유료 API 추가는 사용자 지시 없이 하지 않는다.\n`);
await fs.writeFile(path.join(output,'인수인계.md'),`# Codex / Claude 공통 인수인계\n\n2026-10-30 Codex가 생성한 Windows x64 체험 배포본. 고정 주담당 없음. 사용자가 작업별 담당을 지정하며 상대 AI를 자동 호출하지 않음.\n\n## 구조\n- jobs/: 서버·화면·수집·Windows OCR 코드와 공개 사이트 선택지\n- jobs/runtime/node.exe: Node 실행 파일\n- jobs/node_modules/: Playwright와 playwright-core(각 LICENSE/NOTICE 포함)\n- licenses/: Node 라이선스\n- .runtime/: 첫 실행/저장 후 생기는 사용자 자료(깨끗한 배포본에는 없음)\n- 배포명세.json: 상대 경로별 해시·크기와 생성 버전\n\n## 배포용 변경\n- 포트 42638로 분리, 빈 공고/개인조건/검색조건, 사이트 선택 기본 해제\n- 동봉 Node 우선 사용, Codex 설치 경로 의존 제거\n- 동봉 Playwright와 설치된 Chrome/Edge 사용, Chromium 본체 미동봉\n- 실행 오류 시 창을 유지하여 오류를 읽을 수 있게 함\n\n## 다음 담당자 확인\n- 별도 Windows PC에서 첫 실행, 사이트별 실제 수집, 한국어 OCR을 확인할 것. 현재 PC의 격리 검사는 다른 PC 검증을 대신하지 않음.\n- 경험 입력·AI 적합도 평가는 이 배포 작업에 추가하지 않았음.\n- 기존 작업실의 공고/메모/계정자료를 복사하지 말 것.\n- 원본 재생성 스크립트: 개발 프로젝트 jobs/build-portable.mjs (새 폴더 경로 전달, 기존 폴더 덮어쓰기 금지)\n`);
await fs.writeFile(path.join(output,'변경기록.md'),'# 변경기록\n\n- 2026-10-30 Codex: 개인 자료 없는 체험 배포본 생성. 최종 검증은 검증결과.json 참고.\n');
const list=[];async function walk(dir){for(const entry of await fs.readdir(dir,{withFileTypes:true})){const absolute=path.join(dir,entry.name);if(entry.isDirectory())await walk(absolute);else{const bytes=await fs.readFile(absolute);list.push({path:path.relative(output,absolute).replaceAll('\\','/'),bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')});}}}
await walk(output);await fs.writeFile(path.join(output,'배포명세.json'),JSON.stringify({format:1,createdAt:new Date().toISOString(),platform:process.platform,arch:process.arch,node:process.version,playwright:pw.version,port:42638,files:list},null,2));
console.log(JSON.stringify({output,files:list.length,bytes:list.reduce((n,f)=>n+f.bytes,0)}));
