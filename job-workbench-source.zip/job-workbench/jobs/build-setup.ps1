param([Parameter(Mandatory=$true)][string]$Payload,[Parameter(Mandatory=$true)][string]$Output)
$ErrorActionPreference='Stop'
$payloadRoot=(Resolve-Path -LiteralPath $Payload).Path
if(Test-Path -LiteralPath $Output){throw '기존 출력 폴더를 덮어쓰지 않습니다.'}
$manifest=Get-Content -LiteralPath (Join-Path $payloadRoot '배포명세.json') -Raw -Encoding utf8 | ConvertFrom-Json
$allowed=@($manifest.files | ForEach-Object {
  $resolved=[IO.Path]::GetFullPath((Join-Path $payloadRoot $_.path))
  if(-not $resolved.StartsWith($payloadRoot+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw '배포 파일 경로 오류'}
  if((Get-FileHash -LiteralPath $resolved).Hash.ToLowerInvariant() -ne $_.sha256){throw ('파일 변경 감지: '+$_.path)}
  $_.path
})
$allowed+='배포명세.json'
if(Test-Path -LiteralPath (Join-Path $payloadRoot '검증결과.json')){$allowed+='검증결과.json'}
New-Item -ItemType Directory -Path $Output | Out-Null
$tempRoot=Join-Path $env:TEMP ('job-desk-setup-build-'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $tempRoot | Out-Null
$payloadZip=Join-Path $tempRoot 'payload.zip'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip=[IO.Compression.ZipFile]::Open($payloadZip,[IO.Compression.ZipArchiveMode]::Create)
try{foreach($relative in $allowed){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,(Join-Path $payloadRoot $relative),$relative.Replace('\','/'),[IO.Compression.CompressionLevel]::Optimal)|Out-Null}}finally{$zip.Dispose()}
$compiler=Join-Path $env:SystemRoot 'Microsoft.NET/Framework64/v4.0.30319/csc.exe'
$exe=Join-Path $Output '설치하고 시작하기.exe'
& $compiler /nologo /target:winexe /platform:x64 /reference:System.Windows.Forms.dll /reference:System.IO.Compression.dll /reference:System.IO.Compression.FileSystem.dll ('/resource:'+$payloadZip+',payload.zip') ('/out:'+$exe) (Join-Path $PSScriptRoot 'portable-setup.cs')
if($LASTEXITCODE -ne 0){throw '설치 실행 파일 빌드 실패'}
@'
처음 사용하는 분께

이 설치기는 서명 검증과 스마트 앱 컨트롤 PC 검증을 마치기 전에는 내부 체험용입니다.
스마트 앱 컨트롤이 켜진 PC에서는 실행이 차단될 수 있습니다. 보안 설정을 끄지 마세요.

1. 받은 ZIP에서 '모두 압축 풀기'를 누르세요.
2. '설치하고 시작하기.exe'를 더블클릭하세요.
3. 화면이 열리면 내 전공 → 검색 사이트·조건 → 공고 가져오기 순서로 진행하세요.

다음부터는 바탕화면 '내 공고 작업실'을 누르면 됩니다.
종료하려면 바탕화면 '내 공고 작업실 종료'를 누르세요.

Windows 10/11 64비트와 Chrome 또는 Edge가 필요합니다. Node/npm 설치나 명령어 입력은 필요 없습니다.
관리자 권한 없이 본인 계정의 AppData/Local/JobDeskTrial에 설치합니다.
개인 기록은 설치 폴더 안에 보관합니다. 제작자의 개인 기록은 포함하지 않았습니다.
이 설치기는 첫 설치용입니다. 기존 설치본이 있으면 자료를 덮어쓰지 않고 기존 버전을 실행합니다.
디지털 서명이 없는 체험판으로 Windows 보안 확인이 나타날 수 있습니다. 보안 기능을 끄도록 요구하지 않습니다.
다른 PC에서 실제 수집과 이미지 인식은 아직 검증하지 않았습니다.
'@ | Set-Content -LiteralPath (Join-Path $Output '먼저 읽어주세요.txt') -Encoding utf8
$exeHash=(Get-FileHash -LiteralPath $exe).Hash
$signingTargets=@($exe,(Join-Path $payloadRoot 'jobs/runtime/node.exe'),(Join-Path $payloadRoot 'jobs/start-jobs.ps1'),(Join-Path $payloadRoot 'jobs/stop-jobs.ps1'),(Join-Path $payloadRoot 'jobs/windows-ocr.ps1'))
$unsignedTargets=@($signingTargets|Where-Object {(Get-AuthenticodeSignature -LiteralPath $_).Status -ne 'Valid'})
[pscustomobject]@{signingPrerequisiteSatisfied=($unsignedTargets.Count -eq 0);smartAppControlDeviceTested=$false;publicDistributionReady=$false;nextCheck='jobs/check-distribution-trust.ps1 실행 후 스마트 앱 컨트롤이 켜진 별도 PC에서 실제 설치/실행/OCR 확인 필요'}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $Output '배포 준비 상태.json') -Encoding utf8
if($unsignedTargets.Count){Write-Warning '서명 없는 내부 체험 빌드입니다. 스마트 앱 컨트롤 호환 배포본으로 안내하지 마세요.'}
[pscustomobject]@{createdAt=[DateTime]::UtcNow.ToString('o');version='0.2.0-trial-setup';sha256=$exeHash;payloadFiles=$allowed.Count;source='Codex';handoff='고정 주담당 없음. 사용자가 지정한 Codex 또는 Claude 한 명만 수정. jobs/build-portable.mjs + jobs/build-setup.ps1로 새 설치본 생성. 기존 설치본 자동 업데이트는 미구현.'}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $Output '설치판 정보.json') -Encoding utf8
Write-Output $exe
