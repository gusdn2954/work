import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomUUID} from 'node:crypto';
import {validateWorkspace} from './server.mjs';
const project=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
export async function inspectWorkspace(root=project){
  const schema=JSON.parse(await fs.readFile(path.join(root,'jobs/settings-schema.json'),'utf8')),result={};
  for(const key of ['workspace.json','workspace.previous.json']){
    try{const raw=await fs.readFile(path.join(root,'.runtime/jobs',key),'utf8'),data=JSON.parse(raw.replace(/^\uFEFF/,''));validateWorkspace(data,schema);result[key]={valid:true,revision:data.revision,stateVersion:data.stateVersion||0,collected:data.collected.length,runs:data.runs.length,preparationRecords:Object.keys(data.annotations||{}).length};}
    catch(e){result[key]={valid:false,error:e.code==='ENOENT'?'파일 없음':e instanceof SyntaxError?'JSON 형식을 읽지 못했습니다. 내용은 출력하지 않았습니다.':e.message};}
  }return result;
}
export async function restorePrevious(root=project){
  const runtime=path.join(root,'.runtime/jobs'),status=await inspectWorkspace(root);if(!status['workspace.previous.json'].valid)throw new Error('복원할 이전 저장본이 유효하지 않습니다. 현재 파일을 변경하지 않았습니다.');
  try{const live=await(await fetch('http://127.0.0.1:42637/api/health',{signal:AbortSignal.timeout(1000)})).json();if(path.resolve(live.root)===path.resolve(root))throw Object.assign(new Error('이 프로젝트 서버를 종료한 뒤 복원해주세요.'),{active:true});}catch(e){if(e.active)throw e;}
  try{const pid=JSON.parse((await fs.readFile(path.join(runtime,'server.json'),'utf8')).replace(/^\uFEFF/,'')).pid;if(Number.isSafeInteger(pid)&&pid>0){let alive=false;try{process.kill(pid,0);alive=true;}catch{}if(alive)throw Object.assign(new Error('기록된 서버 프로세스의 종료를 먼저 확인해주세요.'),{active:true});}}catch(e){if(e.active)throw e;}
  const previous=await fs.readFile(path.join(runtime,'workspace.previous.json')),dir=path.join(runtime,'recovery');await fs.mkdir(dir,{recursive:true});
  let preserved=path.join(dir,'workspace-before-'+Date.now()+'-'+randomUUID()+'.json');try{await fs.copyFile(path.join(runtime,'workspace.json'),preserved);}catch(e){if(e.code!=='ENOENT')throw e;preserved=null;}
  const temporary=path.join(runtime,'restore-'+randomUUID()+'.tmp');try{await fs.writeFile(temporary,previous);await fs.rename(temporary,path.join(runtime,'workspace.json'));}finally{await fs.rm(temporary,{force:true}).catch(()=>{});}
  return {restored:true,preserved,warning:'이전 저장본으로 복원했습니다. 마지막 저장 내용 일부는 복원 전 파일에만 있을 수 있습니다.'};
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  if(process.argv.includes('--restore-previous'))console.log(JSON.stringify(await restorePrevious(),null,2));
  else console.log(JSON.stringify(await inspectWorkspace(),null,2));
}
