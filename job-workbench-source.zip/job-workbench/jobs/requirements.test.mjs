import test from 'node:test';
import assert from 'node:assert/strict';
import {extractRequirements,compareProfile} from './requirements.mjs';
test('원문에 명시된 자격·우대·서류만 구분하고 접수일은 서류로 섞지 않는다',()=>{
  const r=extractRequirements('[지원 자격]\n학사 이상\n경력 3년 이상\n[우대사항] SQLD 보유\n[제출서류]\n지원서 및 포트폴리오\n[접수기간]\n2026.11.01');
  assert.deepEqual(r.fields.required,['학사 이상','경력 3년 이상']);assert.deepEqual(r.fields.preferred,['SQLD 보유']);assert.deepEqual(r.fields.documents,['지원서 및 포트폴리오']);assert.deepEqual(r.evidence.documents.quotes,r.fields.documents);
});
test('표제가 없거나 이미지 안내뿐인 요약에서 자격·서류를 지어내지 않는다',()=>{
  assert.deepEqual(extractRequirements('자세한 자격요건과 우대사항은 이미지 공고를 확인하세요.').fields,{});
  assert.deepEqual(extractRequirements('[제출서류]\n[접수기간]\n2026-11-01').fields,{});
});
test('HTML에서 한 줄이 된 대괄호 표제도 자격과 서류를 섞지 않는다',()=>{
  const r=extractRequirements('[지원자격] 검증 필수 조건 [제출서류] 검증 포트폴리오');assert.deepEqual(r.fields.required,['검증 필수 조건']);assert.deepEqual(r.fields.documents,['검증 포트폴리오']);
});
test('전형 구절 뒤 문의 표제에서 추출을 중단하고 분량 제한을 표시한다',()=>{
  const r=extractRequirements('전형 절차:\n서류 > 면접\n문의:\n채용 담당자');assert.deepEqual(r.fields.stages,['서류 > 면접']);
  const long=extractRequirements('[필수조건]\n'+'가'.repeat(600));assert.equal(long.fields.required[0].length,500);assert.equal(long.evidence.required.truncated,true);
});
test('개인 조건이 없으면 비교를 만들지 않고 Java를 JavaScript 충족으로 표시하지 않는다',()=>{
  const row={company:'검증',title:'개발자',roles:['개발'],locations:['서울'],career:['신입'],employment:['정규직'],education:'미확인',required:['JavaScript 경험'],preferred:['SQLD 보유'],detailText:''};
  assert.deepEqual(compareProfile(row,{}),[]);const result=compareProfile(row,{credentials:'Java, SQLD',locations:'서울',education:'학사'});
  assert.equal(result.find(r=>r.term==='Java').status,'원문 추가 확인');assert.equal(result.find(r=>r.term==='SQLD').status,'같은 문구 있음');assert.equal(result.find(r=>r.term==='학사').status,'원문 추가 확인');assert.ok(result.every(r=>!r.status.includes('충족')));
});
