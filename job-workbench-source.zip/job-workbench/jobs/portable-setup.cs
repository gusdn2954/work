using System;
using System.IO;
using System.IO.Compression;
using System.Diagnostics;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

class JobDeskSetup {
 [STAThread] static int Main(string[] args) {
  try {
   bool test=args.Length==2 && args[0]=="--test-install";
   string target=test?Path.GetFullPath(args[1]):Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"JobDeskTrial");
   string self=Assembly.GetExecutingAssembly().Location;
   string installed=Path.Combine(target,"내 공고 작업실.exe");
   if(!test && String.Equals(Path.GetFullPath(self),installed,StringComparison.OrdinalIgnoreCase)){Start(target);return 0;}
   // 기존 설치본/사용자 자료를 덮어쓰지 않는다. 재실행은 기존 설치본을 연다.
   if(!test && File.Exists(installed)){Start(target);return 0;}
   if(Directory.Exists(target) && Directory.GetFileSystemEntries(target).Length>0)throw new Exception("설치할 폴더에 기존 자료가 있습니다. 기존 자료를 보존하기 위해 중단했습니다: "+target);
   Directory.CreateDirectory(target);
   using(Stream data=Assembly.GetExecutingAssembly().GetManifestResourceStream("payload.zip"))
   using(ZipArchive zip=new ZipArchive(data,ZipArchiveMode.Read)) {
    foreach(ZipArchiveEntry entry in zip.Entries) {
     string relative=entry.FullName.Replace('/',Path.DirectorySeparatorChar);
     if(relative.Contains("..") || Path.IsPathRooted(relative))throw new Exception("잘못된 설치 경로입니다.");
     string dest=Path.GetFullPath(Path.Combine(target,relative));
     if(!dest.StartsWith(target+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase))throw new Exception("설치 경로를 확인할 수 없습니다.");
     Directory.CreateDirectory(Path.GetDirectoryName(dest));
     using(Stream input=entry.Open())using(Stream output=File.Create(dest))input.CopyTo(output);
    }
   }
   File.Copy(self,installed,false);
   if(test){Shortcut(Path.Combine(target,"검사용 바로가기.lnk"),installed,target);return 0;}
   Shortcut(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),"내 공고 작업실.lnk"),installed,target);
   Shortcut(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),"내 공고 작업실 종료.lnk"),Path.Combine(Environment.SystemDirectory,"WindowsPowerShell\\v1.0\\powershell.exe"),target,"-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \""+Path.Combine(target,"jobs\\stop-jobs.ps1")+"\"");
   Start(target);return 0;
  }catch(Exception error){if(args.Length==0)MessageBox.Show(error.Message,"내 공고 작업실 실행 안내",MessageBoxButtons.OK,MessageBoxIcon.Information);return 1;}
 }
 static void Start(string target){
  string script=Path.Combine(target,"jobs\\start-jobs.ps1").Replace("'","''"), log=Path.Combine(target,"실행오류.txt").Replace("'","''");
  string command="$ErrorActionPreference='Stop';try{& '"+script+"' -Open *> '"+log+"';exit 0}catch{$_ | Out-File -LiteralPath '"+log+"' -Encoding utf8;exit 1}";
  ProcessStartInfo info=new ProcessStartInfo(Path.Combine(Environment.SystemDirectory,"WindowsPowerShell\\v1.0\\powershell.exe"),"-NoProfile -ExecutionPolicy Bypass -EncodedCommand "+Convert.ToBase64String(Encoding.Unicode.GetBytes(command)));
  info.UseShellExecute=false;info.CreateNoWindow=true;info.WorkingDirectory=target;
  using(Process process=Process.Start(info)){if(!process.WaitForExit(90000))throw new Exception("시작 시간이 오래 걸립니다. 잠시 뒤 바탕화면 바로가기를 다시 눌러주세요.");if(process.ExitCode!=0)throw new Exception(File.Exists(Path.Combine(target,"실행오류.txt"))?File.ReadAllText(Path.Combine(target,"실행오류.txt")):"프로그램을 시작하지 못했습니다.");}
 }
 static void Shortcut(string file,string exe,string directory,string arguments=""){
  Type shellType=Type.GetTypeFromProgID("WScript.Shell");object shell=Activator.CreateInstance(shellType);
  object link=shellType.InvokeMember("CreateShortcut",BindingFlags.InvokeMethod,null,shell,new object[]{file});Type type=link.GetType();
  type.InvokeMember("TargetPath",BindingFlags.SetProperty,null,link,new object[]{exe});type.InvokeMember("Arguments",BindingFlags.SetProperty,null,link,new object[]{arguments});type.InvokeMember("WorkingDirectory",BindingFlags.SetProperty,null,link,new object[]{directory});type.InvokeMember("WindowStyle",BindingFlags.SetProperty,null,link,new object[]{7});type.InvokeMember("Save",BindingFlags.InvokeMethod,null,link,null);
 }
}
