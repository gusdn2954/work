import {recognizeHtmlImages} from './image-ocr.mjs';
import {readPublicBody} from './detail-body.mjs';
import {extractRequirements} from './requirements.mjs';
import fs from 'node:fs/promises';
import path from 'node:path';
import {setTimeout as pause} from 'node:timers/promises';
import {fetchPublic} from './saramin.mjs';
import {launchBrowser} from './browser.mjs';

export const publicSites={catch:{name:'캐치',host:'www.catch.co.kr'},jasoseol:{name:'자소설닷컴',host:'jasoseol.com'},jobkorea:{name:'잡코리아',host:'www.jobkorea.co.kr'}};
const catchRegions=new Set(['서울','전남광주','부산','대구','인천','대전','울산','세종','경기','강원','충북','충남','전북','경북','경남','제주','해외']);
const catchEmployment=new Map([['정규직','1'],['계약직','2'],['인턴','4'],['교육생','7'],['기타','6']]);
const terms=value=>[...new Set(String(value||'').split(/[,，\n]/).map(v=>v.trim()).filter(Boolean))];
const text=value=>typeof value==='string'?value.trim():'';
const values=value=>Array.isArray(value)?value.map(text).filter(Boolean):text(value)?[text(value)]:[];
export function directJasoseolPlan(filter,urls){
  if(!filter.enabled)throw new Error('자소설닷컴 사이트 사용을 켜주세요.');
  if(!Array.isArray(urls)||!urls.length||urls.length>20)throw new Error('공개 공고 주소를 한 줄에 하나씩, 최대 5개 입력해주세요.');
  const canonical=[...new Set(urls.map(value=>{if(typeof value!=='string'||value.length>2000)throw new Error('공고 주소가 너무 깁니다.');let url;try{url=new URL(value);}catch{throw new Error('공개 공고 주소 형식을 확인해주세요.');}const match=url.pathname.match(/^\/recruit\/(\d+)\/?$/);if(url.protocol!=='https:'||url.hostname!=='jasoseol.com'||url.username||url.password||url.port||!match||!Number.isSafeInteger(Number(match[1]))||Number(match[1])<1)throw new Error('https://jasoseol.com/recruit/번호 형식의 공개 공고 주소만 넣어주세요.');return 'https://jasoseol.com/recruit/'+Number(match[1]);}))];
  if(canonical.length>5)throw new Error('한 번에 공개 공고 주소 최대 5개만 확인합니다.');
  return {site:'jasoseol',keyword:'',url:null,urls:canonical,remote:['지정한 공개 공고 주소'],local:[],unsupported:[],coverage:'지정한 공개 공고만 확인합니다. 검색·전체 사이트 수집이 아니며 저장된 목록 조건은 계속 적용됩니다.'};
}
export const JASOSEOL_LIMITS={perPage:20,maxPages:5,maxItems:100,pageDelayMs:1500};
// 자소설닷컴 검색 페이지의 서버 렌더링 데이터(__NEXT_DATA__의 jobSearch)를 읽는다. 구조가 다르면 0건으로 처리하지 않고 오류로 알린다.
export function readJasoseolSearch(html){
  const m=String(html).match(/<script id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/);if(!m)throw new Error('자소설닷컴 공개 목록 구조를 확인하지 못했습니다.');
  const query=JSON.parse(m[1]).props?.pageProps?.dehydratedState?.queries?.find(q=>q.queryKey?.[0]==='jobSearch'),data=query?.state?.data;
  if(!Array.isArray(data?.data)||!Number.isFinite(data.totalCount))throw new Error('자소설닷컴 공개 목록 구조를 확인하지 못했습니다.');
  const business={big_business:'대기업',middle_market:'중견기업',public_institution:'공공기관'},division={1:'신입',2:'경력',3:'인턴',4:'계약직',7:'교육'};
  const rows=data.data.filter(r=>Number.isSafeInteger(r.id)&&r.id>0&&typeof r.name==='string'&&r.name.trim()&&typeof r.title==='string'&&r.title.trim()).map(r=>{const divs=[...new Set((r.employments||[]).flatMap(e=>e.division||[]))];return {id:String(r.id),company:r.name,title:r.title,roles:(r.employments||[]).map(e=>text(e.field)).filter(Boolean),education:[...new Set((r.employments||[]).map(e=>text(e.graduate_condition)).filter(Boolean))].join(' / '),career:divs.filter(d=>d<=2).map(d=>division[d]),employment:divs.filter(d=>d>2).map(d=>division[d]||String(d)),companyType:business[r.company_group?.business_type]||(r.company_group?.business_type?'기타기업':''),deadline:r.end_time,startAt:r.start_time};});
  if(data.data.length&&!rows.length)throw new Error('자소설닷컴 공고 식별자를 확인하지 못했습니다.');
  return {rows,total:data.totalCount,page:query.queryKey?.[1]?.page};
}
export const NATIVE_LIMITS={catch:{perPage:20,maxPages:5,maxItems:100,pageDelayMs:1500},jasoseol:{...JASOSEOL_LIMITS},jobkorea:{perPage:40,maxPages:3,maxItems:100,pageDelayMs:1500}};
// 잡코리아 상세검색 결과 표(_GI_List)를 읽는다. 공고 번호·회사·제목·경력/학력/지역/고용형태·등록일·마감일. 구조가 다르면 0건으로 처리하지 않는다.
export function readJobkoreaList(html){
  const h=String(html),m=h.match(/data-text="전체">전체\s*<em>\(([\d,]+)건\)<\/em>/);
  const rows=[...h.matchAll(/<tr class="devloopArea"[\s\S]*?<\/tr>/g)].map(x=>x[0]).map(tr=>{
    const strip=v=>String(v||'').replace(/<[^>]+>/g,' ').replace(/&#183;/g,'·').replace(/&amp;/g,'&').replace(/&quot;/g,'"').replace(/\s+/g,' ').trim();
    const id=(tr.match(/data-gno="(\d+)"/)||[])[1],company=strip((tr.match(/<td class="tplCo">[\s\S]*?<a[^>]*>([\s\S]*?)<\/a>/)||[])[1]),title=strip((tr.match(/<td class="tplTit">[\s\S]*?<a[^>]*title="([^"]*)"/)||[])[1]);
    const cells=[...((tr.match(/<p class="etc">([\s\S]*?)<\/p>/)||[])[1]||'').matchAll(/<span class="cell">([\s\S]*?)<\/span>/g)].map(c=>strip(c[1]));
    const braze=((tr.match(/data-brazeinfo="([^"]*)"/)||[])[1]||'').split('|'),date=v=>/^\d{4}-\d{2}-\d{2}$/.test(v||'')?v:null;
    const start=date(braze[3]),end=date(braze[4]),dsc=strip((tr.match(/<p class="dsc">([\s\S]*?)<\/p>/)||[])[1]);
    return {id,company,title,career:cells[0]?[cells[0]]:[],education:cells[1]||'',locations:cells[2]?[cells[2]]:[],employment:cells[3]?[cells[3]]:[],roles:dsc?dsc.split(/,\s*/):[],deadline:end?end+'T23:59:59+09:00':null,startAt:start?start+'T00:00:00+09:00':null};
  }).filter(r=>r.id&&r.company&&r.title);
  if(!m&&!rows.length)throw new Error('잡코리아 상세검색 결과 구조를 확인하지 못했습니다. 0건으로 처리하지 않았습니다.');
  return {rows,total:m?Number(m[1].replace(/,/g,'')):rows.length};
}
export function sitePlan(site,filter) {
  const config=publicSites[site];if(!config)throw new Error('지원하지 않는 공개 수집 사이트입니다.');
  if(!filter.enabled)throw new Error(config.name+' 사이트 사용을 켜주세요.');
  const C=globalThis.JobsCore;
  const native=C.nativeQuery(site,filter.nativeQuery);
  if(native){
    if(!native.ok)throw new Error(config.name+': '+native.error);
    const limits={...NATIVE_LIMITS[site]};let url;
    if(site==='jasoseol'){url=new URL('/search','https://'+config.host);for(const[k,v]of Object.entries(native.params))url.searchParams.set(k,v);}
    else if(site==='catch'){url=new URL('/api/v1.0/recruit/information/getRecruitList','https://'+config.host);for(const[k,v]of Object.entries({...native.params,onRecruitYN:'Y',Sort:'0',curpage:'1',pageSize:String(limits.perPage)}))url.searchParams.set(k,v);}
    else url=new URL('/Recruit/Home/_GI_List/','https://'+config.host);
    return {site,keyword:native.params.keyword||native.params.Keyword||'',url:url.href,params:native.params,remote:[config.name+' 양식 조건 그대로'],remoteKey:native.key,urlCovered:['native'],local:[],unsupported:[],limits,coverage:config.name+' 검색과 같은 조건으로 최대 '+limits.maxPages+'페이지·'+limits.maxItems+'건까지 확인합니다.'};
  }
  // 자소설닷컴은 공개 검색(/search)에 채용형태·기업형태·직무·마감 제외를 그대로 보내고, 사이트가 돌려준 목록을 페이지별로 읽는다.
  if(site==='jasoseol'){
    const q=C.jasoseolQuery(filter);if(!q)throw new Error('자소설닷컴: 검색어나 채용형태·기업형태·직무 조건을 하나 이상 저장해주세요.');
    const url=new URL('/search','https://'+config.host);for(const[k,v]of Object.entries(q.params))url.searchParams.set(k,v);
    return {site,keyword:q.params.keyword||'',url:url.href,remote:q.labels,remoteKey:q.key,urlCovered:q.covered,notes:q.notes,local:['roles','locations','career','employment','hiring','education','industry','companyType','exclude'].filter(k=>filter[k]&&!q.covered.includes(k)),unsupported:['nativeUrl','nativeNotes'].filter(k=>filter[k]),limits:{...JASOSEOL_LIMITS},coverage:'자소설닷컴 공개 검색과 같은 조건(마감 공고 제외)으로 최대 '+JASOSEOL_LIMITS.maxPages+'페이지·'+JASOSEOL_LIMITS.maxItems+'건까지 확인합니다.'};
  }
  const keyword=text(C.siteKeywordOf(filter)||filter.roles);if(!keyword||keyword.length>120||/[,，\n]/.test(keyword))throw new Error(config.name+': 120자 이내 검색어 한 개를 저장해주세요.');
  const url=new URL(site==='catch'?'/api/v1.0/recruit/information/getRecruitList':site==='jasoseol'?'/search':'/Search/','https://'+config.host);
  if(site==='catch')for(const[k,v]of Object.entries({Keyword:keyword,curpage:'1',pageSize:'10',onRecruitYN:'Y',Sort:'0'}))url.searchParams.set(k,v);
  const applied=[];
  if(site==='catch'){
    const regions=terms(filter.locations),employment=terms(filter.employment);
    if(regions.length&&regions.every(v=>catchRegions.has(v))){url.searchParams.set('Sido',regions.join(','));applied.push('지역: '+regions.join(', '));}
    if(employment.length&&employment.every(v=>catchEmployment.has(v))){url.searchParams.set('WorkPosition',employment.map(v=>catchEmployment.get(v)).join(','));applied.push('고용형태: '+employment.join(', '));}
  }
  if(site==='jobkorea')url.searchParams.set('stext',keyword);
  return {site,keyword,url:url.href,remote:site==='jasoseol'?['최근 공개 목록 첫 20건']:['검색어',...applied],local:[...(site==='jasoseol'?['keyword']:[]),...['roles','locations','career','employment','education','industry','companyType','exclude'].filter(k=>filter[k])],unsupported:['hiring','nativeUrl','nativeNotes'].filter(k=>filter[k]),coverage:site==='jasoseol'?'원격 검색어 적용 미확인. 최근 공개 첫 20건 안에서만 조건을 확인하며 전체 검색 결과가 아닙니다.':'공개 첫 페이지에서만 최대 10건 확인. 전체 검색 결과를 보장하지 않습니다.'};
}

export function explicitDeadline(value,basis='공개 페이지의 시간대가 명시된 마감 필드를 보존했습니다.') {
  const parts=typeof value==='string'?value.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2})(?:\.\d+)?)?(?:Z|[+-]\d{2}:\d{2})$/):null;
  const calendar=parts?new Date(Date.UTC(+parts[1],+parts[2]-1,+parts[3])):null;
  if(parts&&calendar.getUTCFullYear()===+parts[1]&&calendar.getUTCMonth()===+parts[2]-1&&calendar.getUTCDate()===+parts[3]&&+parts[4]<24&&+parts[5]<60&&+(parts[6]||0)<60&&Number.isFinite(Date.parse(value))) {
    return {at:value,precision:'timestamp',label:new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'}).format(new Date(value))+' KST',basis};
  }
  return {at:null,precision:'unknown',label:text(value)||'미확인',basis:'원문 날짜 표기만 보존했습니다. 시간대·정확한 마감은 추가 확인이 필요합니다.'};
}

export async function parseSiteList(site,page,html,plan) {
  if(site==='catch'){
    const data=JSON.parse(html);if(!Array.isArray(data.recruitData)||!Number.isFinite(data.intTotalRecordCount))throw new Error('캐치 공개 목록 구조를 확인하지 못했습니다.');
    const rows=data.recruitData.filter(r=>Number.isSafeInteger(r.RecruitID)&&r.RecruitID>0&&typeof r.CompName==='string'&&r.CompName.trim()&&typeof r.RecruitTitle==='string'&&r.RecruitTitle.trim()).map(r=>({id:String(r.RecruitID),company:r.CompName,title:r.RecruitTitle,roles:values(r.Depth),locations:values(r.WorkArea),career:values(r.CareerGubunCode),employment:values(r.GubunCode),industry:text(r.RecruitCategory),deadlineSuppressed:Boolean(r.ApplyEndTimeHide||r.ApplyEndCode),deadline:r.ApplyEndTimeHide||r.ApplyEndCode?null:r.ApplyEndDatetime,startAt:r.ApplyStartDatetime||null}));
    if(data.recruitData.length&&!rows.length)throw new Error('캐치 공고 식별자를 확인하지 못했습니다.');return rows;
  }
  await page.setContent(html,{waitUntil:'domcontentloaded'});
  if(site==='jasoseol'){
    const raw=await page.locator('#__NEXT_DATA__').textContent();const data=JSON.parse(raw),query=data.props?.pageProps?.dehydratedState?.queries?.find(q=>q.queryKey?.[0]==='jobSearch');
    if(!Array.isArray(query?.state?.data?.data))throw new Error('자소설닷컴 공개 목록 구조를 확인하지 못했습니다.');
    const rows=query.state.data.data.slice(0,20).filter(r=>Number.isSafeInteger(r.id)&&r.id>0&&typeof r.name==='string'&&r.name.trim()&&typeof r.title==='string'&&r.title.trim()).map(r=>({id:String(r.id),company:r.name,title:r.title,roles:(r.employments||[]).map(e=>text(e.field)).filter(Boolean),education:[...new Set((r.employments||[]).map(e=>text(e.graduate_condition)).filter(Boolean))].join(' / '),deadline:r.end_time}));
    if(query.state.data.data.length&&!rows.length)throw new Error('자소설닷컴 공고 식별자를 확인하지 못했습니다.');return rows;
  }
  const rows=await page.locator('a[data-sentry-component="Title"][href*="/Recruit/GI_Read/"]').evaluateAll(es=>es.slice(0,100).map(a=>{const box=a.parentElement?.parentElement;return {id:a.getAttribute('href')?.match(/\/GI_Read\/(\d+)/)?.[1],title:a.textContent.trim(),company:a.parentElement.nextElementSibling?.querySelector('a > span')?.textContent.trim(),locations:[...box.querySelectorAll('[data-sentry-component="GrayChip"]')].filter(e=>e.querySelector('[class*="emoji--basicemoji-place"]')).map(e=>e.textContent.trim()),roles:[...box.querySelectorAll('[data-sentry-component="GrayChip"]')].filter(e=>e.querySelector('[class*="emoji--basicemoji-briefcase"]')).map(e=>e.textContent.trim())};}));
  if(!rows.length&&!/검색 결과가 없습니다|검색결과가 없습니다/.test(await page.locator('body').textContent()))throw new Error('잡코리아 목록 구조를 확인하지 못했습니다. 0건으로 처리하지 않았습니다.');
  const valid=rows.filter(r=>r.id&&r.company&&r.title);if(rows.length&&!valid.length)throw new Error('잡코리아 회사·공고 식별자를 확인하지 못했습니다.');return valid;
}

export async function readJobPosting(page,html){
  await page.setContent(html,{waitUntil:'domcontentloaded'});
  const raw=await page.locator('script[type="application/ld+json"]').allTextContents();
  const find=value=>{if(!value||typeof value!=='object')return null;if(value['@type']==='JobPosting'||value['@type']?.includes?.('JobPosting'))return value;for(const item of Array.isArray(value)?value:(value['@graph']||[])){const result=find(item);if(result)return result;}return null;};
  for(const item of raw){try{const result=find(JSON.parse(item));if(result)return result;}catch{}}
  throw new Error('공개 상세의 채용 구조화 요약을 확인하지 못했습니다.');
}

export async function collectPublicSite(site,{filter,runtime,runId,signal,progress=()=>{},limit=10,fetcher,browserFactory=launchBrowser,directUrls=null}) {
  if(directUrls&&site!=='jasoseol')throw new Error('주소 추가는 자소설닷컴 공개 공고만 지원합니다.');
  const plan=directUrls?directJasoseolPlan(filter,directUrls):sitePlan(site,filter),config=publicSites[site],dir=path.join(runtime,'sources',runId);await fs.mkdir(dir,{recursive:true});
  const checkedAt=new Date().toISOString();progress(config.name+(directUrls?' 지정한 공개 공고 확인 중':' 공개 목록 확인 중'),{phase:'list',completed:0,total:null});
  let listing=null;const extension=site==='catch'?'json':'html';
  if(directUrls)await fs.writeFile(path.join(dir,'requested-urls.json'),JSON.stringify(plan,null,2));
  else if(plan.remoteKey&&(site==='catch'||site==='jobkorea')){
    const all=[];let total=0,pages=0,stopMessage=null;
    for(let p=1;p<=plan.limits.maxPages;p++){
      signal?.throwIfAborted();progress(config.name+' 검색 '+p+'페이지 확인 중',{phase:'list',completed:p-1,total:null});let read;
      if(site==='catch'){const url=new URL(plan.url);url.searchParams.set('curpage',String(p));const res=await fetchPublic(url.href,{signal,fetcher,site});await fs.writeFile(path.join(dir,p===1?'search.json':'search-'+p+'.json'),res.html);const data=JSON.parse(res.html);const rows=await parseSiteList('catch',null,res.html,plan);read={rows,total:data.intTotalRecordCount};}
      else{const body=new URLSearchParams();for(const[k,v]of Object.entries(plan.params))body.set('condition['+k+']',v);body.set('page',String(p));body.set('pagesize',String(plan.limits.perPage));body.set('tabindex','0');
        const post=(u,o)=>(fetcher||fetch)(u,{...o,method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest',Referer:'https://www.jobkorea.co.kr/recruit/joblist?menucode=duty'},body:body.toString()});
        const res=await fetchPublic(plan.url,{signal,fetcher:post,site});await fs.writeFile(path.join(dir,p===1?'search.html':'search-'+p+'.html'),res.html);read=readJobkoreaList(res.html);}
      total=read.total;pages=p;const before=all.length;for(const r of read.rows)if(!all.some(x=>x.id===r.id))all.push(r);
      if(all.length>=total||!read.rows.length||all.length===before)break;if(all.length>=plan.limits.maxItems){stopMessage='상한('+plan.limits.maxPages+'페이지·'+plan.limits.maxItems+'건)까지만 확인했습니다.';break;}
      if(p<plan.limits.maxPages)await pause(plan.limits.pageDelayMs,undefined,{signal});else if(all.length<total)stopMessage='상한('+plan.limits.maxPages+'페이지·'+plan.limits.maxItems+'건)까지만 확인했습니다.';
    }
    listing={rows:all.slice(0,plan.limits.maxItems)};plan.scan={siteTotal:total,pagesRead:pages,unique:listing.rows.length,complete:listing.rows.length>=total,stopMessage};
  }
  else if(site==='jasoseol'){
    const all=[];let total=0,pages=0,stopMessage=null;
    for(let p=1;p<=plan.limits.maxPages;p++){
      signal?.throwIfAborted();const url=new URL(plan.url);url.searchParams.set('page',String(p));progress(config.name+' 공개 검색 '+p+'페이지 확인 중',{phase:'list',completed:p-1,total:null});
      const res=await fetchPublic(url.href,{signal,fetcher,site});await fs.writeFile(path.join(dir,p===1?'search.html':'search-'+p+'.html'),res.html);
      const read=readJasoseolSearch(res.html);if(read.page!==undefined&&read.page!==p){stopMessage=p+'페이지 요청이 다른 페이지로 응답되어 멈췄습니다.';break;}
      total=read.total;pages=p;const before=all.length;for(const r of read.rows)if(!all.some(x=>x.id===r.id))all.push(r);
      if(all.length>=total||!read.rows.length||all.length===before)break;if(all.length>=plan.limits.maxItems){stopMessage='상한('+plan.limits.maxPages+'페이지·'+plan.limits.maxItems+'건)까지만 확인했습니다.';break;}
      if(p<plan.limits.maxPages)await pause(plan.limits.pageDelayMs,undefined,{signal});else if(all.length<total)stopMessage='상한('+plan.limits.maxPages+'페이지·'+plan.limits.maxItems+'건)까지만 확인했습니다.';
    }
    listing={rows:all.slice(0,plan.limits.maxItems)};plan.scan={siteTotal:total,pagesRead:pages,unique:listing.rows.length,complete:listing.rows.length>=total,stopMessage};
  }
  else{listing=await fetchPublic(plan.url,{signal,fetcher,site});await fs.writeFile(path.join(dir,'search.'+extension),listing.html);}
  const browser=await browserFactory(),abort=()=>{void browser.close().catch(()=>{});};signal?.addEventListener('abort',abort,{once:true});
  try{
    signal?.throwIfAborted();const context=await browser.newContext({javaScriptEnabled:false,serviceWorkers:'block'});await context.route('**/*',r=>r.abort());const page=await context.newPage();
    const candidates=directUrls?plan.urls.map(url=>({id:new URL(url).pathname.split('/').pop(),roles:[]})):listing.rows||await parseSiteList(site,page,listing.html,plan),seen=new Set();
    const rows=candidates.filter(r=>{if(seen.has(r.id))return false;seen.add(r.id);return directUrls||site==='catch'||plan.remoteKey||[r.company,r.title,...(r.roles||[])].join(' ').toLocaleLowerCase('ko').includes(plan.keyword.toLocaleLowerCase('ko'));}).slice(0,plan.limits?.maxItems||Math.max(1,Math.min(10,limit)));
    const records=[];
    for(const row of rows){
      signal?.throwIfAborted();const url='https://'+config.host+(site==='catch'?'/NCS/RecruitInfoDetails/':site==='jasoseol'?'/recruit/':'/Recruit/GI_Read/')+row.id;
      progress(config.name+` 상세 확인 ${records.length+1}/${rows.length}`,{phase:'detail',completed:records.length,total:rows.length});await pause(800,undefined,{signal});
      let posting=null,error=null,detailText='',mainSaved=false,bodySaved=false,bodyKind='summary',bodyImages=0,imageOcr=null;
      try{
        const detail=await fetchPublic(url,{signal,fetcher,site});if(new URL(detail.url).pathname.replace(/\/$/,'').toLowerCase()!==new URL(url).pathname.toLowerCase())throw new Error('상세 주소가 바뀌어 공고 식별자를 다시 확인해야 합니다.');await fs.writeFile(path.join(dir,row.id+'.html'),detail.html);mainSaved=true;posting=await readJobPosting(page,detail.html);
        if(directUrls){const node=page.locator('#__NEXT_DATA__'),data=await node.count()?JSON.parse(await node.textContent()).props?.pageProps?.initialEmploymentCompany:null;if(data&&String(data.id)!==row.id)throw new Error('지정한 공고와 페이지의 식별자가 다릅니다.');row.company=text(data?.name)||text(posting.hiringOrganization?.name);row.title=text(data?.title)||text(posting.title);if(!row.company||!row.title)throw new Error('지정한 공고의 회사·제목을 확인하지 못했습니다.');if(data&&String(data.id)===row.id){row.roles=(data.employments||[]).map(e=>text(e.field)).filter(Boolean);row.deadline=data.end_time;row.education=[...new Set((data.employments||[]).map(e=>text(e.graduate_condition)).filter(Boolean))].join(' / ');}}
        const body=await readPublicBody({site,id:row.id,page,html:detail.html,signal,fetcher});
        if(body){await fs.writeFile(path.join(dir,row.id+'-body.html'),body.html);bodySaved=true;await page.setContent(body.html,{waitUntil:'domcontentloaded'});const images=await page.locator('img').count();bodyImages=images;await page.locator('script,style,noscript').evaluateAll(es=>es.forEach(e=>e.remove()));detailText=(await page.locator('body').innerText()).trim().slice(0,24000);bodyKind=detailText?'body-text':images?'image-body':'empty-body';}
        if(!detailText){const description=text(posting.description);if(/<[a-z][^>]*>/i.test(description)){await page.setContent(description,{waitUntil:'domcontentloaded'});detailText=(await page.locator('body').innerText()).slice(0,24000);}else detailText=description.slice(0,24000);}
      }
      catch(e){signal?.throwIfAborted();if(directUrls)throw new Error('지정 공고 '+row.id+' 확인 실패 · 이번 주소 묶음을 적용하지 않았습니다. '+e.message);error=e.message;}
      if(bodySaved||/<img\b/i.test(text(posting?.description))){const bodyHtml=bodySaved?await fs.readFile(path.join(dir,row.id+'-body.html'),'utf8'):text(posting.description);imageOcr=await recognizeHtmlImages({html:bodyHtml,base:url,signal});}
      const location=posting?.jobLocation;const addresses=(Array.isArray(location)?location:location?[location]:[]).map(l=>[l.address?.addressRegion,l.address?.addressLocality,l.address?.streetAddress].filter(Boolean).join(' ')).filter(Boolean);
      const record={id:site+'-'+row.id,company:row.company,title:row.title,roles:row.roles?.length?row.roles:['미확인'],locations:addresses.length?addresses:row.locations?.length?row.locations:['미확인'],career:row.career?.length&&plan.remoteKey?row.career:values(posting?.experienceRequirements).length?values(posting.experienceRequirements):row.career?.length?row.career:['미확인'],employment:row.employment?.length?row.employment:['미확인'],education:text(posting?.educationRequirements)||row.education||'미확인',industry:row.industry||'미확인',companyType:row.companyType||'미확인',required:['직무별 필수 자격은 원문 확인 필요'],preferred:['우대 조건 미확인'],stages:['전형 절차 미확인'],documents:['제출 서류 미확인'],prep:['원문에서 부문별 자격·마감·제출 서류 확인'],deadline:row.deadlineSuppressed?{at:null,precision:'unknown',label:'원 사이트 마감시각 미표시',basis:'사이트에서 마감시각을 숨겼으므로 구조화 데이터의 날짜로 확정하지 않았습니다.'}:explicitDeadline(row.deadline||posting?.validThrough),sources:[{site:config.name,url,checkedAt,official:false,status:mainSaved?200:null,scope:error?'공개 상세 확인 중 실패 · 이전 자료 대조 필요':bodyKind==='body-text'?'공개 목록·상세 요약·본문 텍스트 확인 · 이미지 해석 미수행':bodyKind==='image-body'?'공개 목록·상세 요약 확인 · 본문은 이미지로 제공되어 해석 미수행':'공개 목록·상세 구조화 요약 확인 · 본문 해석 미수행',evidenceFile:'.runtime/jobs/sources/'+runId+'/'+(mainSaved?row.id+'.html':'search.'+extension),bodyEvidenceFile:bodySaved?'.runtime/jobs/sources/'+runId+'/'+row.id+'-body.html':null}],checkedAt,bodyImages,detailScope:bodyKind,detailCheckedAt:error?null:checkedAt,detailFetch:{status:error?'failed':'success',error},originalUrl:url,officialStatus:config.name+' 게시물 확인 · 기업 공식 원문 별도 대조 미수행',evidenceNotes:[plan.coverage,error||(bodyKind==='body-text'?'공개 본문의 명시적 표제만 정리했습니다. 이미지·자동 자격 판정은 수행하지 않았습니다.':bodyKind==='image-body'?'본문은 이미지로 제공되어 OCR 없이 미확인으로 남겼습니다.':'구조화 요약만 확인했습니다. 이미지 요강은 해석하지 않았습니다.')],eligibility:{status:'보류',reason:'개인 조건과 직무별 상세 자격 확인 필요',missing:['개인 지원 조건','상세 자격']},review:'추가 확인',reason:'공개 목록 수집 · 상세 자격은 확인 필요',detailText,partial:true,discoveredAt:checkedAt,...(row.startAt?{startAt:row.startAt}:{}),...(plan.remoteKey?{remoteMatches:[{key:plan.remoteKey,fields:plan.urlCovered,checkedAt}]}:{})};
      if(imageOcr){record.imageOcr=imageOcr;if(imageOcr.text){record.evidenceNotes.push('이미지 글자 인식: Windows 한국어 OCR · 오독 가능, 원문 대조 필요');record.sources[0].scope+=' · 이미지 OCR 텍스트 별도 보관';}}
      const extracted=extractRequirements(detailText);for(const item of Object.values(extracted.evidence)){item.sourceFile=record.detailScope==='body-text'?(record.sources[0].bodyEvidenceFile||record.sources[0].evidenceFile):record.sources[0].evidenceFile;item.checkedAt=checkedAt;}Object.assign(record,extracted.fields,{requirementsEvidence:extracted.evidence,extractionMethod:extracted.method});
      await fs.writeFile(path.join(dir,row.id+'.json'),JSON.stringify(record,null,2));records.push(record);
      progress(config.name+` 상세 확인 ${records.length}/${rows.length}건 처리`,{phase:'detail',completed:records.length,total:rows.length});
    }
    await fs.writeFile(path.join(dir,'manifest.json'),JSON.stringify({checkedAt,plan,candidates:candidates.length,count:records.length},null,2));return {records,checkedAt,plan,candidates:candidates.length,...(plan.scan?{scan:plan.scan}:{})};
  }finally{signal?.removeEventListener('abort',abort);await browser.close();}
}
