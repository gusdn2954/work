import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import http from 'node:http';
import {createJobsApp,mergedRecords,duplicateCandidates} from './server.mjs';
import {searchPlan,fetchPublic} from './saramin.mjs';
import {inspectWorkspace,restorePrevious} from './recover.mjs';

const source=new URL('./',import.meta.url);
async function fixture(t,collector,options={}){
  const base=path.resolve(os.tmpdir(),'local-job-desk-tests');await fs.mkdir(base,{recursive:true});const root=await fs.mkdtemp(path.join(base,'case-'));await fs.mkdir(path.join(root,'jobs'));
  for(const name of ['data.json','settings-schema.json','search-settings.json'])await fs.copyFile(new URL(name==='data.json'?'fixtures/public-sample.json':name==='search-settings.json'?'fixtures/test-settings.json':name,source),path.join(root,'jobs',name));
  let app=await createJobsApp({root,...collector?{collector}:{},...options});await new Promise(resolve=>app.server.listen(0,'127.0.0.1',resolve));let url='http://127.0.0.1:'+app.server.address().port;
  const api=async(route,data,headers={})=>{const response=await fetch(url+route,{...(data===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json',...headers},body:JSON.stringify(data)}),...data===undefined?{headers}:{}});return {status:response.status,data:await response.json()};};
  t.after(async()=>{await app.close();const rel=path.relative(base,root);assert.ok(rel&&!rel.startsWith('..')&&!path.isAbsolute(rel));await fs.rm(root,{recursive:true,force:true});});
  return {root,api,get app(){return app;},get url(){return url;},async restart(){await app.close();app=await createJobsApp({root,...collector?{collector}:{},...options});await new Promise(resolve=>app.server.listen(0,'127.0.0.1',resolve));url='http://127.0.0.1:'+app.server.address().port;}};
}
async function saveKeyword(f){const {data}=await f.api('/api/state');data.settings.sites.saramin.keyword='데이터';return f.api('/api/preferences',{revision:data.revision,profile:data.profile,settings:data.settings});}
async function waitDone(f){for(let i=0;i<100;i++){const {data}=await f.api('/api/state');if(!data.active)return data;await new Promise(r=>setTimeout(r,10));}throw new Error('수집 완료 대기 초과');}
async function waitBatch(f){for(let i=0;i<200;i++){const {data}=await f.api('/api/state');if(!data.batchActive)return data;await new Promise(r=>setTimeout(r,10));}throw new Error('여러 사이트 수집 완료 대기 초과');}
async function saveBatchKeywords(f,sites){const {data}=await f.api('/api/state');for(const site of sites)data.settings.sites[site].keyword='검증';return (await f.api('/api/preferences',{revision:data.revision,profile:data.profile,settings:data.settings})).data;}
function record(){return {id:'saramin-123',company:'가상 검증 기업',title:'가상 검증 공고',roles:['분석'],locations:['서울'],career:['신입'],education:'미확인',employment:['정규직'],required:['미확인'],preferred:['미확인'],stages:['미확인'],documents:['미확인'],prep:['원문 확인'],deadline:{at:null,label:'마감 미확인'},sources:[{site:'사람인',url:'https://www.saramin.co.kr/zf_user/jobs/relay/view-detail?rec_idx=123'}],partial:true,checkedAt:new Date().toISOString(),discoveredAt:new Date().toISOString(),eligibility:{status:'보류',reason:'검증 표본'}};}

test('40회 이전 실행도 보관하고 새 실행·재시작 뒤 이전 페이지를 중복 없이 이어 읽는다',async t=>{
  const f=await fixture(t,async()=>({records:[],plan:{}}));await saveKeyword(f);
  for(let i=0;i<43;i++){assert.equal((await f.api('/api/collect',{})).status,202);await waitDone(f);}
  assert.equal(f.app.snapshot().runs.length,40);
  const first=(await f.api('/api/history')).data;assert.equal(first.total,43);assert.equal(first.runs.length,20);
  await f.api('/api/collect',{});await waitDone(f);await f.restart();
  const second=(await f.api('/api/history?cursor='+first.nextCursor)).data,third=(await f.api('/api/history?cursor='+second.nextCursor)).data;
  assert.equal(second.total,44);assert.equal(third.nextCursor,null);
  const ids=[...first.runs,...second.runs,...third.runs].map(r=>r.id);assert.equal(ids.length,43);assert.equal(new Set(ids).size,43);
  assert.equal((await f.api('/api/history?cursor=invalid')).status,400);
  assert.equal((await f.api('/api/history',undefined,{'X-Job-Desk-Project':'other'})).status,409);
});

test('과거 실행 보관에 실패하면 기록을 버리거나 다음 수집을 시작하지 않는다',async t=>{
  let calls=0;const f=await fixture(t,async()=>{calls++;return {records:[],plan:{}};});await saveKeyword(f);
  for(let i=0;i<40;i++){await f.api('/api/collect',{});await waitDone(f);}
  const before=f.app.snapshot().runs.map(r=>r.id);await fs.writeFile(path.join(f.root,'.runtime/jobs/history'),'보관 실패 재현');
  assert.equal((await f.api('/api/collect',{})).status,500);assert.equal(calls,40);assert.deepEqual(f.app.snapshot().runs.map(r=>r.id),before);assert.equal(f.app.snapshot().active,null);
});

test('조건은 재시작 후 유지되고 이전 원본 파일을 변경하지 않는다',async t=>{
  const f=await fixture(t),before=await fs.readFile(path.join(f.root,'jobs','search-settings.json'),'utf8');
  const saved=await saveKeyword(f);assert.equal(saved.status,200);assert.equal(saved.data.revision,1);
  await f.restart();assert.equal((await f.api('/api/state')).data.settings.sites.saramin.keyword,'데이터');assert.equal(await fs.readFile(path.join(f.root,'jobs','search-settings.json'),'utf8'),before);
  assert.equal((await f.api('/api/state')).data.data.records.length,8);
});
test('겹치는 저장과 외부 출처·잘못된 JSON 형식 요청을 거부한다',async t=>{
  const f=await fixture(t);const {data}=await f.api('/api/state');const payload={revision:data.revision,settings:data.settings,profile:data.profile};
  const results=await Promise.all([f.api('/api/preferences',payload),f.api('/api/preferences',payload)]);assert.deepEqual(results.map(r=>r.status).sort(),[200,409]);
  assert.equal((await f.api('/api/collect',{}, {Origin:'https://attacker.example'})).status,403);
  assert.equal((await f.api('/api/collect',{}, {'Content-Type':'text/plain'})).status,415);
  const hostStatus=await new Promise((resolve,reject)=>{const req=http.request(f.url+'/api/health',{headers:{host:'attacker.example'}},res=>{res.resume();resolve(res.statusCode);});req.on('error',reject);req.end();});assert.equal(hostStatus,403);
});
test('네트워크 조각 경계에 걸린 한글도 손상 없이 저장한다',async t=>{
  const f=await fixture(t);const {data}=await f.api('/api/state');data.profile.credentials='한글 자격 조건';
  const bytes=Buffer.from(JSON.stringify({revision:data.revision,profile:data.profile,settings:data.settings})),split=bytes.indexOf(Buffer.from('한글'))+1;
  const status=await new Promise((resolve,reject)=>{const req=http.request(f.url+'/api/preferences',{method:'POST',headers:{'Content-Type':'application/json','Content-Length':bytes.length}},res=>{res.resume();resolve(res.statusCode);});req.on('error',reject);req.flushHeaders();req.write(bytes.subarray(0,split));setTimeout(()=>req.end(bytes.subarray(split)),10);});
  assert.equal(status,200);assert.equal((await f.api('/api/state')).data.profile.credentials,'한글 자격 조건');
});
test('재수집은 같은 사이트 공고 ID를 중복 추가하지 않는다',async t=>{
  const f=await fixture(t,async()=>({records:[record()],plan:{remote:['검색어']},checkedAt:new Date().toISOString()}));await saveKeyword(f);
  for(let i=0;i<2;i++){assert.equal((await f.api('/api/collect',{})).status,202);await waitDone(f);}
  const data=(await f.api('/api/state')).data;assert.equal(data.data.records.length,9);assert.equal(data.runs.length,2);assert.equal(data.runs[0].added,0);assert.equal(data.runs[0].updated,1);
  await f.restart();assert.equal((await f.api('/api/state')).data.data.records.length,9);
});
test('수집이 끝까지 성공하면 마감·사이트에서 사라진 공고를 정리하고 지운 목록을 남긴다',async t=>{
  const open=new Date(Date.now()+5*86400000).toISOString(),closed=new Date(Date.now()-86400000).toISOString();
  const mk=(n,at)=>({...record(),id:'saramin-'+n,title:'정리 검사 '+n,deadline:{at,precision:'minute',label:'마감'},sources:[{site:'사람인',url:'https://www.saramin.co.kr/zf_user/jobs/relay/view?rec_idx='+n,checkedAt:new Date().toISOString(),official:false}]});
  let round=0;const f=await fixture(t,async()=>{round++;const records=round===1?[mk(901,open),mk(902,open),mk(903,open),mk(904,closed)]:[mk(901,open),mk(902,open)];return {records,plan:{remote:['검색어']},scan:{siteTotal:records.length,unique:records.length,complete:true,stopMessage:null},checkedAt:new Date().toISOString()};});await saveKeyword(f);
  assert.equal((await f.api('/api/collect',{})).status,202);await waitDone(f);
  let data=(await f.api('/api/state')).data;assert.equal(data.data.records.filter(r=>r.id.startsWith('saramin-9')).length,4);
  assert.equal((await f.api('/api/collect',{})).status,202);data=await waitDone(f);
  const ids=data.data.records.filter(r=>r.id.startsWith('saramin-9')).map(r=>r.id).sort();assert.deepEqual(ids,['saramin-901','saramin-902']);
  assert.match(data.runs[0].message,/정리 2건/);const dir=path.join(f.root,'.runtime','jobs','cleanup-log'),files=await fs.readdir(dir);assert.equal(files.length,1);
  const log=JSON.parse(await fs.readFile(path.join(dir,files[0]),'utf8'));assert.deepEqual(log.removed.map(x=>x.record.id).sort(),['saramin-903','saramin-904']);
});
test('목록을 끝까지 읽지 못한 수집은 저장 공고를 정리하지 않는다',async t=>{
  const open=new Date(Date.now()+5*86400000).toISOString();const mk=n=>({...record(),id:'saramin-'+n,title:'미완료 검사 '+n,deadline:{at:open,precision:'minute',label:'마감'},sources:[{site:'사람인',url:'https://www.saramin.co.kr/zf_user/jobs/relay/view?rec_idx='+n,checkedAt:new Date().toISOString(),official:false}]});
  let round=0;const f=await fixture(t,async()=>{round++;const records=round===1?[mk(911),mk(912),mk(913)]:[mk(911)];return {records,plan:{remote:['검색어']},scan:{siteTotal:5,unique:records.length,complete:false,stopMessage:'상한까지만 확인했습니다.'},checkedAt:new Date().toISOString()};});await saveKeyword(f);
  for(let i=0;i<2;i++){assert.equal((await f.api('/api/collect',{})).status,202);await waitDone(f);}
  const data=(await f.api('/api/state')).data;assert.equal(data.data.records.filter(r=>r.id.startsWith('saramin-91')).length,3);assert.match(data.runs[0].message,/끝까지 읽지 못해/);
});
test('중지 완료 후에만 다음 수집을 허용하고 미완료 결과는 반영하지 않는다',async t=>{
  let release;const f=await fixture(t,async({signal})=>{await new Promise(resolve=>{release=resolve;signal.addEventListener('abort',()=>setTimeout(resolve,40),{once:true});});signal.throwIfAborted();return {records:[record()]};});await saveKeyword(f);
  const start=await f.api('/api/collect',{});while(!release)await new Promise(r=>setTimeout(r,1));
  assert.equal((await f.api('/api/collect',{})).status,409);assert.equal((await f.api('/api/stop',{id:'wrong'})).status,409);
  assert.equal((await f.api('/api/stop',{id:start.data.id})).data.status,'stopping');assert.equal((await f.api('/api/collect',{})).status,409);
  const data=await waitDone(f);assert.equal(data.runs[0].status,'stopped');assert.equal(data.data.records.length,8);
});
test('수집 오류·비어 있는 검색어가 기존 공고를 지우지 않는다',async t=>{
  const f=await fixture(t,async()=>{throw new Error('시험용 조회 실패');});assert.equal((await f.api('/api/collect',{})).status,400);await saveKeyword(f);await f.api('/api/collect',{});const data=await waitDone(f);assert.equal(data.runs[0].status,'failed');assert.equal(data.data.records.length,8);
});
test('시작 기록 저장 실패는 500으로 응답하고 수집기를 실행하지 않는다',async t=>{
  let calls=0;const f=await fixture(t,async()=>{calls++;return {records:[]};});await saveKeyword(f);
  const file=path.join(f.root,'.runtime/jobs/workspace.json'),backup=file+'.preserved';await fs.rename(file,backup);await fs.mkdir(file);
  try {const r=await f.api('/api/collect',{});assert.equal(r.status,500);assert.match(r.data.error,/시작하지/);assert.equal(calls,0);assert.equal(f.app.snapshot().active,null);assert.equal(f.app.snapshot().runs.length,0);}
  finally {await fs.rmdir(file);await fs.rename(backup,file);}
  assert.equal((await f.api('/api/state')).data.data.records.length,8);
});
test('자동으로 수집한 불완전한 목록은 수동 확인된 상세를 덮어쓰지 않는다',()=>{
  const newRow=record(),seed={...record(),id:'manual',partial:false,required:['실제 대조한 필수조건'],deadline:{at:'2026-11-01T18:00:00+09:00',label:'확인된 마감'}};const result=mergedRecords([seed],[newRow]);assert.equal(result.length,1);assert.deepEqual(result[0].required,seed.required);assert.equal(result[0].deadline.at,seed.deadline.at);assert.equal(result[0].latestObservation.title,newRow.title);
});
test('사람인 보기·상세보기·추적변수 주소가 달라도 같은 게시물은 병합한다',()=>{
  const seed={...record(),id:'manual',partial:false,sources:[{site:'사람인',url:'https://www.saramin.co.kr/zf_user/jobs/relay/view?rec_idx=123&tracking=old'}]};
  const rows=mergedRecords([seed],[record()]);assert.equal(rows.length,1);assert.equal(rows[0].id,'manual');assert.ok(rows[0].latestObservation);
});
test('다른 출처의 동일 회사·제목은 중복 후보로만 표시하고 실제 목록을 합치지 않는다',()=>{
  const a={...record(),id:'a'},b={...record(),id:'b',company:'(주)'+record().company},c={...record(),id:'c',title:record().title+' 다른 부문'};
  const rows=[a,b,c];assert.deepEqual(duplicateCandidates(rows),{a:['b'],b:['a']});assert.equal(rows.length,3);
});
test('검색어만 원격 적용하고 다른 조건의 적용 범위를 명시한다',()=>{
  const plan=searchPlan({enabled:true,keyword:'데이터',locations:'서울',nativeNotes:'급여 조건'});assert.equal(new URL(plan.url).searchParams.get('searchword'),'데이터');assert.deepEqual(plan.local,['locations']);assert.deepEqual(plan.unsupported,['nativeNotes']);assert.throws(()=>searchPlan({enabled:true,keyword:'물류,분석'}));
});
test('공개 수집은 외부 리디렉션·오류·크기 초과 응답을 중단한다',async()=>{
  await assert.rejects(fetchPublic('https://www.saramin.co.kr/zf_user/search',{fetcher:async()=>new Response('',{status:302,headers:{location:'https://attacker.example/'}})}),/허용/);
  await assert.rejects(fetchPublic('https://www.saramin.co.kr/',{fetcher:async()=>new Response('',{status:403})}),/403/);
  await assert.rejects(fetchPublic('https://www.saramin.co.kr/',{fetcher:async()=>new Response('',{headers:{'content-length':'99999999'}})}),/상한/);
});

test('예약은 기본 꺼짐·유효한 조건과 주기를 저장한 뒤 예정 시각에 사이트별로 순서대로 실행한다',async t=>{
  const calls=[],collect=site=>async()=>{calls.push(site);return {records:[],plan:{},checkedAt:new Date().toISOString()};};
  const f=await fixture(t,collect('saramin'),{collectors:{catch:collect('catch')}});
  assert.equal(f.app.snapshot().schedule.enabled,false);assert.equal(await f.app.runScheduled(Date.now()+99999999),false);assert.deepEqual(calls,[]);
  let data=(await f.api('/api/state')).data;
  assert.equal((await f.api('/api/schedule',{revision:data.revision,schedule:{enabled:true,sites:['saramin'],intervalMinutes:1}})).status,400);
  assert.equal((await f.api('/api/schedule',{revision:data.revision,schedule:{enabled:true,sites:['saramin'],intervalMinutes:30}})).status,400);
  data.settings.sites.saramin.keyword='검증';data.settings.sites.catch.keyword='검증';
  data=(await f.api('/api/preferences',{revision:data.revision,profile:data.profile,settings:data.settings})).data;
  const config={enabled:true,sites:['catch','saramin'],intervalMinutes:30};
  const saved=await f.api('/api/schedule',{revision:data.revision,schedule:config});assert.equal(saved.status,200);
  const due=Date.parse(saved.data.schedule.nextRunAt);assert.equal(await f.app.runScheduled(due-1),false);assert.equal(await f.app.runScheduled(due),true);assert.deepEqual(calls,['catch','saramin']);
  assert.ok(f.app.snapshot().runs.every(r=>r.trigger==='scheduled'));assert.equal(Date.parse(f.app.snapshot().schedule.nextRunAt),due+1800000);
  await f.restart();assert.equal(f.app.snapshot().schedule.enabled,true);assert.equal(await f.app.runScheduled(due),false);
  data=(await f.api('/api/state')).data;assert.equal((await f.api('/api/schedule',{revision:data.revision,schedule:{...config,enabled:false}})).status,200);assert.equal(await f.app.runScheduled(due+99999999),false);assert.deepEqual(calls,['catch','saramin']);
});
test('예약 수집의 중지는 현재 수집 종료를 기다리고 같은 회차의 나머지 사이트도 시작하지 않는다',async t=>{
  let started=false,other=0;
  const f=await fixture(t,async({signal})=>{started=true;await new Promise(resolve=>signal.addEventListener('abort',()=>setTimeout(resolve,30),{once:true}));signal.throwIfAborted();},{collectors:{catch:async()=>{other++;return {records:[]};}}});
  let data=(await saveKeyword(f)).data;data.settings.sites.catch.keyword='검증';data=(await f.api('/api/preferences',{revision:data.revision,profile:data.profile,settings:data.settings})).data;
  const saved=await f.api('/api/schedule',{revision:data.revision,schedule:{enabled:true,sites:['saramin','catch'],intervalMinutes:30}}),due=Date.parse(saved.data.schedule.nextRunAt);
  const running=f.app.runScheduled(due);while(!started)await new Promise(r=>setTimeout(r,1));
  const id=f.app.snapshot().active.id;assert.equal((await f.api('/api/stop',{id})).status,202);await running;
  assert.equal(f.app.snapshot().active,null);assert.equal(f.app.snapshot().runs[0].status,'stopped');assert.equal(other,0);
});
test('알림 읽음 처리는 요청 뒤 새로 도착한 알림을 읽음으로 바꾸지 않고 재시작에도 유지한다',async t=>{
  let calls=0;const f=await fixture(t,async()=>{if(++calls===2)throw new Error('검증용 실패');return {records:[record()],plan:{},checkedAt:new Date().toISOString()};});await saveKeyword(f);
  await f.api('/api/collect',{});await waitDone(f);const first=f.app.snapshot().notifications[0].id;
  await f.api('/api/collect',{});await waitDone(f);assert.equal(f.app.snapshot().notifications.length,2);
  assert.equal((await f.api('/api/notifications/read',{upTo:first})).status,200);assert.equal(f.app.snapshot().notifications[0].read,false);assert.equal(f.app.snapshot().notifications[1].read,true);
  assert.equal((await f.api('/api/notifications/read',{upTo:'unknown'})).status,409);await f.restart();assert.equal(f.app.snapshot().notifications[0].read,false);assert.equal(f.app.snapshot().notifications[1].read,true);
});
test('명시된 마감만 7일 알림을 만들고 같은 마감은 반복 알리지 않는다',async t=>{
  const row=record();row.deadline={at:new Date(Date.now()+2*86400000).toISOString(),precision:'timestamp',label:'시험용 시각'};
  const f=await fixture(t,async()=>({records:[row],plan:{},checkedAt:new Date().toISOString()}));await saveKeyword(f);await f.api('/api/collect',{});await waitDone(f);
  assert.ok(await f.app.checkDeadlines()>0);assert.equal(f.app.snapshot().notifications.filter(n=>n.type==='deadline'&&n.recordId===row.id).length,1);assert.equal(await f.app.checkDeadlines(),0);
  await f.restart();assert.equal(await f.app.checkDeadlines(),0);
});
test('공고별 준비 메모·체크는 재시작에 보존되고 겹치는 저장과 미확인 서류 완료를 거부한다',async t=>{
  const row={...record(),documents:['지원서','포트폴리오','기타 미확인']};const f=await fixture(t,async()=>({records:[row],plan:{},checkedAt:new Date().toISOString()}));await saveKeyword(f);await f.api('/api/collect',{});await waitDone(f);
  const before=f.app.snapshot().revision,payload={id:row.id,revision:0,notes:'한국어 준비 메모',checkedTasks:['원문 확인'],checkedDocuments:['지원서']};
  let saved=await f.api('/api/annotation',payload);assert.equal(saved.status,200);assert.equal(saved.data.annotations[row.id].revision,1);assert.equal(saved.data.revision,before);
  assert.equal((await f.api('/api/annotation',{...payload,revision:1,checkedDocuments:['기타 미확인']})).status,409);
  const results=await Promise.all(['A','B'].map(notes=>f.api('/api/annotation',{...payload,revision:1,notes})));assert.deepEqual(results.map(r=>r.status).sort(),[200,409]);const accepted=results.find(r=>r.status===200).data.annotations[row.id];
  await f.restart();assert.deepEqual(f.app.snapshot().annotations[row.id],accepted);assert.equal((await f.api('/api/annotation',{...payload,id:'not-found'})).status,404);
});
test('손상된 저장본은 원본을 보관한 뒤 유효한 이전 저장본으로만 명시적으로 복원한다',async t=>{
  const f=await fixture(t);let data=(await saveKeyword(f)).data;data.profile.credentials='마지막 변경';await f.api('/api/preferences',{revision:data.revision,settings:data.settings,profile:data.profile});await f.app.close();
  const file=path.join(f.root,'.runtime/jobs/workspace.json'),broken='{"broken":';await fs.writeFile(file,broken);const status=await inspectWorkspace(f.root);assert.equal(status['workspace.json'].valid,false);assert.equal(status['workspace.previous.json'].valid,true);
  const result=await restorePrevious(f.root);assert.equal(await fs.readFile(result.preserved,'utf8'),broken);await f.restart();assert.equal(f.app.snapshot().settings.sites.saramin.keyword,'데이터');assert.equal(f.app.snapshot().profile.credentials,'');
});
test('이전 저장본도 손상됐거나 서버 PID가 살아 있으면 복원으로 현재 파일을 바꾸지 않는다',async t=>{
  const f=await fixture(t);await saveKeyword(f);const file=path.join(f.root,'.runtime/jobs/workspace.json'),previous=path.join(f.root,'.runtime/jobs/workspace.previous.json'),before=await fs.readFile(file,'utf8');
  await fs.writeFile(previous,'not JSON');await assert.rejects(restorePrevious(f.root),/유효하지/);assert.equal(await fs.readFile(file,'utf8'),before);
  await fs.writeFile(previous,before);await fs.writeFile(path.join(f.root,'.runtime/jobs/server.json'),JSON.stringify({pid:process.pid}));await assert.rejects(restorePrevious(f.root),/종료/);assert.equal(await fs.readFile(file,'utf8'),before);
});
test('종료는 프로젝트 ID 확인 후 수집·저장 종료를 기다리고 원래 공고를 보존한다',async t=>{
  let entered=false;const f=await fixture(t,async({signal})=>{entered=true;await new Promise(r=>signal.addEventListener('abort',()=>setTimeout(r,30),{once:true}));signal.throwIfAborted();});await saveKeyword(f);await f.api('/api/collect',{});while(!entered)await new Promise(r=>setTimeout(r,1));
  assert.equal((await f.api('/api/shutdown',{})).status,403);assert.equal((await f.api('/api/shutdown',{}, {'X-Job-Desk-Project':f.app.snapshot().projectId})).data.status,'stopping');await f.app.close();assert.equal(f.app.server.listening,false);
  const persisted=JSON.parse(await fs.readFile(path.join(f.root,'.runtime/jobs/workspace.json'),'utf8'));assert.equal(persisted.runs[0].status,'stopped');await f.restart();assert.equal(f.app.snapshot().data.records.length,8);
});
test('최종 저장이 실패해도 기존 공고는 그대로이고 저장 실패를 표시하며 종료할 수 있다',async t=>{
  let call=0,release,entered=false;const f=await fixture(t,async()=>{if(++call===2){entered=true;await new Promise(r=>release=r);}return {records:[{...record(),title:call===1?'기존 공고':'갱신 공고'}],plan:{},checkedAt:new Date().toISOString()};});await saveKeyword(f);await f.api('/api/collect',{});await waitDone(f);await f.api('/api/collect',{});while(!entered)await new Promise(r=>setTimeout(r,1));
  const file=path.join(f.root,'.runtime/jobs/workspace.json'),backup=file+'.preserved';await fs.rename(file,backup);await fs.mkdir(file);release();const data=await waitDone(f);assert.match(data.storageError,/저장하지 못/);assert.equal(data.data.records.find(r=>r.id==='saramin-123').title,'기존 공고');await f.app.close();await fs.rmdir(file);await fs.rename(backup,file);await f.restart();assert.equal(f.app.snapshot().data.records.find(r=>r.id==='saramin-123').title,'기존 공고');assert.equal(f.app.snapshot().runs[0].status,'interrupted');
});
test('주소 수집은 검색어 없이 동작하고 기존 수동 공고를 신규로 세거나 덮어쓰지 않는다',async t=>{
  let received;const seed=JSON.parse(await fs.readFile(new URL('fixtures/public-sample.json',source),'utf8')).records.find(r=>r.sources.some(s=>s.site==='자소설닷컴')),url=seed.sources.find(s=>s.site==='자소설닷컴').url;
  const row={...record(),id:'jasoseol-imported',sources:[{site:'자소설닷컴',url}],required:['자동 표제 추출 예시']};
  const f=await fixture(t,null,{collectors:{jasoseol:async args=>{received=args.directUrls;return {records:[row],plan:{remote:['지정 주소']},checkedAt:new Date().toISOString()};}}});
  assert.equal((await f.api('/api/import-urls',{})).status,400);assert.equal((await f.api('/api/import-urls',{urls:['https://attacker.example/recruit/1']})).status,400);
  assert.equal((await f.api('/api/import-urls',{urls:[url]})).status,202);const data=await waitDone(f);assert.deepEqual(received,[url]);assert.equal(data.runs[0].trigger,'direct-urls');assert.equal(data.runs[0].added,0);assert.equal(data.runs[0].updated,1);assert.equal(data.data.records.length,8);assert.deepEqual(data.data.records.find(r=>r.id===seed.id).required,seed.required);
});
test('수집기가 잘못된 형태의 공고를 반환하면 상태 파일을 손상시키지 않고 실패로 남긴다',async t=>{
  const f=await fixture(t,async()=>({records:[{...record(),company:{unexpected:'object'}}],plan:{},checkedAt:new Date().toISOString()}));await saveKeyword(f);await f.api('/api/collect',{});const data=await waitDone(f);assert.equal(data.runs[0].status,'failed');assert.equal(data.data.records.length,8);await f.restart();assert.equal(f.app.snapshot().data.records.length,8);
});
test('같은 프로젝트의 두 번째 서버는 다른 포트를 쓰더라도 시작 전에 막고 종료 후 다시 실행한다',async t=>{
  const f=await fixture(t);await saveKeyword(f);const file=path.join(f.root,'.runtime/jobs/workspace.json'),before=await fs.readFile(file,'utf8');let second;
  try{await assert.rejects(async()=>{second=await createJobsApp({root:f.root});},/이미 실행 중/);}finally{await second?.close();}
  assert.equal(await fs.readFile(file,'utf8'),before);await f.restart();assert.equal(f.app.snapshot().settings.sites.saramin.keyword,'데이터');
});
test('손상된 개인 저장본의 내용은 오류 메시지에 출력하지 않고 시작 실패 후 실행 잠금도 해제한다',async t=>{
  const f=await fixture(t);await saveKeyword(f);await f.app.close();const file=path.join(f.root,'.runtime/jobs/workspace.json'),before=await fs.readFile(file,'utf8'),broken='민감 메모 시험 표식 {not json';await fs.writeFile(file,broken);
  await assert.rejects(createJobsApp({root:f.root}),e=>{assert.match(e.message,/저장 형식/);assert.ok(!e.message.includes('민감 메모'));return true;});assert.equal(await fs.readFile(file,'utf8'),broken);await fs.writeFile(file,before);await f.restart();assert.equal(f.app.snapshot().data.records.length,8);
});

test('여러 사이트 수집은 모든 조건·버전을 실행 전에 확인하고 잘못된 선택은 수집을 시작하지 않는다',async t=>{
  let calls=0;const collect=async()=>{calls++;return {records:[],plan:{}};};const f=await fixture(t,collect,{collectors:{catch:collect}});
  for(const sites of [[],['other'],['saramin','saramin']])assert.equal((await f.api('/api/collect-batch',{sites,revision:0})).status,400);
  let data=await saveBatchKeywords(f,['saramin']);assert.equal((await f.api('/api/collect-batch',{sites:['saramin','catch'],revision:data.revision})).status,400);
  data=await saveBatchKeywords(f,['saramin','catch']);assert.equal((await f.api('/api/collect-batch',{sites:['saramin','catch'],revision:data.revision-1})).status,409);
  data.settings.sites.catch.enabled=false;data=(await f.api('/api/preferences',{revision:data.revision,profile:data.profile,settings:data.settings})).data;
  assert.equal((await f.api('/api/collect-batch',{sites:['saramin','catch'],revision:data.revision})).status,400);assert.equal(calls,0);assert.equal(f.app.snapshot().runs.length,0);assert.equal(f.app.snapshot().batchActive,false);
});

test('네 사이트는 순서대로 한 번씩 실행하고 실행 후 저장이 바뀌어도 처음 저장된 조건을 사용한다',async t=>{
  const sites=['saramin','catch','jasoseol','jobkorea'],calls=[];let release,started=false,concurrent=0,max=0;
  const collect=site=>async({filter})=>{concurrent++;max=Math.max(max,concurrent);calls.push({site,keyword:filter.keyword});if(site==='saramin'){started=true;await new Promise(r=>release=r);}await new Promise(r=>setTimeout(r,2));concurrent--;return {records:[],plan:{},checkedAt:new Date().toISOString()};};
  const f=await fixture(t,collect('saramin'),{collectors:Object.fromEntries(sites.slice(1).map(site=>[site,collect(site)]))});let data=await saveBatchKeywords(f,sites);
  assert.equal((await f.api('/api/collect-batch',{sites,revision:data.revision})).status,202);while(!started)await new Promise(r=>setTimeout(r,1));
  data=(await f.api('/api/state')).data;data.settings.sites.catch.keyword='변경된 조건';await f.api('/api/preferences',{revision:data.revision,profile:data.profile,settings:data.settings});release();data=await waitBatch(f);
  assert.deepEqual(calls,sites.map(site=>({site,keyword:'검증'})));assert.equal(max,1);assert.equal(data.batch.status,'completed');assert.equal(data.batch.results.length,4);assert.equal(data.schedule.enabled,false);assert.ok(data.runs.every(r=>r.trigger==='batch'&&r.batchId===data.batch.id));
  await f.restart();assert.equal(f.app.snapshot().batch.status,'completed');assert.equal(f.app.snapshot().batch.results.length,4);assert.equal(calls.length,4);
});

test('한 사이트 실패 뒤에도 다음 선택 사이트를 확인하고 성공 공고와 사이트별 결과를 보존한다',async t=>{
  const calls=[],f=await fixture(t,async()=>{calls.push('saramin');return {records:[record()],plan:{}};},{collectors:{catch:async()=>{calls.push('catch');throw new Error('공개 응답 429');},jobkorea:async()=>{calls.push('jobkorea');return {records:[],plan:{}};}}});
  const sites=['saramin','catch','jobkorea'],saved=await saveBatchKeywords(f,sites);await f.api('/api/collect-batch',{sites,revision:saved.revision});const data=await waitBatch(f);
  assert.deepEqual(calls,sites);assert.equal(data.batch.status,'partial');assert.deepEqual(data.batch.results.map(r=>r.status),['completed','failed','completed']);assert.equal(data.data.records.length,9);assert.ok(data.batch.message.includes('신규 1'));assert.ok(data.batch.results[1].message.includes('429'));await f.restart();assert.equal(f.app.snapshot().data.records.length,9);assert.equal(f.app.snapshot().batch.status,'partial');
});

test('여러 사이트 중지는 현재 수집의 실제 종료를 기다리고 남은 사이트·겹친 요청을 실행하지 않는다',async t=>{
  let started=false,ended=false,other=0;const f=await fixture(t,async({signal})=>{started=true;await new Promise(r=>signal.addEventListener('abort',()=>setTimeout(r,60),{once:true}));ended=true;signal.throwIfAborted();},{collectors:{catch:async()=>{other++;return {records:[],plan:{}};}}});
  const sites=['saramin','catch'],saved=await saveBatchKeywords(f,sites),startedRun=await f.api('/api/collect-batch',{sites,revision:saved.revision});while(!started)await new Promise(r=>setTimeout(r,1));
  assert.equal((await f.api('/api/stop',{id:'stale-id'})).status,409);assert.equal((await f.api('/api/collect-batch',{sites,revision:saved.revision})).status,409);assert.equal((await f.api('/api/collect',{site:'catch'})).status,409);
  assert.equal((await f.api('/api/stop',{id:startedRun.data.id})).status,202);assert.equal(ended,false);assert.equal(f.app.snapshot().batchActive,true);assert.equal((await f.api('/api/collect',{site:'catch'})).status,409);
  const data=await waitBatch(f);assert.equal(ended,true);assert.equal(data.batch.status,'stopped');assert.equal(other,0);assert.equal(data.data.records.length,8);assert.equal(data.batch.results[0].status,'stopped');assert.equal(data.active,null);
});

test('같은 여러 사이트 요청을 동시에 보내거나 예약과 겹쳐도 한 흐름만 실행한다',async t=>{
  let release,started=false,calls=0;const f=await fixture(t,async()=>{calls++;started=true;await new Promise(r=>release=r);return {records:[],plan:{}};});
  const saved=await saveBatchKeywords(f,['saramin']),schedule=await f.api('/api/schedule',{revision:saved.revision,schedule:{enabled:true,sites:['saramin'],intervalMinutes:30}}),data={sites:['saramin'],revision:schedule.data.revision};
  const results=await Promise.all([f.api('/api/collect-batch',data),f.api('/api/collect-batch',data)]);assert.deepEqual(results.map(r=>r.status).sort(),[202,409]);while(!started)await new Promise(r=>setTimeout(r,1));
  assert.equal(await f.app.runScheduled(Date.parse(schedule.data.schedule.nextRunAt)),false);assert.equal(calls,1);release();await waitBatch(f);
});

test('여러 사이트의 저장 실패에서는 다음 사이트를 호출하지 않고 재시작 뒤 자동 재개하지 않는다',async t=>{
  let release,started=false,other=0;const f=await fixture(t,async()=>{started=true;await new Promise(r=>release=r);return {records:[record()],plan:{}};},{collectors:{catch:async()=>{other++;return {records:[],plan:{}};}}});
  const saved=await saveBatchKeywords(f,['saramin','catch']);await f.api('/api/collect-batch',{sites:['saramin','catch'],revision:saved.revision});while(!started)await new Promise(r=>setTimeout(r,1));
  const file=path.join(f.root,'.runtime/jobs/workspace.json'),backup=file+'.preserved';await fs.rename(file,backup);await fs.mkdir(file);release();const data=await waitBatch(f);
  assert.equal(other,0);assert.equal(data.data.records.length,8);assert.match(data.storageError,/저장하지 못/);await f.app.close();await fs.rmdir(file);await fs.rename(backup,file);await f.restart();assert.equal(f.app.snapshot().batch.status,'interrupted');assert.equal(f.app.snapshot().batchActive,false);assert.equal(other,0);assert.equal(f.app.snapshot().data.records.length,8);
});

test('여러 사이트 수집 중 종료는 현재 작업 종료와 중지 기록 저장을 기다리고 나머지를 시작하지 않는다',async t=>{
  let started=false,ended=false,other=0;const f=await fixture(t,async({signal})=>{started=true;await new Promise(r=>signal.addEventListener('abort',()=>setTimeout(r,25),{once:true}));ended=true;signal.throwIfAborted();},{collectors:{catch:async()=>{other++;return {records:[],plan:{}};}}});
  const saved=await saveBatchKeywords(f,['saramin','catch']);await f.api('/api/collect-batch',{sites:['saramin','catch'],revision:saved.revision});while(!started)await new Promise(r=>setTimeout(r,1));await f.app.close();assert.equal(ended,true);assert.equal(other,0);await f.restart();assert.equal(f.app.snapshot().batch.status,'stopped');assert.equal(f.app.snapshot().batchActive,false);assert.equal(f.app.snapshot().data.records.length,8);
});
