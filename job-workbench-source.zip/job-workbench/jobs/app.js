(function () {
  'use strict';
  const data=globalThis.JOBS_DATA,schema=globalThis.JOBS_SCHEMA,C=globalThis.JobsCore;
  const $=id=>document.getElementById(id);
  const node=(tag,text,cls)=>{const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;};
  const stamp=value=>new Intl.DateTimeFormat('ko-KR',{dateStyle:'short',timeStyle:'short',timeZone:'Asia/Seoul'}).format(new Date(value));
  const key='job-workbench:v1:'+schema.project+':'+location.pathname;
  const labels={keyword:'기업·공고·직무 키워드',roles:'직무 키워드',locations:'근무지 키워드',career:'채용구분 / 경력',employment:'고용형태',hiring:'채용형태 (신입·경력·인턴)',education:'학력 문구',industry:'업종 키워드',companyType:'기업형태'};
  let settings=C.defaults(schema),selected=schema.sites[0].id,group='open';
  function message(text,error=false){$('save-status').textContent=text;$('save-status').className=error?'error':'';}
  try{const saved=localStorage.getItem(key);if(saved)settings=C.normalizeSettings(JSON.parse(saved),schema);}catch{message('저장 조건을 읽지 못해 기본 조건으로 표시합니다. 기존 저장값은 덮어쓰지 않았습니다.',true);}
  function link(text,url,host){const e=node('a',text),safe=C.safeUrl(url,host);if(safe){e.href=safe;e.target='_blank';e.rel='noopener noreferrer';}return e;}
  function download(name,value){const blob=new Blob([JSON.stringify(value,null,2)+'\n'],{type:'application/json;charset=utf-8'}),url=URL.createObjectURL(blob),a=node('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
  function readForm(){const row=settings.sites[selected];for(const input of $('filter-fields').querySelectorAll('[name]'))row[input.name]=input.type==='checkbox'?input.checked:input.value;}
  function renderForm(){
    const site=schema.sites.find(s=>s.id===selected),row=settings.sites[selected],fields=$('filter-fields');fields.replaceChildren();
    for(const [id,title] of [['enabled','이 사이트의 조건과 공고 사용'],['includeUnknown','필터 항목이 미확인인 공고도 남기기']]){const label=node('label',undefined,'check'),input=node('input');input.type='checkbox';input.name=id;input.checked=row[id];label.append(input,document.createTextNode(title));fields.append(label);}
    const verified=node('p',`원 사이트 확인 항목: ${site.nativeLabels.join(' · ')} (${site.verifiedAt})`,'help wide');fields.append(verified);
    for(const id of new Set(['keyword',...site.fields,'locations'])){const label=node('label',labels[id]),input=node('input');input.name=id;input.value=row[id]||'';input.maxLength=4000;input.placeholder=id==='locations'?'예: 서울, 경기':id==='roles'?'예: 인사, 기획':'전체 (조건 없음)';if(id==='locations'&&!site.fields.includes(id))label.append(node('span','대시보드 추가 필터 · 사이트 원격 적용 안 됨','help'));label.append(input);fields.append(label);}
    const excluded=node('label','제외 키워드'),exclude=node('input');exclude.name='exclude';exclude.value=row.exclude;exclude.placeholder='예: 파견, 영업';excluded.append(exclude);fields.append(excluded);
    const urlLabel=node('label','원 사이트의 실제 검색결과 URL','wide'),url=node('input');url.type='url';url.name='nativeUrl';url.value=row.nativeUrl;url.placeholder=site.url;url.maxLength=4000;urlLabel.append(url,node('span','원 사이트에서 세부조건을 선택한 뒤 주소를 보관합니다. 아래 로컬 조건을 이 URL에 자동으로 넣지는 않습니다.','help'));fields.append(urlLabel);
    const noteLabel=node('label','사이트 고유 세부조건 메모','wide'),notes=node('textarea');notes.name='nativeNotes';notes.value=row.nativeNotes;notes.rows=2;notes.maxLength=4000;notes.placeholder=site.extraHint;noteLabel.append(notes);fields.append(noteLabel);
    const remote=node('p',undefined,'help wide');remote.append(link(site.name+' 검색 페이지 열기 (사용자 클릭)',row.nativeUrl||site.url,site.host));fields.append(remote);
    for(const tab of $('site-tabs').children){const active=tab.dataset.site===selected;tab.setAttribute('aria-selected',String(active));tab.tabIndex=active?0:-1;}
  }
  for(const site of schema.sites){const tab=node('button',site.name);tab.type='button';tab.dataset.site=site.id;tab.setAttribute('role','tab');tab.addEventListener('click',()=>{readForm();selected=site.id;renderForm();});tab.addEventListener('keydown',e=>{if(!['ArrowRight','ArrowLeft','Home','End'].includes(e.key))return;e.preventDefault();const all=[...$('site-tabs').children],at=all.indexOf(tab),next=e.key==='Home'?0:e.key==='End'?all.length-1:(at+(e.key==='ArrowRight'?1:-1)+all.length)%all.length;all[next].click();all[next].focus();});$('site-tabs').append(tab);const option=node('option',site.name);option.value=site.id;$('site-select').append(option);}
  const groups=[['open','진행 공고'],['priority','우선 검토할 공고'],['check','추가 확인할 공고'],['urgent','마감 임박 공고 (7일 이내)'],['closed','마감 공고'],['all','전체 기록']];
  for(const [id,title] of groups){const b=node('button',title);b.type='button';b.dataset.group=id;b.addEventListener('click',()=>{group=id;renderResults();});$('groups').append(b);}
  function section(title,items,wide=false){const block=node('section',undefined,wide?'wide':''),list=node('ul');block.append(node('h3',title));for(const item of items)list.append(node('li',item));block.append(list);return block;}
  function renderResults(){
    for(const b of $('groups').children)b.setAttribute('aria-pressed',String(b.dataset.group===group));
    const rows=C.select(data.records,settings,schema,{site:$('site-select').value,group,search:$('search').value.trim()});$('result-count').textContent=rows.length+'건 표시 · 지원 적합도는 모두 보류';$('results').replaceChildren();
    if(!rows.length){const tr=node('tr'),td=node('td','조건에 맞는 저장 공고가 없습니다. 조건과 미확인 포함 여부를 확인하세요.','empty');td.colSpan=6;tr.append(td);$('results').append(tr);}
    for(const r of rows){
      const tr=node('tr'),company=node('td');company.append(node('strong',r.company),node('p',r.title));
      const detail=node('details'),toggle=node('summary','상세 조건·준비할 일');detail.append(toggle);const grid=node('div',undefined,'detail-grid');
      grid.append(section('학력 / 필수 자격',[r.education,...r.required]),section('우대 조건',r.preferred),section('전형 절차',r.stages),section('제출 서류',r.documents),section('준비할 사항',r.prep),section('지원 자격 판단',[r.eligibility.status+' — '+r.eligibility.reason,...r.eligibility.missing]),section('공식 확인·날짜 근거',[r.officialStatus,r.deadline.basis,...r.evidenceNotes],true));
      const sources=node('section',undefined,'wide');sources.append(node('h3','원문·검증 범위'));for(const s of r.sources){const p=node('p');p.append(link(s.site,s.url),document.createTextNode(' · '+stamp(s.checkedAt)+' KST · '+s.scope));sources.append(p);}if(r.officialUrl)sources.append(link('기업 공식 채용 페이지',r.officialUrl));grid.append(sources);detail.append(grid);
      const role=node('td');role.append(node('p',r.roles.join(' / ')),node('p',r.locations.join(' / ')));const employment=node('td');employment.append(node('p',r.career.join(' / ')),node('p',r.employment.join(' / ')));
      const deadline=node('td',undefined,C.state(r)==='closed'?'closed':'deadline');deadline.append(node('p',r.deadline.label),node('span',C.state(r)==='closed'?'마감':C.state(r)==='urgent'?'7일 이내':'원문 재확인','badge'));
      const priority=node('td');priority.append(node('strong',r.review),node('p',r.reason),node('p','지원 자격: '+r.eligibility.status));
      const origin=node('td');for(const s of r.sources.filter(s=>!s.official)){const p=node('p');p.append(link(s.site,s.url));origin.append(p);}origin.append(node('p',stamp(r.checkedAt)+' KST'));
      tr.append(company,role,employment,deadline,priority,origin);const detailRow=node('tr',undefined,'detail-row'),td=node('td');td.colSpan=6;td.append(detail);detailRow.append(td);$('results').append(tr,detailRow);
    }
  }
  $('filters').addEventListener('submit',e=>{e.preventDefault();readForm();try{settings=C.normalizeSettings(settings,schema);localStorage.setItem(key,JSON.stringify(settings));message('이 브라우저에 조건을 저장했습니다. 프로젝트 보관·다른 브라우저 사용 시 조건 JSON을 저장하세요.');renderForm();renderResults();}catch(error){message(error.message,true);}});
  $('export-settings').addEventListener('click',()=>{readForm();try{download('search-settings.json',C.normalizeSettings(settings,schema));message('조건 JSON을 저장합니다. 프로젝트 jobs 폴더에 보관하면 다음 수집 시 재사용할 수 있습니다.');}catch(e){message(e.message,true);}});
  $('import-settings').addEventListener('change',async e=>{const file=e.target.files[0];if(!file)return;try{if(file.size>200000)throw new Error('조건 JSON은 200KB 이하만 지원합니다.');const imported=C.normalizeSettings(JSON.parse(await file.text()),schema);localStorage.setItem(key,JSON.stringify(imported));settings=imported;renderForm();renderResults();message('조건을 불러와 이 브라우저에 저장했습니다.');}catch(error){message('불러오기 실패: '+error.message,true);}finally{e.target.value='';}});
  $('export-data').addEventListener('click',()=>download('recruitments-'+data.collectedAt.slice(0,10)+'.json',data));$('site-select').addEventListener('change',renderResults);$('search').addEventListener('input',renderResults);
  $('checked').textContent='공개 게시물 확인: '+stamp(data.collectedAt)+' KST · 원문별 확인 시점은 상세 참조';
  const counts=C.summary(data.records);for(const [title,value] of [['진행 중',counts.open],['마감 임박 · 7일',counts.urgent],['중복 정리 후 전체',counts.unique],['마감 별도 보관',counts.closed]]){const card=node('div',title,'stat');card.append(node('strong',String(value)));$('stats').append(card);}
  $('scope').textContent=data.scope+' '+data.deduplication;for(const item of data.limitations)$('limits').append(node('li',item));for(const item of data.profile.questions)$('questions').append(node('li',item));renderForm();renderResults();
})();
