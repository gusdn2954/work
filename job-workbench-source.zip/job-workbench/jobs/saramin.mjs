import {recognizeHtmlImages} from './image-ocr.mjs';
import {extractRequirements} from './requirements.mjs';
import fs from 'node:fs/promises';
import path from 'node:path';
import {setTimeout as pause} from 'node:timers/promises';
import {launchBrowser} from './browser.mjs';
import './core.js';

export const SARAMIN_LIMITS = {pageSize: 40, maxPages: 5, maxItems: 200, pageDelayMs: 1500};
const JC = () => globalThis.JobsCore;
export function searchPlan(filter) {
  // 사이트 양식 조건이 있으면 사람인 검색 화면과 같은 이름·코드를 그대로 보낸다(공통 조건은 쓰지 않는다).
  const native = JC().nativeQuery('saramin', filter.nativeQuery);
  if (native) {
    if (!filter.enabled) throw new Error('사람인 사이트 사용을 켜주세요.');
    if (!native.ok) throw new Error(native.error);
    const url = new URL('https://www.saramin.co.kr/zf_user/search');
    for (const [k, v] of Object.entries(native.params)) url.searchParams.set(k, v);
    url.searchParams.set('recruitPage', '1'); url.searchParams.set('recruitPageCount', String(SARAMIN_LIMITS.pageSize));
    return {url: url.href, keyword: native.params.searchword || '', remote: ['사람인 양식 조건 그대로'], remoteKey: native.key, urlCovered: ['native'], conflicts: [], notes: [], companyTypeSource: null, local: [], unsupported: [], limits: {...SARAMIN_LIMITS}};
  }
  const siteKeyword = JC().siteKeywordOf(filter), query = JC().saraminQuery(filter.nativeUrl, filter.companyType, {...filter, keyword: siteKeyword});
  if (!filter.enabled) throw new Error('사람인 사이트 사용을 켜주세요.');
  if (query && !query.ok) throw new Error(query.error);
  const keyword = String(query?.params.searchword || siteKeyword || filter.roles || '').trim();
  if (!keyword) throw new Error('사람인 조건에 검색어 또는 직무를 먼저 저장해주세요.');
  if (keyword.length > 120 || /[,，\n]/.test(keyword)) throw new Error('첫 수집은 검색어 한 개로 실행합니다. 120자 이내의 검색어를 저장해주세요.');
  const url = new URL('https://www.saramin.co.kr/zf_user/search');
  url.searchParams.set('searchword', keyword);
  for (const key of ['exp_cd','edu_min','edu_max','company_type','company_cd','recruitSort']) if (query?.params[key]) url.searchParams.set(key, query.params[key]);
  url.searchParams.set('recruitPage', '1');
  url.searchParams.set('recruitPageCount', String(SARAMIN_LIMITS.pageSize));
  const covered = query?.covered || [];
  const localKeys = ['roles','locations','career','employment','education','industry','companyType','exclude'];
  return {
    url: url.href, keyword, remote: query ? query.labels : ['검색어'], remoteKey: query?.key || null, urlCovered: covered,
    // URL이 대신 보내는 항목에 로컬 값이 따로 있으면 조용히 합치지 않고 기록한다. 로컬 값은 이 URL로 확인되지 않은 기존 공고에만 적용된다.
    conflicts: covered.filter(k => k !== 'keyword' && k !== 'companyType' && filter[k] && !(query?.fromSelection || []).includes(k)).map(k => k), notes: query?.notes || [], companyTypeSource: query?.companyTypeSource || null,
    local: localKeys.filter(k => filter[k] && !(covered.includes(k) && k !== 'keyword')),
    unsupported: ['hiring', ...(query ? [] : ['nativeUrl']), 'nativeNotes'].filter(k => filter[k]),
    limits: {...SARAMIN_LIMITS}
  };
}

const KST_DAY=['일','월','화','수','목','금','토'];
function endOfDay(y,m,d){const date=new Date(Date.UTC(y,m-1,d));if(date.getUTCFullYear()!==y||date.getUTCMonth()!==m-1||date.getUTCDate()!==d)return null;const label=`${y}-${String(m).padStart(2,'0')}-${String(d).padStart(2,'0')}`;return {date,at:label+'T23:59:59+09:00',label};}
// 목록 마감 표기 → 구조화. 연도는 요일이 일치하는 가장 가까운 해만 인정하고, 시각은 추정하지 않는다.
export function parseListDeadline(raw,checkedAt=new Date().toISOString()){
  const label=String(raw||'').replace(/\s+/g,' ').trim()||'미확인',kstNow=new Date(Date.parse(checkedAt)+9*3600000),year=kstNow.getUTCFullYear();
  const unknown=basis=>({at:null,precision:'unknown',label,basis});
  if(/오늘\s*마감/.test(label)){const day=endOfDay(year,kstNow.getUTCMonth()+1,kstNow.getUTCDate());return {at:day.at,precision:'date',label:day.label+' (오늘 마감 표기)',basis:'사람인 목록의 “오늘마감” 표기를 확인 시각 기준 날짜로 변환했습니다. 마감 시각은 미확인(날짜 끝값).'};}
  if(/채용\s*시|상시/.test(label))return unknown('사람인 목록이 “채용시/상시” 마감으로 표기했습니다. 종료일이 없어 마감 시각을 계산하지 않았습니다.');
  const m=label.match(/(\d{1,2})\/(\d{1,2})\s*\(([일월화수목금토])\)/);
  if(m){
    const today=Date.UTC(year,kstNow.getUTCMonth(),kstNow.getUTCDate());
    const hits=[year-1,year,year+1].map(y=>endOfDay(y,+m[1],+m[2])).filter(c=>c&&KST_DAY[c.date.getUTCDay()]===m[3]).sort((a,b)=>Math.abs(a.date-today)-Math.abs(b.date-today));
    if(hits.length)return {at:hits[0].at,precision:'date',label:hits[0].label+' ('+m[3]+') 마감',basis:'사람인 목록 “'+label+'”에서 요일이 일치하는 가장 가까운 연도를 적용했습니다. 마감 시각은 미확인(날짜 끝값).'};
    return unknown('목록의 날짜와 요일이 가까운 연도와 맞지 않아 연도를 확정하지 않았습니다.');
  }
  return unknown('검색 목록 표기를 보존했습니다. 연도·정확한 마감시각은 미확인입니다.');
}
// 상세 본문의 “접수기간 : YYYY년 M월 D일 ~ YYYY년 M월 D일”에서 종료일만 읽는다.
export function parseDetailDeadline(text){
  const m=String(text||'').match(/접수\s*기간\s*[:：]?[^\n~]{0,60}~\s*(\d{4})\s*년\s*(\d{1,2})\s*월\s*(\d{1,2})\s*일(?:\s*\(([일월화수목금토])\))?(?:\s*(\d{1,2})\s*(?:시|:)\s*(\d{0,2}))?/);
  if(!m)return null;const day=endOfDay(+m[1],+m[2],+m[3]);if(!day||(m[4]&&KST_DAY[day.date.getUTCDay()]!==m[4]))return null;
  const hour=m[5]!==undefined?+m[5]:null,minute=m[6]?+m[6]:0;
  return {day,time:hour!==null&&hour<24&&minute<60?{hour,minute}:null};
}

export async function fetchPublic(url, {signal, fetcher = fetch, site = 'saramin'} = {}) {
  let current = new URL(url);
  const host={saramin:'www.saramin.co.kr',catch:'www.catch.co.kr',jasoseol:'jasoseol.com',jobkorea:'www.jobkorea.co.kr'}[site];
  const check = u => host && !/\/(?:auth|login|member|account)(?:\/|$)/i.test(u.pathname) && u.protocol === 'https:' && u.hostname === host && !u.username && !u.password && (!u.port || u.port === '443');
  for (let hop = 0; hop < 4; hop++) {
    if (!check(current)) throw new Error('허용한 사이트 공개 주소가 아닙니다.');
    const response = await fetcher(current.href, {redirect: 'manual', signal: AbortSignal.any([signal || new AbortController().signal, AbortSignal.timeout(25000)])});
    if ([301,302,303,307,308].includes(response.status)) { current = new URL(response.headers.get('location'), current); continue; }
    if (!response.ok) throw new Error(`공개 페이지 응답 ${response.status}: 기존 결과를 유지했습니다.`);
    if (response.headers.get('content-length') > 8 * 1024 * 1024) throw new Error('공고 응답 크기 상한을 넘었습니다.');
    const reader = response.body.getReader(); let size = 0; const chunks = [];
    try {
      for (;;) { const {done,value} = await reader.read(); if (done) break; size += value.length; if (size > 8 * 1024 * 1024) throw new Error('공고 응답 크기 상한을 넘었습니다.'); chunks.push(Buffer.from(value)); }
    } finally { await reader.cancel().catch(() => {}); }
    return {html: Buffer.concat(chunks).toString('utf8'), url: current.href};
  }
  throw new Error('공개 페이지 리디렉션 상한을 넘었습니다.');
}

export async function readSearch(page, html, limit = 10) {
  await page.setContent(html, {waitUntil: 'domcontentloaded'});
  return page.locator('.item_recruit').evaluateAll((items, max) => items.map(item => {
    const text = selector => (item.querySelector(selector)?.textContent || '').replace(/\s+/g, ' ').trim();
    const spans=[...item.querySelectorAll('.job_condition > span')],conditions=spans.map(e=>e.textContent.replace(/\s+/g,' ').trim());
    const locations=spans.filter((e,i)=>/\/jobs\/list\/(?:domestic|world)|[?&]loc_(?:mcd|bcd)=/.test(e.querySelector('a')?.getAttribute('href')||'')||/^(?:서울|인천|경기|강원|충북|충남|전북|전남|경북|경남|세종|부산|울산|대구|대전|광주|제주|전국|해외)/.test(conditions[i])).map(e=>e.textContent.replace(/\s+/g,' ').trim());
    const remaining=conditions.filter(v=>!locations.includes(v));
    const career=remaining.filter(v=>/신입|경력/.test(v)),education=remaining.find(v=>/학력|대졸|고졸|석사|박사|대학|졸업/.test(v))||'미확인',employment=remaining.filter(v=>/정규직|계약직|인턴|아르바이트|프리랜서|기간제|위촉직|교육생|파견직/.test(v));
    return {company: text('.corp_name a'), title: text('.job_tit a'), href: item.querySelector('.job_tit a')?.getAttribute('href'), conditions,locations,career,education,employment,roles: [...item.querySelectorAll('.job_sector a')].map(e => e.textContent.trim()), deadline: text('.job_date .date')};
  }).filter(r => r.company && r.title && r.href).slice(0,max), limit);
}

export async function readTotal(page) {
  const text = await page.locator('#recruit_info .cnt_result').first().textContent({timeout: 2000}).catch(() => '');
  const m = String(text || '').replace(/,/g, '').match(/(\d+)\s*건/);
  return m ? Number(m[1]) : null;
}

export async function collectSaramin({filter, runtime, runId, signal, progress = () => {}, limit = SARAMIN_LIMITS.maxItems, fetcher, browserFactory = launchBrowser, pageDelayMs = SARAMIN_LIMITS.pageDelayMs, detailDelayMs = 800}) {
  const plan = searchPlan(filter), dir = path.join(runtime, 'sources', runId);
  await fs.mkdir(dir, {recursive: true});
  const checkedAt = new Date().toISOString();
  const maxItems = Math.max(1, Math.min(SARAMIN_LIMITS.maxItems, Math.floor(limit) || SARAMIN_LIMITS.maxItems)), pageSize = SARAMIN_LIMITS.pageSize;
  progress('사람인 검색 목록을 읽고 있습니다.',{phase:'list',completed:0,total:null});
  const search = await fetchPublic(plan.url, {signal, fetcher});
  await fs.writeFile(path.join(dir, 'search-p1.html'), search.html);
  const browser = await browserFactory();
  const abort = () => { void browser.close().catch(()=>{}); };
  signal?.addEventListener('abort', abort, {once: true});
  try {
    signal?.throwIfAborted();
    const context = await browser.newContext({javaScriptEnabled: false, serviceWorkers: 'block'});
    await context.route('**/*', route => route.abort());
    const page = await context.newPage();
    const idOf = row => new URL(row.href, plan.url).searchParams.get('rec_idx');
    const items = [], ids = new Set(), scan = {siteTotal: null, pageSize, pagesPlanned: 1, pagesRead: 0, listed: 0, duplicates: 0, noId: 0, limit: {maxPages: SARAMIN_LIMITS.maxPages, maxItems}, stopReason: null, stopMessage: null};
    const take = rows => { let fresh = 0; for (const row of rows) { scan.listed++; const id = idOf(row); if (!/^\d+$/.test(id || '')) { scan.noId++; continue; } if (ids.has(id)) { scan.duplicates++; continue; } if (items.length >= maxItems) continue; ids.add(id); items.push({row, id}); fresh++; } return fresh; };
    const rows = await readSearch(page, search.html, pageSize);
    scan.pagesRead = 1; scan.siteTotal = await readTotal(page);
    if (!rows.length) {
      await page.setContent(search.html, {waitUntil: 'domcontentloaded'});
      const body = await page.locator('body').textContent();
      if (!/검색결과가 없습니다|검색 결과가 없습니다|검색된 채용정보가 없습니다/.test(body)) throw new Error('목록 구조를 확인하지 못했습니다. 0건 성공으로 처리하지 않았습니다.');
    }
    take(rows);
    // 총건수를 읽은 경우에만 다음 페이지로 간다. 유한 상한(페이지/건수)·요청 간격·25초 요청 제한이 있고 실패는 재시도하지 않는다.
    scan.pagesPlanned = scan.siteTotal ? Math.max(1, Math.min(SARAMIN_LIMITS.maxPages, Math.ceil(Math.min(scan.siteTotal, maxItems) / pageSize))) : 1;
    for (let n = 2; n <= scan.pagesPlanned && items.length < maxItems; n++) {
      progress(`사람인 검색 목록 ${n}/${scan.pagesPlanned}페이지를 읽고 있습니다.`,{phase:'list',completed:scan.pagesRead,total:scan.pagesPlanned});
      await pause(pageDelayMs, undefined, {signal});
      let next;
      try {
        const pageUrl = new URL(plan.url); pageUrl.searchParams.set('recruitPage', String(n));
        next = await fetchPublic(pageUrl.href, {signal, fetcher});
      } catch (e) { signal?.throwIfAborted(); Object.assign(scan, {stopReason: 'page-failed', stopMessage: `${n}페이지 실패: ${e.message}`}); break; }
      await fs.writeFile(path.join(dir, `search-p${n}.html`), next.html);
      const more = await readSearch(page, next.html, pageSize); scan.pagesRead = n;
      if (!more.length) { Object.assign(scan, {stopReason: 'empty-page', stopMessage: `${n}페이지가 비어 있어 멈췄습니다.`}); break; }
      if (!take(more)) { Object.assign(scan, {stopReason: 'repeated-page', stopMessage: `${n}페이지가 이미 읽은 공고뿐이라 멈췄습니다.`}); break; }
    }
    scan.unique = items.length;
    if (!scan.stopReason && scan.siteTotal != null && scan.siteTotal > items.length) Object.assign(scan, {stopReason: 'limit', stopMessage: `상한(${SARAMIN_LIMITS.maxPages}페이지·${maxItems}건)까지만 확인했습니다.`});
    scan.complete = scan.siteTotal == null ? null : items.length >= scan.siteTotal && !scan.stopReason;
    const records = [];
    for (const {row, id} of items) {
      signal?.throwIfAborted();
      progress(`상세 확인 ${records.length + 1}/${items.length} · ${row.company}`,{phase:'detail',completed:records.length,total:items.length});
      await pause(detailDelayMs,undefined,{signal});
      const url = `https://www.saramin.co.kr/zf_user/jobs/relay/view-detail?rec_idx=${id}`;
      let detailText = '', detailError = null, hasImages = false, imageOcr=null;
      try {
        const detail = await fetchPublic(url, {signal, fetcher});
        await fs.writeFile(path.join(dir, `${id}.html`), detail.html);
        await page.setContent(detail.html, {waitUntil: 'domcontentloaded'});
        hasImages = await page.locator('img').count() > 0;
        await page.locator('script,style,noscript').evaluateAll(es => es.forEach(e => e.remove()));
        detailText = (await page.locator('body').innerText()).trim().slice(0, 24000);
        if(hasImages)imageOcr=await recognizeHtmlImages({html:detail.html,base:url,signal});
      } catch (e) { signal?.throwIfAborted(); detailError = e.message; }
      const record = {
        id: `saramin-${id}`, company: row.company, title: row.title, roles: row.roles.length ? row.roles : ['미확인'], locations: row.locations.length?row.locations:['미확인'], career: row.career.length?row.career:['미확인'], education: row.education, employment: row.employment.length?row.employment:['미확인'], industry: '미확인', companyType: '미확인',
        required: ['직무별 필수 자격은 원문 확인 필요'], preferred: ['우대 조건 미확인'], stages: ['전형 절차 미확인'], documents: ['제출 서류 미확인'], prep: ['원문에서 직무별 자격·마감시각·제출 서류 확인'],
        deadline: parseListDeadline(row.deadline,checkedAt),
        sources: [{site: '사람인', url, checkedAt, official: false, status: detailError ? null : 200, scope: detailError ? '검색 목록 확인 · 상세 조회 실패' : '검색 목록과 공개 상세 텍스트 확인 · 이미지 요강 해석 미수행', evidenceFile: `.runtime/jobs/sources/${runId}/${detailError ? 'search-p1' : id}.html`}],
        detailFetch:{status:detailError?'failed':'success',error:detailError}, detailCheckedAt:detailError?null:checkedAt,
        remoteMatches: plan.remoteKey ? [{key: plan.remoteKey, fields: plan.urlCovered, checkedAt}] : undefined, checkedAt, originalUrl: `https://www.saramin.co.kr/zf_user/jobs/relay/view?rec_idx=${id}`, officialStatus: '사람인 게시물만 확인 · 기업 공식 원문 별도 대조 미수행', listConditions:row.conditions,evidenceNotes: ['목록 원래 표기: '+row.conditions.join(' / '),detailError || (hasImages ? '이미지로 제공되는 요강은 자동 해석하지 않았습니다.' : '본문에서 필수·우대·전형·서류를 자동 확정하지 않았습니다.')], eligibility: {status: '보류', reason: '개인 조건과 직무별 상세 자격 확인 필요', missing: ['개인 지원 조건', '직무별 상세 자격']}, review: '추가 확인', reason: '검색 목록 수집 · 상세 자격은 확인 필요', detailText, partial: true, discoveredAt: checkedAt
      };
      const detailEnd=parseDetailDeadline(detailText);
      if(detailEnd){
        const {day,time}=detailEnd,mismatch=record.deadline.at&&record.deadline.at.slice(0,10)!==day.label?' 목록 표기('+record.deadline.label+')와 날짜가 달라 본문 날짜를 우선했으며 원문 확인이 필요합니다.':'';
        record.deadline=time?{at:`${day.label}T${String(time.hour).padStart(2,'0')}:${String(time.minute).padStart(2,'0')}:00+09:00`,precision:'minute',label:`${day.label} ${String(time.hour).padStart(2,'0')}:${String(time.minute).padStart(2,'0')} KST`,basis:'사람인 공개 상세의 접수기간 종료일시를 읽었습니다.'+mismatch}:{at:day.at,precision:'date',label:day.label+' 마감',basis:'사람인 공개 상세의 접수기간 종료일을 읽었습니다. 시각은 미확인(날짜 끝값).'+mismatch};
      }
      if(imageOcr){record.imageOcr=imageOcr;if(imageOcr.text){record.evidenceNotes.push('이미지 글자 인식: Windows 한국어 OCR · 오독 가능, 원문 대조 필요');record.sources[0].scope+=' · 이미지 OCR 텍스트 별도 보관';}}
      const extracted=extractRequirements(detailText);for(const item of Object.values(extracted.evidence)){item.sourceFile=record.detailScope==='body-text'?(record.sources[0].bodyEvidenceFile||record.sources[0].evidenceFile):record.sources[0].evidenceFile;item.checkedAt=checkedAt;}Object.assign(record,extracted.fields,{requirementsEvidence:extracted.evidence,extractionMethod:extracted.method});
      await fs.writeFile(path.join(dir, `${id}.json`), JSON.stringify(record, null, 2));
      records.push(record);
      progress(`상세 확인 ${records.length}/${items.length}건 처리`,{phase:'detail',completed:records.length,total:items.length});
    }
    if(items.length===0&&rows.length)throw new Error('공고 식별자를 확인하지 못했습니다. 기존 결과를 유지합니다.');
    await fs.writeFile(path.join(dir,'manifest.json'),JSON.stringify({checkedAt,plan,count:records.length,scan},null,2));
    return {records, plan, checkedAt, scan};
  } finally { signal?.removeEventListener('abort',abort); await browser.close(); }
}
