import test from 'node:test';
import assert from 'node:assert/strict';
import {sitePlan,directJasoseolPlan,explicitDeadline,parseSiteList,readJasoseolSearch} from './public-sites.mjs';
import {fetchPublic} from './saramin.mjs';

test('공개 사이트별 원격 조건과 제한된 최근 목록을 구분한다',()=>{
  const filter={enabled:true,keyword:'검증',locations:'서울'};
  assert.equal(new URL(sitePlan('catch',filter).url).searchParams.get('Keyword'),'검증');
  assert.equal(new URL(sitePlan('jobkorea',filter).url).searchParams.get('stext'),'검증');
  const jaso=sitePlan('jasoseol',filter);assert.equal(new URL(jaso.url).searchParams.get('keyword'),'검증');assert.equal(new URL(jaso.url).searchParams.get('excludeClosed'),'true');assert.ok(!jaso.local.includes('keyword'));assert.match(jaso.coverage,/100건/);
  assert.throws(()=>sitePlan('unknown',filter));assert.throws(()=>sitePlan('catch',{...filter,enabled:false}));
});
test('캐치 표준 지역·고용형태만 원격 전달하고 인식 못한 문구를 임의로 바꾸지 않는다',()=>{
  const filter={enabled:true,keyword:'검증',locations:'서울, 경기',employment:'인턴'};
  let plan=sitePlan('catch',filter),url=new URL(plan.url);assert.equal(url.searchParams.get('Sido'),'서울,경기');assert.equal(url.searchParams.get('WorkPosition'),'4');assert.ok(plan.remote.some(v=>v.startsWith('지역:')));
  plan=sitePlan('catch',{...filter,locations:'서울, 강남구',employment:'정규직 협의'});url=new URL(plan.url);assert.equal(url.searchParams.has('Sido'),false);assert.equal(url.searchParams.has('WorkPosition'),false);assert.ok(plan.local.includes('locations'));assert.ok(plan.local.includes('employment'));
});
test('주소 수집은 지정 사이트 공개 공고만 허용하고 추적 변수·중복을 제거한다',()=>{
  const filter={enabled:true},plan=directJasoseolPlan(filter,['https://jasoseol.com/recruit/123?from=search','https://jasoseol.com/recruit/00123/']);assert.deepEqual(plan.urls,['https://jasoseol.com/recruit/123']);assert.equal(plan.keyword,'');
  for(const url of ['https://attacker.example/recruit/123','https://jasoseol.com/login','http://jasoseol.com/recruit/123','https://user:password@jasoseol.com/recruit/123','https://jasoseol.com/recruit/0'])assert.throws(()=>directJasoseolPlan(filter,[url]));
  assert.throws(()=>directJasoseolPlan(filter,Array.from({length:6},(_,i)=>'https://jasoseol.com/recruit/'+(i+1))),/5개/);
});
test('시간대 없는 날짜·잘못된 날짜는 마감시각을 확정하지 않는다',()=>{
  assert.equal(explicitDeadline('2026-11-01T23:59').at,null);
  assert.equal(explicitDeadline('11/01').at,null);assert.equal(explicitDeadline('2026-02-30T23:59:00+09:00').at,null);assert.equal(explicitDeadline('2026-11-01T24:00:00+09:00').at,null);
  assert.equal(explicitDeadline('2026-13-01T00:00:00+09:00').at,null);
  const exact=explicitDeadline('2026-11-01T23:59:00+09:00');assert.equal(exact.at,'2026-11-01T23:59:00+09:00');assert.match(exact.label,/2026-11-01 23:59 KST/);
});
test('공개 수집 사이트가 달라도 로그인·다른 호스트 리디렉션을 거부한다',async()=>{
  await assert.rejects(fetchPublic('https://www.catch.co.kr/NCS/RecruitSearch',{site:'catch',fetcher:async()=>new Response('',{status:302,headers:{location:'/Member/Login'}})}),/허용/);
  await assert.rejects(fetchPublic('https://jasoseol.com/search',{site:'jasoseol',fetcher:async()=>new Response('',{status:302,headers:{location:'https://secure.jasoseol.com/login'}})}),/허용/);
  await assert.rejects(fetchPublic('https://www.jobkorea.co.kr/Search/',{site:'catch'}),/허용/);
});
test('캐치 응답 형식 변경을 빈 성공으로 처리하지 않는다',async()=>{
  await assert.rejects(parseSiteList('catch',null,'{"rows":[]}',{}),/구조/);
  const rows=await parseSiteList('catch',null,JSON.stringify({intTotalRecordCount:1,recruitData:[{RecruitID:1,CompName:'가상 검증 회사',RecruitTitle:'가상 공고',Depth:'분석',ApplyEndTimeHide:true,ApplyEndDatetime:'2026-11-01T23:59:00+09:00'}]}),{});
  assert.equal(rows[0].deadline,null);
});

test('자소설닷컴은 사이트 검색과 같은 채용형태·기업형태·직무·마감 제외 코드를 보낸다',()=>{
  const C=globalThis.JobsCore,filter={enabled:true,keyword:'화학공학',siteKeyword:'*',career:'신입',employment:'정규직, 계약직, 인턴',hiring:'교육',companyType:'대기업, 중견기업, 중소기업',duties:'95'};
  const plan=sitePlan('jasoseol',filter),p=new URL(plan.url).searchParams;
  assert.equal(p.get('keyword'),null,'* 이면 검색어 없이');assert.equal(p.get('division'),'1,3,4,7');assert.equal(p.get('businessTypes'),'big_business,middle_market,other_business_type');
  assert.equal(p.get('dutyGroupIds'),'185,186,187,188,189,190,191,192,193','생산·제조 대분류는 사이트처럼 하위 9개로 펼친다');assert.equal(p.get('excludeClosed'),'true');
  assert.deepEqual(plan.urlCovered,['career','employment','hiring','companyType']);assert.deepEqual(plan.local,[]);assert.ok(plan.remoteKey);
  // 자소설닷컴 구분이 없는 값만 있는 항목은 로컬 검사로 남긴다.
  assert.ok(sitePlan('jasoseol',{enabled:true,keyword:'a',employment:'프리랜서'}).local.includes('employment'));
  assert.throws(()=>sitePlan('jasoseol',{enabled:true}),/조건을 하나 이상/);
  assert.equal(C.siteKeywordOf({keyword:'공통',siteKeyword:''}),'공통');assert.equal(C.siteKeywordOf({keyword:'공통',siteKeyword:'화학'}),'화학');assert.equal(C.siteKeywordOf({keyword:'공통',siteKeyword:'*'}),'');
  // 같은 조건으로 확인된 공고만 목록에 남는다.
  const site={id:'jasoseol',fields:['roles','companyType','hiring']},record={company:'a',title:'b',roles:['생산'],locations:['미확인'],career:['신입'],employment:[],education:'',industry:'',companyType:'',sources:[{site:'자소설닷컴'}]};
  assert.equal(C.matches({...record,remoteMatches:[{key:plan.remoteKey}]},filter,site),true);assert.equal(C.matches(record,filter,site),false);
});
test('자소설닷컴 검색 페이지 데이터에서 공고·전체 건수·시작/마감을 읽고 구조가 다르면 0건으로 처리하지 않는다',()=>{
  const page=data=>'<script id="__NEXT_DATA__" type="application/json">'+JSON.stringify({props:{pageProps:{dehydratedState:{queries:[{queryKey:['jobSearch',{page:2}],state:{data}}]}}}})+'</script>';
  const read=readJasoseolSearch(page({totalCount:29,data:[{id:7,name:'회사',title:'생산 신입',start_time:'2026-10-27T17:00:00.000+09:00',end_time:'2026-11-08T23:59:00.000+09:00',company_group:{business_type:'big_business'},employments:[{field:'생산',division:[1,3]}]}]}));
  assert.equal(read.total,29);assert.equal(read.page,2);assert.deepEqual(read.rows[0].career,['신입']);assert.deepEqual(read.rows[0].employment,['인턴']);assert.equal(read.rows[0].companyType,'대기업');assert.equal(read.rows[0].startAt,'2026-10-27T17:00:00.000+09:00');
  assert.throws(()=>readJasoseolSearch('<html></html>'),/구조/);assert.throws(()=>readJasoseolSearch(page({data:[]})),/구조/);
});
