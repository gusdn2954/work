import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import vm from 'node:vm';
// 사이트 양식의 학력 선택이 사이트마다 다른 형식(사람인: edu_min/edu_max 쿼리, 잡코리아: edu=코드)으로 저장·복원되는지 검사한다.
const source=await fs.readFile(new URL('./dashboard.js',import.meta.url),'utf8');
const context=vm.createContext({URLSearchParams});
vm.runInContext(source.slice(source.indexOf('  const tokenOf=o=>'),source.indexOf('  const leavesOf=')),context);
const table=async site=>JSON.parse(await fs.readFile(new URL('./site-tables/'+site+'.json',import.meta.url),'utf8'));
const roundTrip=async(site,labelPattern)=>{
  const t=await table(site),group=t.groups.find(g=>g.label==='학력'),option=group.options.find(o=>labelPattern.test(o.label));
  context.t=t;context.sel=vm.runInContext('nativeParse(t,"")',context);context.sel.set(group.key,new Set([group.param+':'+option.code]));
  const query=vm.runInContext('nativeBuild(t,sel)',context);context.q=query;
  const back=vm.runInContext('nativeParse(t,q)',context);return {query,restored:[...back.get(group.key)],token:group.param+':'+option.code};
};
test('jobkorea education is sent as edu=5, never as an empty "5=" key',async()=>{
  const r=await roundTrip('jobkorea',/대학교졸업\(4년\)/);assert.equal(r.query,'edu=5');assert.ok(!/(^|&)5=/.test(r.query));assert.deepEqual(r.restored,[r.token]);
});
test('saramin education keeps its edu_min/edu_max form',async()=>{
  const r=await roundTrip('saramin',/대학교졸업\(4년\)/);assert.equal(r.query,'edu_min=8&edu_max=11');assert.deepEqual(r.restored,[r.token]);
});
test('a legacy empty "5=" key no longer shows as a selected education',async()=>{
  context.t=await table('jobkorea');context.q='duty=1000330&career=1&5=&cotype=1';
  const back=vm.runInContext('nativeParse(t,q)',context);assert.deepEqual([...back.get('edu')],[]);
});
