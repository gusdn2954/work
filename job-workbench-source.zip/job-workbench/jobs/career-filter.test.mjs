import fs from 'node:fs/promises';import vm from 'node:vm';import test from 'node:test';import assert from 'node:assert/strict';
const source=await fs.readFile(new URL('./dashboard.js',import.meta.url),'utf8'),start=source.indexOf('  function matchesCareer('),end=source.indexOf('  function records(',start);
function accepts(mode,career){const context=vm.createContext({$:()=>({value:mode}),row:{career}});return vm.runInContext(source.slice(start,end)+'\nmatchesCareer(row)',context);}
test('전체 경력은 미확인과 경력 전용 공고도 유지한다',()=>{for(const value of [[],undefined,['미확인'],['경력 3년'],['신입']])assert.equal(accepts('all',value),true);});
test('신입·경력무관은 저장 표기에 신입 또는 무관이 있는 원본만 남긴다',()=>{for(const value of [['신입'],['신입·경력'],['경력 무관'],['무관']])assert.equal(accepts('entry',value),true);for(const value of [[],undefined,['미확인'],['경력 3년']])assert.equal(accepts('entry',value),false);});
test('신입 표기만은 경력무관을 신입 명시로 바꾸어 판정하지 않는다',()=>{assert.equal(accepts('explicit',['경력무관']),false);assert.equal(accepts('explicit',['신입·경력']),true);assert.equal(accepts('explicit',['신입']),true);});
