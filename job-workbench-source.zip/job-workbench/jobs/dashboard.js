(() => {
  'use strict';


  const C=globalThis.JobsCore,$=id=>document.getElementById(id),node=(tag,text,cls)=>{const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;};
  const profileLabels={roles:'희망 직무·검색어',locations:'근무 지역',career:'신입·경력',employment:'고용 형태',education:'학력·졸업 시점',credentials:'자격증·어학·기술',exclude:'제외 키워드'};
  const siteLabels={keyword:'검색어 (한 번에 한 개)',roles:'직무 키워드',locations:'지역 키워드',career:'신입·경력',employment:'고용 형태',hiring:'채용 형태',education:'학력 문구',industry:'업종',companyType:'기업 형태',exclude:'제외 키워드',nativeUrl:'기존 검색결과 주소',nativeNotes:'사이트 세부조건 메모',siteKeyword:'이 사이트 검색어 (비우면 공통 검색어 · * 를 넣으면 검색어 없이 찾기)'};
  const legacyDraftKey='local-job-desk:draft:v1:'+location.origin;let draftKey;
  let composing=false,ready=false,state,settings,profile,selectedSite='saramin',selectedId=null,group='open',dirty=false,saving=false,polling=false,signature='',detailSignature='',editRevision=0,pendingDraft=null,conflict=false,scheduleDirty=false,scheduleSaving=false,scheduleInitialized=false,schedulePending=null,batchSubmitting=false,sortKey='deadline',pageSize=20,page=1;
  // 선택형 조건은 저장 계약(쉼표로 구분한 문자열)에 그대로 연결한다. 같은 항목 안은 OR, 항목 사이는 AND로 core.js가 판정한다.
  const choiceGroups=[
    {key:'locations',label:'지역',options:['서울','경기','인천','부산','대구','대전','광주','울산','세종','강원','충북','충남','전북','전남','경북','경남','제주']},
    {key:'roles',label:'직무',options:['경영지원','영업','마케팅','개발','데이터','인사','재무','회계','물류','생산','디자인','기획']},
    {key:'career',label:'경력',options:['신입','경력','인턴','경력무관']},
    {key:'hiring',label:'채용 형태',options:['신입','경력','인턴','정규직','계약직']},
    {key:'education',label:'학력',options:['학력무관','고졸','초대졸','대졸','석사','박사']},
    {key:'employment',label:'고용 형태',options:['정규직','계약직','인턴','파견직','프리랜서']},
    {key:'industry',label:'업종'},{key:'companyType',label:'기업 형태',options:['대기업','중견기업','중소기업','공기업','외국계기업','스타트업']}
  ];
  // 사람인 기업형태는 사람인 코드와 1:1로 대응하는 값만 고르게 한다(core.js의 코드표 순서). 직접 입력은 코드를 확인할 수 없어 받지 않는다.
  const saraminTypeOptions=Object.values(C.sarCompanyTypes);
  const saraminTypeUnverified='코스닥, 코스피, 코넥스, 주식회사, 유한회사, 협동조합, 사단법인, 재단법인, 외부감사법인, 병역특례 인증 업체, 수출입기업';
  const pendingConditions=['연봉','재택근무','근무 요일','복리후생','역세권·우대조건'];
  const splitTerms=value=>String(value||'').split(/[,，\n]/).map(x=>x.trim()).filter(Boolean);
  const list=value=>(Array.isArray(value)?value:[]).filter(Boolean).join(' · ')||'미확인';
  const stamp=value=>{if(!value||!Number.isFinite(Date.parse(value)))return '미확인';return new Intl.DateTimeFormat('ko-KR',{month:'numeric',day:'numeric',hour:'numeric',minute:'2-digit',timeZone:'Asia/Seoul'}).format(new Date(value));};
  function message(text,error=false){$('app-message').textContent=text;$('app-message').className=error?'error':'';}
  async function api(url,data){if(data!==undefined&&!ready)throw new Error('현재 프로젝트 서버를 다시 확인한 뒤 화면을 새로고침해주세요.');const r=await fetch(url,{cache:'no-store',...(data===undefined?{headers:state?.projectId?{'X-Job-Desk-Project':state.projectId}:{}}:{method:'POST',headers:{'Content-Type':'application/json','X-Job-Desk-Project':state.projectId},body:JSON.stringify(data)})});const value=await r.json();if(!r.ok){if(value.error?.includes('서버의 프로젝트가 바뀌었습니다'))ready=false;throw new Error(value.error||'요청을 처리하지 못했습니다.');}return value;}
  // 사람인은 수집에 쓴 view-detail 조각 주소 대신 입사지원 버튼이 있는 공고 본 화면으로 연다.
  const viewUrl=s=>{const m=/^https:\/\/www\.saramin\.co\.kr\/zf_user\/jobs\/relay\/view-detail\?rec_idx=(\d+)/.exec(s?.url||'');return m?'https://www.saramin.co.kr/zf_user/jobs/relay/view?rec_idx='+m[1]:s?.url;};
  function link(label,value){const a=node('a',label),safe=C.safeUrl(value);if(safe){a.href=safe;a.target='_blank';a.rel='noopener noreferrer';}return a;}
  function badge(text,kind=''){return node('span',text,'pill '+kind);}
  // 검색 조건은 모든 사이트 공통이다. 선택한 사이트 입력을 읽은 뒤 같은 값을 다른 사이트에도 둔다(주소·메모·채용형태·사용 여부는 사이트별).
  const commonKeys=['keyword','roles','locations','career','employment','education','industry','companyType','exclude','includeUnknown'];
  function shareConditions(){const from=settings.sites[selectedSite];for(const row of Object.values(settings.sites))if(row!==from)for(const key of commonKeys)row[key]=from[key];}
  // 처음 열 때 사이트별로 다르게 저장된 조건을 하나로 맞춘다. 조건이 있는 사람인 값을 우선하고, 주소에만 있던 기업형태는 선택값으로 옮긴다.
  function unifyConditions(){
    const sar=settings.sites.saramin;if(sar&&!splitTerms(sar.companyType).length){const q=C.saraminQuery(sar.nativeUrl);if(q?.ok&&q.params.company_type){const codes=C.saraminCompanyCodes(q.params.company_type).codes;if(codes.length)sar.companyType=codes.map(c=>C.sarCompanyTypes[c]).join(', ');}}
    const filled=row=>commonKeys.some(k=>k!=='includeUnknown'&&String(row?.[k]||'').trim());const base=filled(sar)?'saramin':state.schema.sites.map(x=>x.id).find(id=>filled(settings.sites[id]))||selectedSite;
    const keep=selectedSite;selectedSite=base;shareConditions();selectedSite=keep;
  }
  // 기업형태를 비우면 사람인 주소의 company_type도 지워, 다른 사이트 화면에서 비워도 이전 값이 요청에 되살아나지 않게 한다.
  function dropStaleSaraminType(){const sar=settings.sites.saramin;if(!sar?.nativeUrl||splitTerms(sar.companyType).length)return;try{const u=new URL(sar.nativeUrl);if(!u.searchParams.has('company_type')&&!u.searchParams.has('company_type[]'))return;const unknown=C.saraminCompanyCodes(u.searchParams.getAll('company_type').concat(u.searchParams.getAll('company_type[]')).join(',')).unknown;u.searchParams.delete('company_type');u.searchParams.delete('company_type[]');if(unknown.length)u.searchParams.set('company_type',unknown.join(','));sar.nativeUrl=u.href;}catch{}}
  function readForms(){if(!state)return;for(const input of $('profile-fields').querySelectorAll('[name]'))profile[input.name]=input.value;for(const input of $('site-fields').querySelectorAll('[name]'))settings.sites[selectedSite][input.name]=input.type==='checkbox'?input.checked:input.value;shareConditions();}
  function remember(){readForms();dirty=true;try{localStorage.setItem(draftKey,JSON.stringify({revision:editRevision,profile,settings}));$('save-status').textContent='아직 저장하지 않은 변경이 있습니다.';}catch{$('save-status').textContent='임시 보관 공간이 부족합니다. 조건을 저장해주세요.';}}
  function inputField(target,key,label,value,kind='text'){
    const wrap=node('label',label),input=node(kind==='textarea'?'textarea':'input');input.name=key;if(kind!=='textarea')input.type=kind;input.value=value||'';input.maxLength=target===$('profile-fields')?1000:4000;if(kind==='textarea')input.rows=2;wrap.append(input);target.append(wrap);
  }
  function renderForms(){
    $('profile-fields').replaceChildren();for(const [key,label]of Object.entries(profileLabels))inputField($('profile-fields'),key,label,profile[key]);
    $('site-fields').replaceChildren();const row=settings.sites[selectedSite];
    for(const [key,label]of [['includeUnknown','미확인 정보가 있는 공고도 남기기 (모든 사이트 공통)']]){const wrap=node('label',undefined,'check'),input=node('input');input.type='checkbox';input.name=key;input.checked=row[key];wrap.append(input,document.createTextNode(label));$('site-fields').append(wrap);}
    const site=state.schema.sites.find(s=>s.id===selectedSite);
    for(const key of new Set(['keyword',...site.fields,...commonKeys.filter(k=>k!=='includeUnknown')]))inputField($('site-fields'),key,siteLabels[key],row[key]);
    inputField($('site-fields'),'siteKeyword',siteLabels.siteKeyword,row.siteKeyword);
    if(selectedSite==='jasoseol')$('site-fields').append(dutyPicker(row));
    const extra=node('details'),summary=node('summary','세부조건 메모·기존 주소');extra.append(summary);const fields=node('div',undefined,'field-stack');extra.append(fields);inputField(fields,'nativeUrl',selectedSite==='saramin'?'사람인 검색 주소 (공식 공개 검색 주소만 · 저장하면 수집 요청에 적용)':siteLabels.nativeUrl,row.nativeUrl,'url');if(selectedSite==='saramin'){const note=node('p',undefined,'hint');note.id='saramin-url-note';fields.append(note);const show=()=>{note.textContent=saraminNote();};fields.addEventListener('input',show);fields.addEventListener('change',e=>{if(e.target.name==='nativeUrl'){adoptUrlCompanyType();show();}});show();}inputField(fields,'nativeNotes',siteLabels.nativeNotes,row.nativeNotes,'textarea');$('site-fields').append(extra);
    $('site-detail-name').textContent=site.name;$('detail-site').value=selectedSite;renderSitePick();$('direct-urls-editor').hidden=selectedSite!=='jasoseol'||!state.capabilities.directJasoseolUrls;
    // 이전에 주소에만 기업형태가 저장된 경우 입력칸(=저장값)도 같은 값으로 채운다. 요청 key는 같으므로 초안 변경으로 표시하지 않고, 다음 저장 때 저장값에 반영된다.
    if(selectedSite==='saramin'){const input=termInput('companyType'),fromUrl=companyTypeTerms();if(input&&!splitTerms(input.value).length&&fromUrl.length)input.value=fromUrl.join(', ');}
    renderChoices();
  }
  // 사이트마다 원격으로 보낼 수 있는 조건이 달라 한 줄씩 알린다.
  function capability(id){return id==='saramin'?'검색어·신입/경력·대졸·기업형태를 사람인 검색에 보내고, 사람인이 거른 항목은 다시 거르지 않습니다. 지역·고용형태 등은 받은 뒤 거릅니다.':id==='catch'?'검색어·표준 지역·고용형태를 보내고, 나머지는 받은 뒤 거릅니다.':id==='jasoseol'?'채용형태(신입·경력·인턴·계약직·교육)·기업형태·직무(사이트별 세부 설정)를 자소설닷컴 검색에 보내고 마감 공고는 빼고 최대 100건 확인합니다.':'검색어만 보내고 첫 페이지 최대 10건에서 나머지를 거릅니다.';}
  const pickedSites=()=>state.schema.sites.filter(s=>settings.sites[s.id]?.enabled).map(s=>s.id);
  // 검색할 사이트 = 각 사이트의 사용 여부. 저장하면 목록·가져오기에 같이 적용된다.
  function renderSitePick(){
    const list=$('site-pick-list');if(!list.querySelector('input'))for(const site of [...state.schema.sites].sort((a,b)=>['saramin','jasoseol','catch','jobkorea'].indexOf(a.id)-['saramin','jasoseol','catch','jobkorea'].indexOf(b.id))){const label=node('label'),input=node('input');input.type='checkbox';input.value=site.id;input.addEventListener('change',async()=>{readForms();settings.sites[site.id].enabled=input.checked;remember();renderSitePick();await save();showSource('all');});label.append(input,node('span',site.name));label.title=capability(site.id);list.append(label);}
    for(const input of list.querySelectorAll('input'))input.checked=Boolean(settings.sites[input.value]?.enabled);
    const allEnabled=state.schema.sites.every(s=>settings.sites[s.id]?.enabled);list.dataset.all=String(allEnabled);$('all-sites').setAttribute('aria-pressed',String(allEnabled));
    const picked=pickedSites();$('site-pick-note').textContent=picked.length?'':'검색할 사이트를 하나 이상 고르세요.';
    const missingForms=picked.filter(id=>!settings.sites[id]?.nativeQuery).map(id=>state.schema.sites.find(s=>s.id===id).name);$('site-capability').textContent=missingForms.length?missingForms.join('·')+' 검색 조건이 비어 있습니다. ‘세부 조건 펼치기’에서 조건을 고른 뒤 저장하세요.':'';
    renderCondSummary();
    if(!boardDecided){boardDecided=true;if(boardStored===null)setBoardOpen(false,false);}
    $('collect').textContent='↻ 공고 가져오기';$('collect').title=picked.length?'선택한 '+picked.length+'개 사이트의 공고를 갱신합니다.':'먼저 검색할 사이트를 선택하세요.';
  }
  // 자소설닷컴 직무: 사이트와 같은 대·중분류를 고르면 저장값(duties)에 id로 두고, 요청 때 가장 아래 분류까지 펼쳐 보낸다.
  function dutyPicker(row){
    const wrap=node('fieldset',undefined,'duty-pick'),hidden=node('input'),chosen=()=>new Set(splitTerms(hidden.value).map(Number));hidden.type='hidden';hidden.name='duties';hidden.value=row.duties||'';
    const set=ids=>{hidden.value=[...ids].join(', ');remember();renderForms();};
    wrap.append(node('legend','자소설닷컴 직무 (사이트 직무 분류와 같음 · 고르면 검색에 보냄)'),hidden);
    for(const [id,name] of C.jssDuties.filter(d=>d[2]===0)){
      const det=node('details'),sum=node('summary'),cb=node('input'),kids=C.jssDuties.filter(d=>d[2]===id);cb.type='checkbox';cb.dataset.duty=id;cb.checked=chosen().has(id);cb.addEventListener('click',e=>e.stopPropagation());
      cb.addEventListener('change',()=>{const s=chosen();kids.forEach(k=>s.delete(k[0]));if(cb.checked)s.add(id);else s.delete(id);set(s);});
      const picked=kids.filter(k=>chosen().has(k[0])).length;sum.append(cb,document.createTextNode(' '+name+(cb.checked?' · 전체':picked?' · '+picked+'개':'')));det.append(sum);
      const grid=node('div',undefined,'choice-grid');for(const [mid,mname] of kids){const l=node('label',undefined,'choice'),c=node('input');c.type='checkbox';c.dataset.duty=mid;c.checked=cb.checked||chosen().has(mid);c.disabled=cb.checked;c.addEventListener('change',()=>{const s=chosen();if(c.checked)s.add(mid);else s.delete(mid);set(s);});l.append(c,node('span',mname));grid.append(l);}
      det.append(grid);det.open=cb.checked||picked>0;wrap.append(det);
    }
    const leaves=C.jssLeafIds([...chosen()]).length;wrap.append(node('p',leaves?'선택한 직무를 하위 분류까지 펼쳐 '+leaves+'개로 보냅니다.':'직무를 고르지 않으면 모든 직무에서 찾습니다.','hint'));
    return wrap;
  }
  // ---- 사이트 검색 양식: 사이트 화면과 같은 선택지(jobs/site-tables)를 그대로 보여주고, 고른 코드를 사이트 조건(nativeQuery)으로 저장한다.
  const nativeTables={};let nativeSite='saramin',nativeState=null;
  async function nativeTable(site){if(!nativeTables[site]){const r=await fetch('/site-tables/'+site+'.json',{cache:'no-store'});if(!r.ok)throw new Error('사이트 양식을 불러오지 못했습니다. 프로그램을 다시 실행해주세요.');nativeTables[site]=await r.json();}return nativeTables[site];}
  const tokenOf=o=>o.param+':'+o.code;
  function nativeParse(table,query){
    const p=new URLSearchParams(query||''),sel=new Map(),has=(k,v)=>(p.get(k)||'').split(',').includes(v);
    for(const g of table.groups){if(g.kind==='text'){sel.set(g.key,p.get(g.param)||'');continue;}const set=new Set(),walk=opts=>{for(const o of opts){if(o.param==='edu'&&o.code.includes('=')?[...new URLSearchParams(o.code)].every(([k,v])=>p.get(k)===v):has(o.param,o.code))set.add(tokenOf(o));if(o.children)walk(o.children);}};walk(g.options||[]);sel.set(g.key,set);}
    return sel;
  }
  function nativeBuild(table,sel){
    const p=new Map(),add=(k,v)=>{if(!p.has(k))p.set(k,[]);if(!p.get(k).includes(v))p.get(k).push(v);};
    for(const g of table.groups){const v=sel.get(g.key);if(g.kind==='text'){if(String(v||'').trim())add(g.param,String(v).trim());continue;}for(const t of v||[]){const i=t.indexOf(':'),param=t.slice(0,i),code=t.slice(i+1);if(param==='edu'&&code.includes('='))for(const [k,x] of new URLSearchParams(code))add(k,x);else add(param,code);}}
    return [...p].map(([k,v])=>k+'='+v.map(encodeURIComponent).join(',')).join('&');
  }
  const leavesOf=o=>o.children?.length?o.children.flatMap(leavesOf):[o];
  function nativeLabels(table,sel){const lines=[];const find=(opts,t)=>{for(const o of opts){if(tokenOf(o)===t)return o;const c=o.children&&find(o.children,t);if(c)return c;}return null;};for(const g of table.groups){const v=sel.get(g.key);if(g.kind==='text'){if(String(v||'').trim())lines.push(g.label+': '+v);continue;}const names=[...(v||[])].map(t=>find(g.options||[],t)?.label).filter(Boolean);if(names.length)lines.push(g.label+': '+names.join(', '));}return lines;}
  function renderNativeForms(){
    const tabs=$('native-tabs');tabs.replaceChildren();
    for(const site of state.schema.sites){const b=node('button',site.name);b.type='button';b.setAttribute('role','tab');b.dataset.site=site.id;b.setAttribute('aria-selected',String(site.id===nativeSite));if(settings.sites[site.id]?.nativeQuery)b.append(node('span','· 양식 저장됨','saved'));b.addEventListener('click',()=>{nativeSite=site.id;nativeState=null;renderNativeForms();});tabs.append(b);}
    nativeTable(nativeSite).then(renderNativeBody).catch(e=>{$('native-body').replaceChildren(node('p',e.message,'help'));});
  }
  function renderNativeBody(table){
    if(table.site!==nativeSite)return;if(!nativeState||nativeState.site!==table.site)nativeState={site:table.site,sel:nativeParse(table,settings.sites[table.site]?.nativeQuery)};
    const sel=nativeState.sel,body=$('native-body');body.replaceChildren();const preview=node('p',undefined,'native-preview');preview.id='native-preview';
    const refresh=()=>{const lines=nativeLabels(table,sel);preview.textContent=lines.length?lines.join('\n'):'아직 고른 조건이 없습니다. 비어 있으면 이 사이트는 수집을 시작하지 않습니다.';};
    const limitOk=(g,set,adding)=>{if(!g.max||set.size+adding<=g.max)return true;message(g.label+'은(는) 최대 '+g.max+'개까지 고를 수 있습니다(사이트와 같은 제한).',true);return false;};
    for(const g of table.groups){
      const fs=node('fieldset',undefined,'native-group');fs.dataset.group=g.key;const legend=node('legend',g.label);if(g.max)legend.append(node('small','최대 '+g.max+'개'));fs.append(legend);
      if(g.kind==='text'){const input=node('input');input.type='search';input.className='native-text';input.maxLength=120;input.value=sel.get(g.key)||'';input.placeholder=g.label+' (선택)';input.addEventListener('input',()=>{sel.set(g.key,input.value);refresh();});fs.append(input);body.append(fs);continue;}
      const set=sel.get(g.key);
      if(g.kind!=='tree'){const wrap=node('div',undefined,'native-opts');for(const o of g.options){const l=node('label'),c=node('input');c.type='checkbox';c.dataset.token=tokenOf(o);c.checked=set.has(tokenOf(o));c.addEventListener('change',()=>{if(c.checked){if(g.single)set.clear();if(!limitOk(g,set,1)){c.checked=false;return;}set.add(tokenOf(o));}else set.delete(tokenOf(o));if(g.single)for(const x of wrap.querySelectorAll('input'))x.checked=set.has(x.dataset.token);refresh();});l.append(c,node('span',o.label));wrap.append(l);}fs.append(wrap);body.append(fs);continue;}
      const tree=node('div',undefined,'native-tree');
      for(const o of g.options){
        const det=node('details'),sum=node('summary'),c=node('input'),leaves=leavesOf(o),count=()=>g.leafOnly?leaves.filter(x=>set.has(tokenOf(x))).length:(o.children||[]).filter(x=>set.has(tokenOf(x))).length;
        c.type='checkbox';c.dataset.token=tokenOf(o);c.addEventListener('click',e=>e.stopPropagation());
        const label=node('span');const paint=()=>{const n=count();c.checked=g.leafOnly?n===leaves.length:set.has(tokenOf(o));c.indeterminate=!c.checked&&n>0;label.textContent=' '+o.label+(c.checked?' · 전체':n?' · '+n+'개':'');for(const k of det.querySelectorAll('.kids input')){k.checked=set.has(k.dataset.token)||(!g.leafOnly&&c.checked);k.disabled=!g.leafOnly&&c.checked;}};
        c.addEventListener('change',()=>{if(g.leafOnly){if(c.checked){const add=leaves.filter(x=>!set.has(tokenOf(x)));if(!limitOk(g,set,add.length)){c.checked=false;return;}add.forEach(x=>set.add(tokenOf(x)));}else leaves.forEach(x=>set.delete(tokenOf(x)));}else{if(c.checked){(o.children||[]).forEach(x=>set.delete(tokenOf(x)));if(!limitOk(g,set,1)){c.checked=false;return;}set.add(tokenOf(o));}else set.delete(tokenOf(o));}paint();refresh();});
        sum.append(label);det.append(sum);const item=node('div',undefined,'tree-item');item.append(c,det);
        // 하위 목록은 펼칠 때 만든다(사람인 직업처럼 수천 개인 목록).
        det.addEventListener('toggle',()=>{if(!det.open||det.querySelector('.kids'))return;const kids=node('div',undefined,'kids');for(const k of (g.leafOnly?leaves:o.children||[])){const l=node('label'),kc=node('input');kc.type='checkbox';kc.dataset.token=tokenOf(k);kc.addEventListener('change',()=>{if(kc.checked){if(!limitOk(g,set,1)){kc.checked=false;return;}set.add(tokenOf(k));}else set.delete(tokenOf(k));paint();refresh();});l.append(kc,node('span',k.label));kids.append(l);}det.append(kids);paint();});
        paint();tree.append(item);
      }
      fs.append(tree);body.append(fs);
    }
    const actions=node('div',undefined,'native-actions'),saveBtn=node('button','이 사이트 양식 저장'),clearBtn=node('button','양식 비우기');
    saveBtn.type='button';saveBtn.className='primary';clearBtn.type='button';
    saveBtn.addEventListener('click',async()=>{readForms();settings.sites[table.site].nativeQuery=nativeBuild(table,sel);remember();await save();nativeState=null;renderNativeForms();renderCondSummary();});
    clearBtn.addEventListener('click',async()=>{readForms();settings.sites[table.site].nativeQuery='';remember();await save();nativeState=null;renderNativeForms();renderCondSummary();});
    actions.append(saveBtn,clearBtn);body.prepend(actions,preview);refresh();
  }
  function termInput(key){return $('site-fields').querySelector('[name="'+key+'"]');}
  // 입력칸이 기준값이다. 선택 UI는 입력칸 값을 바꾼 뒤 기존 초안 보관(remember)을 그대로 거친다.
  // 사람인 기업형태: 저장된 선택값이 비어 있고 주소에만 company_type이 있으면(이전 저장) 주소의 값을 현재 선택으로 본다. 저장값은 사용자가 바꾸기 전까지 건드리지 않는다.
  function companyTypeTerms(){const input=termInput('companyType'),typed=splitTerms(input?.value);if(typed.length||selectedSite!=='saramin')return typed;const q=C.saraminQuery(termInput('nativeUrl')?.value);return q?.ok&&q.params.company_type?C.saraminCompanyCodes(q.params.company_type).codes.map(c=>C.sarCompanyTypes[c]):[];}
  const currentTerms=key=>key==='companyType'?companyTypeTerms():splitTerms(termInput(key)?.value);
  // 선택값을 바꾸면 사람인 주소의 company_type도 같은 값으로 맞춘다. 비우면 주소에서도 지워 이전 값이 되살아나지 않게 한다.
  function syncSaraminUrl(){
    if(selectedSite!=='saramin')return;const url=termInput('nativeUrl');if(!url||!url.value.trim())return;let u;try{u=new URL(url.value.trim());}catch{return;}
    if(u.protocol!=='https:'||u.hostname!=='www.saramin.co.kr'||u.pathname!=='/zf_user/search')return;
    const extra=C.saraminCompanyCodes(u.searchParams.getAll('company_type').concat(u.searchParams.getAll('company_type[]')).join(',')).unknown,codes=[...C.saraminCompanyCodes(termInput('companyType')?.value).codes,...extra];u.searchParams.delete('company_type[]');if(codes.length)u.searchParams.set('company_type',codes.join(','));else u.searchParams.delete('company_type');url.value=u.href;
  }
  // 사람인 주소를 직접 붙여넣거나 고치면 그 주소의 기업형태를 선택값으로 가져온다. 주소를 읽을 수 없으면 선택값을 건드리지 않는다.
  function adoptUrlCompanyType(){
    if(selectedSite!=='saramin')return;const q=C.saraminQuery(termInput('nativeUrl')?.value);if(!q?.ok)return;const parsed=C.saraminCompanyCodes(q.params.company_type||'');
    const input=termInput('companyType'),text=parsed.codes.map(c=>C.sarCompanyTypes[c]).join(', ');if(input&&input.value!==text){input.value=text;remember();}syncChoices();
  }
  function saraminExtra(){return {keyword:termInput('keyword')?.value,career:termInput('career')?.value,education:termInput('education')?.value};}
  function saraminNote(){const q=C.saraminQuery(termInput('nativeUrl')?.value,termInput('companyType')?.value,saraminExtra());return !q?'주소가 비어 있으면 검색어만 요청에 보냅니다.':q.ok?'요청에 적용: '+q.labels.join(' · ')+(q.covered.length?' / 이 조건이 덮는 항목('+q.covered.join(', ')+')은 로컬 문구 검사로 다시 탈락시키지 않습니다.':'')+(q.notes.length?' / '+q.notes.join(' '):''):q.error;}
  function setTerms(key,terms){const input=termInput(key);if(!input)return;input.value=terms.join(', ');if(key==='companyType')syncSaraminUrl();remember();syncChoices();}
  function toggleTerm(key,term,on){const input=termInput(key);if(!input)return;const terms=currentTerms(key).filter(t=>t.toLocaleLowerCase('ko')!==term.toLocaleLowerCase('ko'));if(on)terms.push(term);setTerms(key,terms);}
  function renderChoices(){
    const box=$('choice-groups'),applied=new Set(['roles','locations','career','employment','education','industry','companyType']);box.replaceChildren();$('choice-unsupported').replaceChildren();
    for(const group of choiceGroups.filter(g=>applied.has(g.key))){
      const fs=node('fieldset',undefined,'choice-group');fs.dataset.field=group.key;fs.append(node('legend',group.label));
      const fixed=group.key==='companyType',options=fixed?saraminTypeOptions:group.options;
      if(options){const grid=node('div',undefined,'choice-grid');for(const option of options){const label=node('label',undefined,'choice'),input=node('input');input.type='checkbox';input.value=option;input.addEventListener('change',()=>toggleTerm(group.key,option,input.checked));label.append(input,node('span',option));grid.append(label);}fs.append(grid);}
      const row=node('div',undefined,'choice-add'),add=node('input'),button=node('button','추가'),commit=()=>{const value=add.value.trim();if(!value)return;toggleTerm(group.key,value,true);add.value='';};add.type='text';add.maxLength=100;add.placeholder=group.options?'직접 추가':group.label+' 문구 입력';add.setAttribute('aria-label',group.label+' 직접 추가');button.type='button';button.addEventListener('click',commit);add.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.isComposing){e.preventDefault();commit();}});row.append(add,button);if(fixed)fs.append(node('p','사람인 기업형태 코드가 확인된 항목만 고를 수 있습니다. 선택하면 선택칩, 저장값, 아래 사람인 검색 주소의 company_type이 같은 값으로 바뀌고 수집 요청에 전달됩니다. '+saraminTypeUnverified+'는 사람인 코드를 아직 확인하지 못해 여기서 고를 수 없습니다. 사람인에서 직접 고른 검색 주소를 붙여넣으면 그 코드는 주소대로 요청에 보냅니다.','help'));else fs.append(row);box.append(fs);
    }
    const fs=node('fieldset',undefined,'choice-group');fs.dataset.field='exclude';fs.append(node('legend','제외 검색어'));const row=node('div',undefined,'choice-add'),add=node('input'),button=node('button','추가'),commit=()=>{const value=add.value.trim();if(!value)return;toggleTerm('exclude',value,true);add.value='';};add.type='text';add.maxLength=100;add.placeholder='빼고 싶은 말';add.setAttribute('aria-label','제외 검색어 추가');button.type='button';button.addEventListener('click',commit);add.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.isComposing){e.preventDefault();commit();}});row.append(add,button);fs.append(row);box.append(fs);
    // 저장된 공고에 값이 없거나 이 사이트 목록 필터가 쓰지 않는 항목은 선택할 수 없게 두고 이유를 보여준다.
    const missing=[...pendingConditions.map(label=>label+' · 원문 확인 필요'),...choiceGroups.filter(g=>['education','career','employment','industry','companyType'].includes(g.key)&&!applied.has(g.key)&&!(['career','employment'].includes(g.key)&&applied.has('hiring'))).map(g=>g.label+' · 이 사이트 목록에 적용하지 않음')];
    const pending=$('choice-unsupported');pending.append(node('p','아직 적용되지 않는 조건','chip-label'));const chips=node('div',undefined,'chips');for(const text of missing){const chip=node('span',text,'chip disabled');chip.setAttribute('aria-disabled','true');chips.append(chip);}pending.append(chips,node('p','이 조건은 저장된 공고에 값이 없거나 이 화면의 목록 필터가 쓰지 않아 목록을 거르지 않습니다. 원 사이트에서 직접 설정하고 ‘세부조건 메모·기존 주소’에 남겨 두세요. 메모는 보관만 하고 필터에는 적용되지 않습니다.','help'));
    syncChoices();
  }
  function syncChoices(){
    if(!state||!settings)return;const row=settings.sites[selectedSite];
    for(const fs of $('choice-groups').querySelectorAll('fieldset[data-field]')){const chosen=currentTerms(fs.dataset.field).map(t=>t.toLocaleLowerCase('ko'));for(const input of fs.querySelectorAll('input[type=checkbox]'))input.checked=chosen.includes(input.value.toLocaleLowerCase('ko'));}
    if(document.activeElement!==$('choice-keyword'))$('choice-keyword').value=row.keyword||'';
    const chips=$('chip-list');chips.replaceChildren();
    const make=(label,text,onRemove)=>{const chip=node('span',undefined,'chip'),remove=node('button','×','chip-x');remove.type='button';remove.setAttribute('aria-label',label+' '+text+' 해제');remove.addEventListener('click',onRemove);chip.append(node('span',label+' · '+text),remove);chips.append(chip);};
    if(row.keyword)make('검색어',row.keyword,()=>{const input=termInput('keyword');if(input){input.value='';remember();syncChoices();}});
    for(const group of [...choiceGroups,{key:'exclude',label:'제외'}])for(const term of (termInput(group.key)?currentTerms(group.key):splitTerms(row[group.key]))){
      if(!termInput(group.key)){chips.append(node('span',group.label+' · '+term+' (이 사이트 목록에 적용하지 않음)','chip disabled'));continue;}
      make(group.label,term,()=>setTerms(group.key,currentTerms(group.key).filter(t=>t!==term)));
    }
    const note=$('saramin-url-note');if(note)note.textContent=saraminNote();
    const sq=selectedSite==='saramin'?C.saraminQuery(termInput('nativeUrl')?.value??row.nativeUrl,termInput('companyType')?.value??row.companyType,termInput('keyword')?saraminExtra():row):null;if(sq&&!sq.ok)chips.append(node('span',sq.error,'chip disabled'));if(row.nativeNotes||(row.nativeUrl&&!sq?.ok))chips.append(node('span','사이트 세부조건 메모 · 목록에 적용되지 않음','chip disabled'));
    if(!chips.children.length)chips.append(node('span','선택한 조건이 없습니다. 모든 공고를 대상으로 합니다.','help'));
  }
  function resetConditions(){
    if(!state||!settings||saving)return;
    // 선택한 사이트의 조건 초안만 비운다. 저장하기 전에는 기존 저장 조건·공고·개인 조건·메모는 바뀌지 않는다.
    for(const key of ['keyword','roles','locations','career','education','employment','industry','companyType','hiring','exclude','nativeUrl']){const input=termInput(key);if(input)input.value='';}
    $('choice-keyword').value='';remember();syncChoices();
    if(selectedSite==='saramin'&&$('saramin-url-note'))$('saramin-url-note').textContent=saraminNote();
    message('이 사이트의 조건을 비웠습니다. ‘조건 저장·적용’을 눌러야 저장되고 목록에 적용됩니다.');
  }
  async function save(event){
    event?.preventDefault();if(composing||saving)return;readForms();dropStaleSaraminType();saving=true;
    const controls=[...document.querySelectorAll('#profile-form input,#profile-form button,#site-form input,#site-form textarea,#site-form button,#site-pick input,#all-sites,#detail-site,#condition-board #choice-panel input,#condition-board #choice-panel button,#choice-keyword,#board-save')];controls.forEach(e=>e.disabled=true);
    try{state=await api('/api/preferences',{revision:editRevision,settings,profile});settings=structuredClone(state.settings);profile=structuredClone(state.profile);editRevision=state.revision;dirty=false;conflict=false;localStorage.removeItem(draftKey);$('restore-draft').hidden=true;$('restore-archive').hidden=!pendingDraft;$('save-status').textContent='프로젝트에 저장했습니다. 다시 실행해도 유지됩니다.';message('조건을 저장하고 현재 목록에 적용했습니다.');renderForms();showSource(selectedSite);}
    catch(e){message(e.message,true);}
    finally{saving=false;controls.forEach(e=>e.disabled=false);}
  }
  // ---- 같은 공고 묶기(화면 전용): 저장 데이터는 그대로 두고, 확실한 경우만 한 건으로 합쳐 보여준다.
  // 조건: 사이트가 서로 다르고, 회사명이 같고, 제목이 거의 같고(2글자 조각 유사도 0.8 이상), 마감 날짜가 둘 다 명시되어 같음.
  // 묶음은 구성원 모두가 서로 조건을 만족하는 경우(전체 연결)에만 만들고, 한 사이트에서 둘 이상 걸리면 모호하므로 묶지 않는다(후보로만 남김).
  let groupOn=true,mergedCount=0;
  const SITE_RANK=['사람인','잡코리아','캐치','자소설닷컴'];
  const compact=s=>String(s||'').normalize('NFKC').replace(/\(주\)|㈜|주식회사|\(유\)|유한회사/g,'').replace(/[\s()[\]【】「」·,./\-_~#]/g,'').toLowerCase();
  const bigramSet=s=>{const set=new Set();for(let i=0;i<s.length-1;i++)set.add(s.slice(i,i+2));return set;};
  function titleSimilarity(a,b){const x=bigramSet(a),y=bigramSet(b);if(!x.size||!y.size)return 0;let common=0;for(const g of x)if(y.has(g))common++;return common/(x.size+y.size-common);}
  const siteSet=r=>new Set((r.sources||[]).filter(s=>!s.official).map(s=>s.site));
  const deadlineDay=r=>r.deadline?.at?ymd(r.deadline.at):null;
  // 제목 비교용: 해시태그·앞 대괄호 말머리·회사명을 빼고, 괄호 안 구분 문구(직무·근무지)를 따로 모은다.
  // 앞 [말머리]와 #해시태그는 한쪽에만 있으면 장식으로 보고 빼지만, 양쪽에 있는데 다르면(예: [생산직]/[연구직]) 다른 공고로 본다.
  function coreTitle(r){const raw=String(r.title||'').normalize('NFKC'),tagMatch=/^\s*\[([^\]]*)\]\s*/.exec(raw),hash=[...raw.matchAll(/#\S+/g)].map(m=>compact(m[0])).sort().join('|'),t=raw.replace(/#\S+/g,' ').replace(/^\s*\[[^\]]*\]\s*/,''),co=compact(r.company);let c=compact(t);if(co&&c.includes(co))c=c.replace(co+'그룹','').replace(co,'');c=c.replace(/^['’]?(\d{2})년/,'20$1년').replace(/^(20\d{2})년/,'$1');const cls=[...new Set(c.match(/신입|경력|인턴/g)||[])].sort().join('');c=c.replace(/신입|경력|인턴/g,'');return {c,cls,tag:tagMatch?compact(tagMatch[1]):'',hash,par:[...t.matchAll(/[(（]([^)）]*)[)）]/g)].map(m=>compact(m[1])).filter(x=>x&&x!=='주'&&x!=='유').sort().join('|')};}
  function sameNotice(a,b){const sa=siteSet(a),sb=siteSet(b);if(!sa.size||!sb.size||[...sa].some(s=>sb.has(s)))return false;const da=deadlineDay(a),db=deadlineDay(b);if(!da||da!==db)return false;const ca=coreTitle(a),cb=coreTitle(b);if(!ca.c||!cb.c)return false;
    if(ca.par&&cb.par&&ca.par!==cb.par)return false;if(ca.cls&&cb.cls&&ca.cls!==cb.cls)return false;if(ca.tag&&cb.tag&&ca.tag!==cb.tag)return false;if(ca.hash&&cb.hash&&ca.hash!==cb.hash)return false;const [s,l]=ca.c.length<=cb.c.length?[ca.c,cb.c]:[cb.c,ca.c];if(l!==s&&(l.startsWith(s)||l.endsWith(s))&&l.length-s.length>=3)return false;return titleSimilarity(ca.c,cb.c)>=0.8;}
  function pickRepresentative(members){const hasDetail=r=>Boolean((r.detailText||r.latestObservation?.detailText||'').trim()),rank=r=>{const i=SITE_RANK.indexOf([...siteSet(r)][0]);return i<0?9:i;};return [...members].sort((a,b)=>(hasDetail(b)-hasDetail(a))||((a.partial?1:0)-(b.partial?1:0))||(rank(a)-rank(b))||String(a.id).localeCompare(String(b.id)))[0];}
  function groupRecords(list){
    mergedCount=0;const buckets=new Map();for(const r of list){const key=compact(r.company);if(!key)continue;if(!buckets.has(key))buckets.set(key,[]);buckets.get(key).push(r);}
    const replaced=new Map(),dropped=new Set();
    for(const bucket of buckets.values()){
      if(bucket.length<2)continue;const adj=new Map(bucket.map(r=>[r.id,new Set()]));
      for(let i=0;i<bucket.length;i++)for(let k=i+1;k<bucket.length;k++)if(sameNotice(bucket[i],bucket[k])){adj.get(bucket[i].id).add(bucket[k].id);adj.get(bucket[k].id).add(bucket[i].id);}
      const seen=new Set();
      for(const start of bucket){
        if(seen.has(start.id)||!adj.get(start.id).size)continue;const stack=[start.id],comp=[];seen.add(start.id);
        while(stack.length){const id=stack.pop();comp.push(id);for(const next of adj.get(id))if(!seen.has(next)){seen.add(next);stack.push(next);}}
        const members=comp.map(id=>bucket.find(r=>r.id===id)),clique=members.every(m=>adj.get(m.id).size===members.length-1);
        const siteCount=members.reduce((n,m)=>n+siteSet(m).size,0),siteUnion=new Set(members.flatMap(m=>[...siteSet(m)])).size;
        if(!clique||siteCount!==siteUnion)continue;
        const rep=pickRepresentative(members),others=members.filter(m=>m!==rep),urls=new Set(),sources=[];
        for(const s of [...rep.sources,...others.flatMap(m=>m.sources)])if(!urls.has(s.url)){urls.add(s.url);sources.push(s);}
        replaced.set(rep.id,{...rep,sources,startAt:members.map(m=>m.startAt).filter(Boolean).sort()[0]||rep.startAt,memberRecords:members,memberIds:members.map(m=>m.id),members:members.map(m=>({id:m.id,site:[...siteSet(m)][0]||'',title:m.title,deadline:m.deadline?.label||'',url:viewUrl((m.sources||[])[0])}))});
        for(const o of others)dropped.add(o.id);mergedCount++;
      }
    }
    return list.filter(r=>!dropped.has(r.id)).map(r=>replaced.get(r.id)||r);
  }
  // 같은 공고(출처 중복)와 같은 채용(통합·직무별 공고)은 별개다.
  // 사용자와 확인한 별칭만 연결한다. 회사명 포함 관계나 SK/한화 접두어 제거는 하지 않는다.
  // ---- 같은 채용 묶음(통합 모집요강 + 직무별 공고). 연결은 근거가 있을 때만 하고, 공고는 삭제·합치지 않는다.
  // 근거 1(제목): 회사·마감 날짜가 같고, 회차(연도 + 상반기/하반기/분기/월)가 제목에 적혀 있으며, 직무 표기(괄호·' - 직무')를 뺀 제목과 채용 구분이 같음.
  // 근거 2(본문): 회사·마감 날짜가 같고, 직무별 공고의 '모집부문'(구체적인 직무명)이 통합 공고 본문에 그대로 나열됨.
  // 상시·수시 채용, 회사명 포함 관계(한화/한화임팩트), 마감일만 같은 경우는 연결하지 않는다.
  // 확인된 회사 별칭만 같은 회사로 본다. 새 별칭은 근거(원문 대조)를 적어 여기에 추가한다.
  const CAMPAIGN_COMPANY_ALIASES=[{names:['에스케이피유코어','피유코어'],evidence:'2026-10-30 사용자 확인 + 사람인(에스케이피유코어)·자소설닷컴·캐치(피유코어)의 같은 하반기 대졸 신입 공개채용(마감 11/1 23:59) 제목·본문 대조'}];
  const aliasCanon=new Map(),aliasShown=new Map();
  for(const a of CAMPAIGN_COMPANY_ALIASES){const canon=compact(a.names[a.names.length-1]);for(const n of a.names){aliasCanon.set(compact(n),canon);aliasShown.set(compact(n),a.names[a.names.length-1]);}}
  const companyIdentity=r=>aliasCanon.get(compact(r.company))||compact(r.company);
  const detailOf=r=>String(r.detailText||r.latestObservation?.detailText||'').normalize('NFKC').replace(/\s+/g,' ').trim();
  const PERIOD=/(상반기|하반기|[1-4]분기|(?:[1-9]|1[0-2])월)/,TEMPORARY=/상시|수시/;
  function campaignDescriptor(r){
    const companyKey=companyIdentity(r),day=deadlineDay(r);
    if(!companyKey||!day)return null;
    let title=String(r.title||'').normalize('NFKC').replace(/#\S+/g,'').trim();
    const lead=/^\[([^\]]+)\]\s*/.exec(title);
    if(lead){const label=compact(lead[1]),pair=/^\s*\[([^\]]+)\]\s*\[([^\]]+)\]/.exec(detailOf(r));
      // 앞 대괄호는 회사명·별칭·공채이거나, 본문이 '[회사명] [같은 표기]'로 병기한 영문 표기일 때만 말머리로 본다.
      if([compact(r.company),companyKey,'공채'].includes(label)||(pair&&compact(pair[1])===compact(r.company)&&compact(pair[2])===label))title=title.slice(lead[0].length).trim();}
    const roles=[],dash=/(?:\s[-–—]\s+|(?<=채용|모집|공채|공고)[-–—]\s*)(.+)$/.exec(title);
    if(dash&&dash[1].replace(/\([^)]*\)/g,'').replace(/신입|경력|인턴/g,'').replace(/[\s·,/및]/g,'').length>=2){roles.push(dash[1].trim());title=title.slice(0,dash.index).trim();}
    roles.push(...[...title.matchAll(/\(([^)]+)\)/g)].map(m=>m[1].trim()).filter(Boolean));
    title=title.replace(/\([^)]*\)/g,' ').replace(/\s+/g,' ').trim();
    title=title.replace(/^['’]?(\d{2})년/,(_m,y)=>'20'+y+'년').replace(/^(20\d{2})(?=\s)/,'$1년');
    let key=compact(title);
    for(const name of new Set([compact(r.company),companyKey])){if(name&&key.includes(name))key=key.replace(name+'그룹','').replace(name,'');}
    key=key.replace(/공개채용/g,'공채').replace(/채용공고/g,'채용').replace(/모집/g,'채용');
    // 회차를 추정하지 않는다. 명시된 연도·반기/분기/월과 채용 표기가 모두 필요하고, 상시·수시 채용은 제외한다.
    if(!/20\d{2}년/.test(key)||!PERIOD.test(key)||!/(채용|공채)/.test(key)||TEMPORARY.test(String(r.title||'')))return null;
    const classes=[...new Set(key.match(/신입|경력|인턴/g)||[])].sort().join('+'),base=key.replace(/신입|경력|인턴/g,'').replace(/[및]/g,'');
    return {key:JSON.stringify([companyKey,base,classes,day]),company:aliasShown.get(compact(r.company))||r.company,label:title,role:roles.join(' · '),day,evidence:'같은 회사·마감일·모집 회차와 제목(직무 표기 제외) 일치'};
  }
  // 직무별 공고의 '모집부문'이 하나의 구체적인 직무명이면 그것을 돌려준다(여러 직무를 한 번에 모집하는 공고는 제외).
  function umbrellaRole(r){
    const m=/모집부문\s*:\s*(.+?)\s*(?:근무지|고용형태|\[|$)/.exec(detailOf(r));if(!m)return null;
    const parts=m[1].split(/\s*,\s*/).map(s=>s.trim()).filter(Boolean);if(parts.length!==1)return null;
    const role=parts[0];return role.length>=6&&(/[A-Za-z]/.test(role)||/\s/.test(role))?role:null;
  }
  function umbrellaBundles(rows){
    const bundles=new Map();
    for(const child of rows){
      const role=umbrellaRole(child),day=deadlineDay(child);if(!role||!day||TEMPORARY.test(String(child.title||'')))continue;
      const parents=rows.filter(p=>p.id!==child.id&&companyIdentity(p)===companyIdentity(child)&&deadlineDay(p)===day&&!TEMPORARY.test(String(p.title||''))&&!umbrellaRole(p)&&detailOf(p).length>=300&&detailOf(p).toLowerCase().includes(role.toLowerCase()));
      if(parents.length!==1)continue;
      const parent=parents[0],key=JSON.stringify(['umbrella',parent.id]);
      if(!bundles.has(key))bundles.set(key,{key,company:aliasShown.get(compact(parent.company))||parent.company,label:parent.title,day,rows:[parent],roles:{[parent.id]:''},campaign:true,evidence:'통합 공고 본문에 직무별 공고의 모집부문이 그대로 나열됨'});
      const b=bundles.get(key);b.rows.push(child);b.roles[child.id]=role;
    }
    return [...bundles.values()];
  }
  function campaignUnits(rows,enabled=true){
    if(!enabled)return rows.map(r=>({key:r.id,rows:[r],campaign:false}));
    const buckets=new Map(),descriptors=new Map();
    for(const r of rows){const d=campaignDescriptor(r);if(!d)continue;descriptors.set(r.id,d);if(!buckets.has(d.key))buckets.set(d.key,{...d,rows:[],campaign:true});buckets.get(d.key).rows.push(r);}
    const bundleOf=new Map(),taken=new Set();
    for(const b of buckets.values()){if(b.rows.length<2||!b.rows.some(r=>descriptors.get(r.id).role))continue;b.rows.sort((x,y)=>Boolean(descriptors.get(x.id).role)-Boolean(descriptors.get(y.id).role));const parts=b.rows.map(r=>descriptors.get(r.id).role.split(' · ').filter(Boolean)),common=parts.every(p=>p.length)?parts[0].filter(x=>parts.every(p=>p.includes(x))):[];b.roles=Object.fromEntries(b.rows.map((r,i)=>{const own=parts[i].filter(x=>!common.includes(x));return [r.id,(own.length?own:parts[i]).join(' · ')];}));for(const r of b.rows){bundleOf.set(r.id,b);taken.add(r.id);}}
    for(const b of umbrellaBundles(rows.filter(r=>!taken.has(r.id))))for(const r of b.rows)bundleOf.set(r.id,b);
    const used=new Set(),units=[];
    for(const r of rows){const b=bundleOf.get(r.id);if(!b){units.push({key:r.id,rows:[r],campaign:false});continue;}if(used.has(b.key))continue;used.add(b.key);units.push(b);}
    return units;
  }
  const campaignOpen=new Map();let displayUnits=[],campaignByRecord=new Map();
  const listUnits=rows=>campaignUnits(rows,groupOn&&$('site-select').value==='all');
  const memberIdsOf=r=>r.memberIds||[r.id];
  const candidateIds=r=>[...new Set(memberIdsOf(r).flatMap(id=>state.data.duplicates?.[id]||[]))].filter(id=>!memberIdsOf(r).includes(id));
  // 조건·검색·학력·전공·'아직 안 봄' 필터는 원본 공고 한 건씩 적용한 뒤, 통과한 공고끼리만 묶는다(묶음 수·건수가 보이는 목록과 일치).
  let selectedMembers=new Set();
  function matchesCareer(r){const mode=$('career-select').value;if(mode==='all')return true;const text=(Array.isArray(r.career)?r.career.join(' '):String(r.career||'')).normalize('NFKC').replace(/\s+/g,'');return /신입/.test(text)||(mode==='entry'&&/경력무관|^무관$/.test(text));}
  function records(){loadMajorPrefs();loadCareerPrefs();const commonGroup=['new','check'].includes(group)?'open':group;let rows=C.select(state.data.records,state.settings,state.schema,{site:$('site-select').value,group:commonGroup,search:$('search').value.trim()});if(group==='new')rows=rows.filter(r=>r.discoveredAt&&(!seenSet().has(r.id)||r.id===selectedId||selectedMembers.has(r.id)));rows=rows.filter(matchesEducation).filter(matchesMajor).filter(matchesCareer);if(group==='check')rows=rows.filter(r=>r.eligibility?.status!=='충족'||r.partial);rows=groupOn?groupRecords(rows):(mergedCount=0,rows);return C.sortRecords(rows,sortKey);}
  function resetPage(){page=1;}
  function showSource(id){
    if(id!=='all'&&!state.schema.sites.some(s=>s.id===id))return;
    if(id!=='all'&&selectedSite!==id){readForms();selectedSite=id;renderForms();}
    $('site-select').value=id;try{localStorage.setItem(draftKey+':list-source',id);}catch{}
    resetPage();renderData();
  }
  function cell(label,value,cls=''){const c=node('span',undefined,'job-cell '+cls);c.append(node('span',label,'job-cell-label'),node('span',value||'미확인','job-cell-value'));return c;}
  function renderPager(pg,total){
    const nav=$('pager');nav.replaceChildren();if(total<=pageSize&&pg.pages<=1)return;
    const go=n=>{const target=Math.min(Math.max(1,n),pg.pages);if(target===page)return;page=target;const rows=listUnits(records()).slice(pg.size*(target-1),pg.size*target).flatMap(unit=>unit.rows);if(!rows.some(r=>r.id===selectedId))selectedId=rows[0]?.id||null;renderData();$('jobs-panel').scrollIntoView({block:'start'});};
    const button=(text,target,disabled,current)=>{const b=node('button',text);b.type='button';b.disabled=disabled;if(current)b.setAttribute('aria-current','page');b.addEventListener('click',()=>go(target));nav.append(b);return b;};
    button('이전',pg.page-1,pg.page<=1);
    const from=Math.max(1,Math.min(pg.page-2,pg.pages-4)),to=Math.min(pg.pages,from+4);for(let n=from;n<=to;n++){const b=button(String(n),n,false,n===pg.page);b.setAttribute('aria-label',n+'페이지');}
    button('다음',pg.page+1,pg.page>=pg.pages);nav.append(node('span',pg.page+' / '+pg.pages+' 페이지','help'));
  }
  // 마감까지 남은 날짜는 달력 날짜 차이로 센다(오늘 23:59 마감 = 오늘 마감).
  function daysLeft(r){const day=v=>Date.parse(new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Seoul'}).format(v));return Math.round((day(Date.parse(r.deadline.at))-day(Date.now()))/86400000);}
  function ddayInfo(r){const status=C.state(r);if(status==='closed')return {text:'마감',kind:'closed'};if(status==='unknown')return {text:'마감일 미확인',kind:'unknown'};const days=Math.max(0,daysLeft(r));return days===0?{text:'오늘 마감',kind:'hot'}:days===1?{text:'내일 마감',kind:'hot'}:{text:'D-'+days,kind:days<=3?'soon':'open'};}
  // 아직 열어보지 않은 새 공고: 이 브라우저에서 목록을 눌러 본 공고 번호만 기억한다.
  let seenIds=null;
  function seenSet(){if(!seenIds){try{seenIds=new Set(JSON.parse(localStorage.getItem(draftKey+':seen')||'[]'));}catch{seenIds=new Set();}}return seenIds;}
  function markSeen(id){const s=seenSet();if(!id||s.has(id))return;s.add(id);try{localStorage.setItem(draftKey+':seen',JSON.stringify([...s].slice(-3000)));}catch{}}
  // ---- 전공 판정: 사람인 외 사이트에는 전공 검색이 없어 받은 공고 본문에서 전공 문구를 읽어 태그를 붙인다(내 브라우저에만 저장).
  // 전공 명시 > 화학 계열 > 이공계 > 전공 무관 > 다른 전공만 > 미확인 순으로 판정한다. 이미지 요강 등 글자가 없으면 미확인으로 둔다.
  const MAJOR_GROUPS=[{"name": "화학공학", "strong": ["화공", "화학공학", "화학생물공학", "화공생물", "화공생명", "응용화학공학", "화학공정", "chemical engineering"], "related": ["화학", "응용화학", "정밀화학", "고분자", "분석화학", "유기화학", "무기화학", "공업화학", "물리화학", "생화학"], "science": true}, {"name": "기계공학", "strong": ["기계공학", "기계", "기계설계", "mechanical engineering"], "related": ["자동차", "메카트로닉스"], "science": true}, {"name": "전기공학", "strong": ["전기공학", "전기", "전기전자공학", "electrical engineering"], "related": ["전자", "제어"], "science": true}, {"name": "전자공학", "strong": ["전자공학", "전자", "전기전자공학", "electronic engineering"], "related": ["전기", "반도체", "제어"], "science": true}, {"name": "컴퓨터공학", "strong": ["컴퓨터공학", "컴공", "컴퓨터", "전산학", "전산", "computer science"], "related": ["소프트웨어", "정보통신"], "science": true}, {"name": "소프트웨어", "strong": ["소프트웨어공학", "소프트웨어", "소프트웨어학", "소프트웨어융합", "software engineering"], "related": ["컴퓨터", "전산", "정보통신"], "science": true}, {"name": "신소재·재료공학", "strong": ["신소재공학", "신소재", "재료공학", "재료", "금속공학", "금속"], "related": ["고분자", "세라믹"], "science": true}, {"name": "산업공학", "strong": ["산업공학", "산업시스템공학", "산업경영공학"], "related": ["시스템공학"], "science": true}, {"name": "환경공학", "strong": ["환경공학", "환경", "환경시스템공학"], "related": ["에너지", "안전공학"], "science": true}, {"name": "생명공학", "strong": ["생명공학", "생명", "생물공학", "바이오공학", "바이오"], "related": ["생물", "생명과학"], "science": true}, {"name": "식품공학", "strong": ["식품공학", "식품", "식품생명공학"], "related": ["식품영양"], "science": true}, {"name": "건축공학", "strong": ["건축공학", "건축", "건축학"], "related": ["토목", "도시공학"], "science": true}, {"name": "토목공학", "strong": ["토목공학", "토목", "건설환경공학"], "related": ["건축", "도시공학"], "science": true}, {"name": "화학", "strong": ["화학", "응용화학", "정밀화학", "분석화학", "유기화학", "무기화학", "공업화학", "물리화학", "생화학"], "related": ["고분자", "화학공학"], "science": true}, {"name": "수학·통계", "strong": ["수학", "통계학", "통계", "응용수학"], "related": ["데이터과학"], "science": true}, {"name": "경영학", "strong": ["경영학", "경영", "경영정보학", "경영정보"], "related": ["경제", "회계"], "science": false}, {"name": "경제학", "strong": ["경제학", "경제", "응용경제학"], "related": ["경영", "금융"], "science": false}, {"name": "회계학", "strong": ["회계학", "회계", "세무학", "세무"], "related": ["경영", "경제"], "science": false}, {"name": "행정학", "strong": ["행정학", "행정", "공공행정"], "related": ["정책학"], "science": false}, {"name": "법학", "strong": ["법학", "법률학", "법률"], "related": ["행정"], "science": false}, {"name": "디자인", "strong": ["디자인", "시각디자인", "산업디자인", "제품디자인"], "related": ["미술"], "science": false}];
  const MAJOR_SCI=/이공계|공학\s*계열|자연\s*계열/;
  const MAJOR_FREE=/전공\s*(무관|불문|제한\s*없|상관\s*없)|학과\s*(무관|불문)|(?<![가-힣])관련\s*(전공|학과)/;
  const MAJOR_OTHER=/(기계|전기|전자|컴퓨터|소프트웨어|산업|건축|토목|환경|신소재|재료|금속|생명|식품|자동차|조선|항공|반도체|제어|메카트로닉스|통계|수학|경영|경제|회계|행정|법|디자인)[가-힣·,/\s]{0,6}(공학|전공|학과|계열)/;
  const MAJOR_LABELS={strong:'전공 명시',chem:'관련 계열',sci:'이공계',free:'전공 무관',other:'다른 전공만',unknown:'전공 미확인'};
  let majorInput='화학공학',majorMode='all',educationMode='all';
  function educationTag(r){
    const text=String(r.education||'');
    if(/석사|박사/.test(text))return 'university';
    if(/초대졸|전문대/.test(text))return 'college';
    if(/대졸/.test(text))return 'university';
    if(/고졸/.test(text))return 'high';
    if(/무관/.test(text))return 'free';
    return 'unknown';
  }
  function matchesEducation(r){const tag=educationTag(r);return educationMode==='all'||(educationMode==='explicit'?tag==='university':!['college','high'].includes(tag));}
  function currentMajorGroup(){const key=majorInput.trim().replace(/\s+/g,'').replace(/과$/,'');return MAJOR_GROUPS.find(g=>g.name===majorInput||g.strong.some(t=>t.replace(/과$/,'')===key))||{name:majorInput,strong:[majorInput.trim()],related:[],science:false};}
  function syncMajorPicker(){const g=currentMajorGroup(),preset=$('major-preset');preset.value=MAJOR_GROUPS.includes(g)?g.name:'custom';$('major-custom').hidden=preset.value!=='custom';$('major-input').value=majorInput;$('major-select').querySelector('[value=science]').textContent=g.science?'내 전공·이공계만':'내 전공·관련 계열만';$('major-select').querySelector('[value=chemistry]').textContent='내 전공만';}
  function matchesMajor(r){const tag=majorTag(r).tag;return majorMode==='all'||(majorMode==='exclude-other'?tag!=='other':(majorMode==='science'&&currentMajorGroup().science?['strong','chem','sci']:['strong','chem']).includes(tag));}
  function majorTag(r){
    const text=[r.title,r.education,...(r.required||[]),...(r.preferred||[]),...(r.roles||[]),r.detailText,r.latestObservation?.detailText,r.imageOcr?.text,r.latestObservation?.imageOcr?.text].filter(v=>typeof v==='string').join('\n'),hit=(re)=>{const m=re.exec(text);return m?m[0]:'';};
    const group=currentMajorGroup();
    for(const term of group.strong){const m=new RegExp('(?<![가-힣])'+term.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'(?:학과|과)?(?![가-힣])','i').exec(text);if(m)return {tag:'strong',label:MAJOR_LABELS.strong,hit:m[0]};}
    const related=group.related.find(term=>new RegExp('(?<![가-힣])'+term+'\\s*(계열|관련|전공|학과|과(?![가-힣])|분야|공학)').test(text)||text.split('\n').some(line=>/전공|학과|공학|자격/.test(line)&&new RegExp('(?<![가-힣])'+term+'(?![가-힣])').test(line)));if(related)return {tag:'chem',label:group.name==='화학공학'?'화학 계열':MAJOR_LABELS.chem,hit:related};
    const sci=hit(MAJOR_SCI);if(sci)return {tag:'sci',label:MAJOR_LABELS.sci,hit:sci};
    const free=hit(MAJOR_FREE);if(free)return {tag:'free',label:MAJOR_LABELS.free,hit:free};
    const other=hit(MAJOR_OTHER);if(other)return {tag:'other',label:MAJOR_LABELS.other,hit:other};
    return {tag:'unknown',label:MAJOR_LABELS.unknown,hit:''};
  }
  function deadlineText(r){const status=C.state(r);if(status==='closed')return '마감 · '+r.deadline.label;if(status==='unknown')return (r.deadline.label||'마감 미확인')+' · 시각 확인 필요';const days=Math.max(0,daysLeft(r));const precise=r.deadline.precision==='minute'?' · 시각 명시':r.deadline.precision==='date'?' · 날짜만 표기(그날 끝까지로 계산)':'';return `D-${days} · ${r.deadline.label}${precise}`;}
  let view='list',calMonth=null;
  const ymd=v=>{const t=typeof v==='number'?v:Date.parse(v);return Number.isFinite(t)?new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Seoul'}).format(t):null;};
  // 달력: 현재 조건 결과(모든 페이지)를 접수 시작일·마감일에 놓는다. 항목을 누르면 오른쪽 상세에 연다.
  function renderCalendar(all){
    const today=ymd(Date.now());if(!calMonth)calMonth=today.slice(0,7);const [y,m]=calMonth.split('-').map(Number);$('cal-title').textContent=y+'.'+String(m).padStart(2,'0');
    const byDay=new Map(),add=(day,r,kind)=>{if(!day)return;if(!byDay.has(day))byDay.set(day,[]);byDay.get(day).push({r,kind});};
    for(const r of all){add(ymd(r.startAt),r,'start');add(ymd(r.deadline?.at),r,'end');}
    const grid=$('cal-grid');grid.replaceChildren();for(const d of ['일','월','화','수','목','금','토'])grid.append(node('div',d,'cal-dow'));
    const first=new Date(Date.UTC(y,m-1,1)),start=new Date(first);start.setUTCDate(1-first.getUTCDay());
    const last=new Date(Date.UTC(y,m,0)),end=new Date(last);end.setUTCDate(last.getUTCDate()+(6-last.getUTCDay()));
    for(const d=new Date(start);d<=end;d.setUTCDate(d.getUTCDate()+1)){
      const key=d.toISOString().slice(0,10),cell=node('div',undefined,'cal-day'+(d.getUTCMonth()!==m-1?' other':'')+(key===today?' today':''));cell.dataset.day=key;cell.append(node('span',String(d.getUTCDate()),'cal-date'));
      const items=(byDay.get(key)||[]).sort((a,b)=>(a.kind==='end')-(b.kind==='end')||a.r.company.localeCompare(b.r.company,'ko'));
      for(const {r,kind} of items.slice(0,8)){const b=node('button',undefined,'cal-item'+(C.state(r)==='closed'?' closed':''));b.type='button';b.dataset.id=r.id;b.title=r.company+' · '+r.title;b.setAttribute('aria-pressed',String(r.id===selectedId));b.append(node('span',kind==='start'?'시':'끝','cal-tag '+kind),node('span',r.company,'name'));b.addEventListener('click',()=>{selectVisibleRecord(r);});cell.append(b);}
      if(items.length>8)cell.append(node('span','+'+(items.length-8)+'개 더','cal-more'));grid.append(cell);
    }
  }
  function setView(next){view=next;try{localStorage.setItem(draftKey+':view',view);}catch{}for(const b of $('view-switch').children)b.setAttribute('aria-pressed',String(b.dataset.view===view));renderData();}
  let inlineRecordId=null;
  function renderQuickChips(){const box=$('quick-chips');box.replaceChildren();for(const [id,label]of [['major-select',currentMajorGroup().name],['education-select',$('education-select').selectedOptions[0].textContent],['career-select',$('career-select').selectedOptions[0].textContent]]){const select=$(id);if(select.value==='all')continue;const chip=node('span',undefined,'quick-chip'),clear=node('button','×');clear.type='button';clear.setAttribute('aria-label',label+' 필터 해제');clear.addEventListener('click',()=>{select.value='all';select.dispatchEvent(new Event('change',{bubbles:true}));});chip.append(node('span',label),clear);box.append(chip);}}
  function companyMark(company,large=false){const clean=String(company||'').replace(/\(주\)|㈜|주식회사|\(유\)/g,'').trim(),mark=node('span',clean.slice(0,2)||'회사','company-mark'+(large?' large':''));mark.setAttribute('aria-hidden','true');mark.dataset.tone=String([...clean].reduce((n,c)=>n+c.charCodeAt(0),0)%4);return mark;}
  function renderJobCard(r,campaign=null){const row=node('article',undefined,'job-row'),b=node('button',undefined,'job'+(C.state(r)==='closed'?' closed':''));row.dataset.record=r.id;b.type='button';b.dataset.id=r.id;b.setAttribute('aria-pressed',String(r.id===selectedId));
      const dd=ddayInfo(r),isNew=(r.memberRecords||[r]).some(m=>m.discoveredAt&&!seenSet().has(m.id)),head=node('span',undefined,'job-head');
      const main=node('span',undefined,'job-main'),companyText=node('span',undefined,'company-text');companyText.append(node('span',r.company,'job-company'));if(isNew)companyText.append(node('span','안 봄','job-new'));head.append(companyMark(r.company),companyText);main.append(head);const title=node('span',campaign?(campaign.roles?.[r.id]||'통합 모집요강'):r.title,'job-title');b.title=r.company+' · '+r.title;
      const meta=[list(r.locations),list([...(r.career||[]),...(r.employment||[])]),r.education].filter(v=>v&&v!=='미확인'),metaLine=node('span',meta.length?meta.join(' · '):'지역·경력 미확인','job-meta-line');
      const sources=node('span',undefined,'job-sources'),sites=[...new Set(r.sources.filter(s=>!s.official).map(s=>s.site))];for(const s of sites){const tag=badge(s);tag.dataset.site=s;sources.append(tag);}if(sites.length>1)sources.append(badge('출처 '+sites.length+'곳 비교','good'));{const cand=candidateIds(r);if(cand.length)sources.append(badge('중복 후보(미확인) '+cand.length,'warn'));}{const mt=majorTag(r);if(mt.tag!=='unknown')sources.append(badge(mt.label,mt.tag==='strong'?'good':mt.tag==='other'?'warn':''));}if(r.imageOcr?.needsReview||r.latestObservation?.imageOcr?.needsReview)sources.append(badge('이미지 확인 필요','warn'));const lead=node('span',undefined,'job-lead');lead.append(title,sources);main.append(lead,metaLine);
      const side=node('span',undefined,'job-side');side.title=r.deadline?.label||'마감 미확인';side.setAttribute('aria-label','마감: '+side.title);side.append(node('span',dd.text,'dday dday-'+dd.kind),node('span',r.deadline?.label||'마감 미확인','job-deadline-date'));
      b.append(main,side);b.addEventListener('click',()=>selectVisibleRecord(r));row.append(b);
      const actions=node('div',undefined,'job-actions'),first=(r.sources||[]).find(s=>!s.official)||r.sources?.[0];
      if(first){const open=link('원문 열기 ↗',viewUrl(first));open.className='open-source';open.setAttribute('aria-label',r.company+' · '+r.title+' 원문 열기');open.addEventListener('click',()=>{for(const id of memberIdsOf(r))markSeen(id);row.querySelector('.job-new')?.remove();});actions.append(open);}
      row.append(actions);const extra=node('details',undefined,'job-extra'),summary=node('summary','메모·준비 기록');summary.title='메모·준비 체크·출처 비교 열기';extra.dataset.record=r.id;extra.open=inlineRecordId===r.id;summary.addEventListener('click',event=>{event.preventDefault();if(inlineRecordId===r.id){inlineRecordId=null;renderData();}else selectVisibleRecord(r);});extra.append(summary);row.append(extra);return row;}

  function selectVisibleRecord(r){
    inlineRecordId=r.id;
    selectedId=r.id;selectedMembers=new Set(memberIdsOf(r));for(const mid of memberIdsOf(r))markSeen(mid);
    const unit=displayUnits.find(u=>u.rows.some(row=>row.id===r.id));if(unit){if(unit.campaign)campaignOpen.set(unit.key,true);page=Math.floor(displayUnits.indexOf(unit)/pageSize)+1;}
    renderData();$('job-list').querySelector('.job[data-id="'+CSS.escape(r.id)+'"]')?.focus({preventScroll:true});if(innerWidth<=700&&!$('job-detail').hidden)$('job-detail').scrollIntoView({block:'start'});
  }
  function renderCampaignUnit(unit){
    const fold=node('details',undefined,'campaign-bundle'),summary=node('summary',undefined,'campaign-summary'),text=node('span',undefined,'campaign-heading');
    fold.dataset.campaign=unit.key;fold.dataset.selected=String(unit.rows.some(r=>r.id===selectedId));fold.open=campaignOpen.get(unit.key)===true;
    text.append(node('strong',unit.company,'campaign-company'),node('span',unit.label,'campaign-title'));
    const sites=new Set(unit.rows.flatMap(r=>(r.sources||[]).filter(s=>!s.official).map(s=>s.site)));
    text.append(node('span','공고 '+unit.rows.length+'개 · 출처 '+sites.size+'곳 · '+unit.day+' 마감','campaign-meta'));summary.append(text);fold.append(summary);
    const body=node('div',undefined,'campaign-body'),grid=node('div',undefined,'campaign-grid'),brand=node('div',undefined,'campaign-brand');brand.append(companyMark(unit.company,true),node('strong',unit.company));
    for(const r of unit.rows)body.append(renderJobCard(r,unit));grid.append(brand,body);fold.append(grid);const evidence=node('details',undefined,'campaign-evidence');evidence.append(node('summary','묶음 연결 근거'),node('p','각 공고의 자격 조건과 원문은 별도로 확인하세요. 연결 근거: '+(unit.evidence||'제목·마감일 일치')+'.','help'));fold.append(evidence);
    fold.addEventListener('toggle',()=>{if(fold.isConnected)campaignOpen.set(unit.key,fold.open);});return fold;
  }
  function renderData(){
    const detailScroll=$('job-detail').scrollTop, previousDetail=$('job-detail').dataset.record;
    const editing=document.activeElement,keepEditing=$('job-detail').contains(editing),selection=keepEditing&&typeof editing.selectionStart==='number'?[editing.selectionStart,editing.selectionEnd]:null;
    const inlineArea=$('job-detail');$('detail-home').append(inlineArea);inlineArea.hidden=true;$('calendar-record').hidden=true;
    const all=records(),units=listUnits(all),pg=C.paginate(units.length,page,pageSize),visibleUnits=units.slice(pg.start,pg.end),rows=visibleUnits.flatMap(unit=>unit.rows),campaignCount=units.filter(unit=>unit.campaign).length;page=pg.page;
    renderQuickChips();
    displayUnits=units;campaignByRecord=new Map();for(const unit of units)if(unit.campaign)for(const r of unit.rows)campaignByRecord.set(r.id,unit);
    const visibleSite=state.schema.sites.find(s=>s.id===$('site-select').value);const offSites=state.schema.sites.filter(s=>(!visibleSite||visibleSite.id===s.id)&&state.settings.sites[s.id]?.enabled!==true).map(s=>s.name),offNote=offSites.length?offSites.join('·')+' 사이트 사용이 꺼져 있어 해당 출처 공고가 표시되지 않습니다. 위쪽 ‘검색할 사이트’에서 체크하고 ‘조건 저장·적용’을 누르세요. ':'';
    $('list-scope').textContent=offNote+(visibleSite?visibleSite.name+' 출처가 있고 저장한 조건을 통과한 공고입니다. 다른 출처도 함께 표시된 행은 같은 공고의 출처 묶음입니다.':'모든 출처의 저장 공고에 사이트별 저장 조건을 적용한 결과입니다. 한 사이트만 보려면 출처를 선택하세요.');
    $('result-count').textContent=all.length?(campaignCount?'목록 '+units.length+'개 중 '+(pg.start+1)+'–'+pg.end+'번 · 공고 '+all.length+'건 · 채용 묶음 '+campaignCount+'개':all.length+'건 중 '+(pg.start+1)+'–'+pg.end+'번 표시')+(mergedCount?' · 같은 공고 묶음 '+mergedCount+'개':''):'0건 표시';for(const b of $('groups').children)b.setAttribute('aria-pressed',String(b.dataset.group===group));
    {const current=all.find(r=>memberIdsOf(r).includes(selectedId));selectedId=current?current.id:(rows[0]?.id||null);const shown=all.find(r=>r.id===selectedId);selectedMembers=new Set(shown?memberIdsOf(shown):[]);}
    const calendar=view==='calendar';$('job-list').hidden=calendar;$('pager').hidden=calendar;$('job-calendar').hidden=!calendar;if(calendar)renderCalendar(all);
    $('job-list').replaceChildren();
    for(const unit of visibleUnits)$('job-list').append(unit.campaign?renderCampaignUnit(unit):renderJobCard(unit.rows[0]));
    if(!rows.length){const sq=$('site-select').value==='saramin'&&state.settings.sites.saramin?.enabled?C.saraminQuery(state.settings.sites.saramin.nativeUrl,state.settings.sites.saramin.companyType,state.settings.sites.saramin):null;$('job-list').append(node('p',sq?.ok?'저장한 사람인 조건으로 사람인이 돌려준 공고가 아직 없습니다. ‘사람인 갱신’을 누르면 사람인 검색 결과와 같은 공고가 표시됩니다.':'조건에 맞는 저장 공고가 없습니다. 출처·조건·미확인 포함 여부를 확인하세요.','job-empty'));}
    renderPager(pg,units.length);
    const record=all.find(r=>r.id===selectedId),key=JSON.stringify([record,state.profile,state.annotations?.[record?.id]?.revision,campaignByRecord.get(record?.id)?.rows.map(r=>r.id)]);
    if(inlineRecordId!==selectedId)inlineRecordId=null;
    if(inlineRecordId&&record){const host=calendar?$('calendar-record'):$('job-list').querySelector('.job-extra[data-record="'+CSS.escape(record.id)+'"]');if(host){host.append(inlineArea);host.hidden=false;inlineArea.hidden=false;}}
    if(key!==detailSignature){const panels=previousDetail===selectedId?[...$('job-detail').querySelectorAll('details[data-section]')].map(e=>({id:e.dataset.section,open:e.open,text:e.querySelector('pre')?.textContent,scroll:e.querySelector('pre')?.scrollTop})):[];renderDetail(record);for(const panel of panels){const restored=[...$('job-detail').querySelectorAll('details[data-section]')].find(e=>e.dataset.section===panel.id);if(restored){restored.open=panel.open;const pre=restored.querySelector('pre');if(pre&&pre.textContent===panel.text)pre.scrollTop=panel.scroll;}}detailSignature=key;$('job-detail').dataset.record=selectedId||'';if(previousDetail===selectedId)$('job-detail').scrollTop=detailScroll;}if(keepEditing&&editing.isConnected&&!inlineArea.hidden){editing.focus({preventScroll:true});if(selection)editing.setSelectionRange(...selection);}renderCollection();
  }
  function renderPreparation(r){
    const section=node('section');section.append(node('h3','내 준비 기록 · 직접 표시'));
    const saved=state.annotations?.[r.id]||{revision:0,notes:'',checkedTasks:[],checkedDocuments:[]},key=draftKey+':job:'+r.id,basis=JSON.stringify([r.prep,r.documents]);
    let draft=null;try{draft=JSON.parse(localStorage.getItem(key)||'null');}catch{}
    let pending=draft&&(draft.revision!==saved.revision||draft.basis!==basis)?draft:null,current=draft&&!pending?draft:saved;
    const form=node('form'),status=node('p',pending?'저장된 기록 또는 공고 항목이 바뀌었습니다. 보관 초안을 복원하거나 저장본을 선택해주세요.':'체크와 메모는 직접 저장한 준비 기록입니다.','help');status.setAttribute('role','status');form.id='preparation-form';
    for(const [kind,title,items]of [['task','준비할 일',r.prep],['document','준비한 서류',r.documents.filter(v=>!/미확인|확인 필요/.test(v))]]){
      form.append(node('p',title,'help'));for(const value of items){const label=node('label',undefined,'todo-item'),input=node('input');input.type='checkbox';input.name=kind;input.value=value;input.checked=(kind==='task'?current.checkedTasks:current.checkedDocuments)?.includes(value)||false;label.append(input,document.createTextNode(value));form.append(label);}
    }
    const label=node('label','개인 메모'),notes=node('textarea');notes.id='job-notes';notes.maxLength=5000;notes.rows=3;notes.value=current.notes||'';label.append(notes);form.append(label);const button=node('button','준비 기록 저장','wide-button');button.type='submit';form.append(button);section.append(form,status);
    const controls=()=>[...form.querySelectorAll('input,textarea,button')],read=()=>({revision:saved.revision,basis,notes:notes.value,checkedTasks:[...form.querySelectorAll('input[name=task]:checked')].map(e=>e.value),checkedDocuments:[...form.querySelectorAll('input[name=document]:checked')].map(e=>e.value)});
    const remember=()=>{try{localStorage.setItem(key,JSON.stringify(read()));status.textContent='아직 저장하지 않은 준비 기록입니다.';}catch{status.textContent='초안을 임시 보관하지 못했습니다. 준비 기록을 저장해주세요.';}};
    form.addEventListener('input',remember);
    if(pending){controls().forEach(e=>e.disabled=true);const restore=node('button','내 준비 초안 복원','wide-button'),useSaved=node('button','저장된 준비 기록 사용','wide-button');restore.type=useSaved.type='button';section.append(restore,useSaved);
      restore.addEventListener('click',()=>{notes.value=typeof pending.notes==='string'?pending.notes:'';for(const input of form.querySelectorAll('input'))input.checked=(input.name==='task'?pending.checkedTasks:pending.checkedDocuments)?.includes(input.value)||false;controls().forEach(e=>e.disabled=false);pending=null;restore.remove();useSaved.remove();remember();});
      useSaved.addEventListener('click',()=>{localStorage.setItem(key+':previous',JSON.stringify(pending));localStorage.removeItem(key);pending=null;controls().forEach(e=>e.disabled=false);restore.remove();useSaved.remove();status.textContent='프로젝트에 저장된 준비 기록을 표시합니다. 이전 초안은 별도 보관했습니다.';});
    }
    form.addEventListener('submit',async event=>{event.preventDefault();if(composing)return;const payload=read();controls().forEach(e=>e.disabled=true);try{const next=await api('/api/annotation',{id:r.id,...payload});localStorage.removeItem(key);const annotation=next.annotations[r.id];if(annotation.revision>=(state.annotations?.[r.id]?.revision||0)){state.annotations={...state.annotations,[r.id]:annotation};state.stateVersion=Math.max(state.stateVersion||0,next.stateVersion||0);}renderData();message('준비 기록을 프로젝트에 저장했습니다.');}catch(e){status.textContent=e.message;await poll();}finally{controls().forEach(e=>e.disabled=false);}});
    return section;
  }
  function listSection(title,values,unknown=false){const section=node('section');section.append(node('h3',title));const ul=node('ul');for(const text of values?.length?values:['미확인'])ul.append(node('li',text,unknown?'unknown':''));section.append(ul);return section;}
  function renderDetail(r){
    const area=$('job-detail');area.replaceChildren();if(!r)return;
    area.append(node('p',r.company,'detail-company'),node('h3',r.title,'detail-title'),renderPreparation(r));
    const more=node('details');more.dataset.section='sources';more.append(node('summary','원문·출처 비교·수집 근거 보기'));area.append(more);
    if(r.imageOcr?.needsReview)more.append(node('p','이미지 인식 결과에 확인이 필요합니다. 원문과 대조하세요.','help'));
    const sourceRows=r.sources||[],compare=node('section');compare.dataset.section='source-compare';compare.append(node('h3','출처 비교'));
    const compareList=node('ul');for(const s of sourceRows)compareList.append(node('li',s.site+(s.official?' (기업 공식)':'')+' · 확인 '+stamp(s.checkedAt)+' · '+(s.scope||'확인 범위 미확인')));
    compare.append(compareList,node('p',sourceRows.length>1?'같은 공고로 묶인 출처가 '+sourceRows.length+'곳입니다. '+(r.members?.length>1?'위쪽 제목·마감·지역 등은 대표 출처의 값이고, 출처별 제목과 마감은 아래에 따로 표시합니다. 달라 보이면 원문에서 직접 대조해주세요.':'출처별 세부 값은 따로 저장하지 않아 위 표시는 이 공고의 합쳐진 값입니다. 달라 보이면 원문에서 직접 대조해주세요.')+'':'출처가 한 곳입니다. 다른 사이트의 같은 공고인지는 확인되지 않았습니다.','help'));more.append(compare);
    if(r.members?.length>1)more.append(listSection('같은 공고로 묶은 출처 · 출처별 제목과 마감',r.members.map(m=>m.site+' · '+m.title+' · '+(m.deadline||'마감 미확인'))),node('p','사이트가 다르고 회사명이 같고 제목이 거의 같으며 마감 날짜가 같아 한 건으로 묶었습니다. 저장된 공고는 그대로이고, 위쪽 ‘같은 공고 묶기’를 끄면 따로 보입니다.','help'));
    const duplicates=candidateIds(r).map(id=>state.data.records.find(row=>row.id===id)).filter(Boolean);
    if(duplicates.length){
      const fieldsToCompare=[['회사',x=>x.company],['공고명',x=>x.title],['직무',x=>list(x.roles)],['근무지',x=>list(x.locations)],['경력·고용형태',x=>list([...(x.career||[]),...(x.employment||[])])],['마감',x=>x.deadline?.label||'미확인']],norm=v=>String(v).normalize('NFKC').replace(/\s+/g,'').toLocaleLowerCase('ko');
      more.append(listSection('확인되지 않은 중복 후보 · 자동으로 합치지 않음',duplicates.map(row=>{const diff=fieldsToCompare.filter(([,read])=>norm(read(r))!==norm(read(row))).map(([name])=>name);return row.company+' · '+row.title+' · '+row.sources.map(s=>s.site).join(', ')+' / '+(diff.length?'다른 항목: '+diff.join(', '):'비교한 항목은 같지만 같은 공고로 확인되지 않음');})));
      more.append(node('p','회사와 제목이 비슷하다는 이유로만 찾은 후보입니다. 같은 회사라도 직무·근무지·고용형태·마감이 다르면 다른 공고일 수 있어 원문을 대조해주세요.','help'));for(const row of duplicates)more.append(link(row.sources[0]?.site+' 후보 원문 ↗',row.originalUrl||row.sources[0]?.url));
    }
    const sources=node('section');sources.append(node('h3','원문 확인'));for(const s of r.sources){sources.append(link(s.site+' 원문 ↗',viewUrl(s)),node('p',stamp(s.checkedAt)+' · '+(s.scope||'확인 범위 추가 확인 필요'),'source-note'));}more.append(sources);
    if(r.detailText){const detail=node('details');detail.dataset.section='current-text';detail.append(node('summary','수집한 상세 텍스트 보기'),node('pre',r.detailText,'detail-text'));more.append(detail);}
  }
  function renderSchedule(){
    const schedule=state.schedule;if(!schedule)return;
    $('schedule-status').textContent=schedule.error||(schedule.enabled?'다음 예약 '+stamp(schedule.nextRunAt)+' · '+schedule.message:schedule.message);
    if(scheduleDirty||scheduleSaving)return;
    $('schedule-enabled').checked=schedule.enabled;$('schedule-interval').value=schedule.intervalMinutes;
    $('schedule-sites').replaceChildren();for(const site of state.schema.sites){const label=node('label',undefined,'check'),input=node('input');input.type='checkbox';input.value=site.id;input.checked=schedule.sites.includes(site.id);label.append(input,document.createTextNode(site.name));$('schedule-sites').append(label);}
    if(!scheduleInitialized){scheduleInitialized=true;try{const draft=JSON.parse(localStorage.getItem(draftKey+':schedule')||'null');if(draft){if(draft.revision===state.revision){applyScheduleDraft(draft);}else{schedulePending=draft;$('restore-schedule').hidden=false;$('discard-schedule').hidden=false;for(const e of $('schedule-form').querySelectorAll('input,button'))e.disabled=true;}}}catch{message('예약 초안을 읽지 못했습니다. 저장된 예약을 표시합니다.',true);}}
    if(schedulePending){for(const e of $('schedule-form').querySelectorAll('input,button'))e.disabled=true;$('schedule-status').textContent+=' · 이전 예약 초안이 있습니다. 복원하거나 저장된 예약 사용을 선택해주세요.';}
  }
  function rememberSchedule(){scheduleDirty=true;try{localStorage.setItem(draftKey+':schedule',JSON.stringify({revision:state.revision,schedule:{enabled:$('schedule-enabled').checked,intervalMinutes:Number($('schedule-interval').value),sites:[...$('schedule-sites').querySelectorAll('input:checked')].map(e=>e.value)}}));}catch{message('예약 초안을 임시 보관하지 못했습니다. 설정을 저장해주세요.',true);}}
  function applyScheduleDraft(draft){const value=draft.schedule;if(!value||!Array.isArray(value.sites))throw new Error('예약 초안 형식이 올바르지 않습니다.');$('schedule-enabled').checked=value.enabled===true;$('schedule-interval').value=value.intervalMinutes;for(const e of $('schedule-sites').querySelectorAll('input'))e.checked=value.sites.includes(e.value);for(const e of $('schedule-form').querySelectorAll('input,button'))e.disabled=false;schedulePending=null;$('restore-schedule').hidden=true;$('discard-schedule').hidden=true;rememberSchedule();}
  async function saveSchedule(event){
    event.preventDefault();if(scheduleSaving)return;if(dirty){message('입력 중인 내 조건·사이트 조건을 먼저 저장해주세요.',true);return;}
    const schedule={enabled:$('schedule-enabled').checked,intervalMinutes:Number($('schedule-interval').value),sites:[...$('schedule-sites').querySelectorAll('input:checked')].map(e=>e.value)};
    scheduleSaving=true;const controls=[...$('schedule-form').querySelectorAll('input,button')];controls.forEach(e=>e.disabled=true);
    try{const next=await api('/api/schedule',{revision:state.revision,schedule});if(next.revision>=state.revision){state=next;editRevision=next.revision;}scheduleDirty=false;localStorage.removeItem(draftKey+':schedule');message('예약 설정을 저장했습니다. '+(schedule.enabled?'예정 시각부터 실행합니다.':'다음 예약은 실행하지 않습니다.'));}
    catch(e){message(e.message,true);}finally{scheduleSaving=false;controls.forEach(e=>e.disabled=false);renderSchedule();}
  }
  function renderAlerts(){const alerts=state.notifications||[];$('alerts-summary').textContent='프로그램 알림 · 안 읽음 '+alerts.filter(n=>!n.read).length+'개';{const unread=alerts.filter(n=>!n.read).length;if($('advanced-note'))$('advanced-note').textContent=unread?' · 안 읽은 알림 '+unread+'개':'';}$('alerts-list').replaceChildren();for(const item of alerts.slice(0,30))$('alerts-list').append(node('li',(item.read?'읽음 · ':'새 알림 · ')+stamp(item.createdAt)+' · '+item.message));$('read-alerts').disabled=!alerts.some(n=>!n.read);}
  function batchBusy(){return state?.batchActive===true;}
  function renderBatch(){
    const container=$('batch-sites'),batch=state.batch,busy=batchBusy();
    if(!container.children.length){
      let selected=[];try{const saved=JSON.parse(localStorage.getItem(draftKey+':batch-sites')||'[]');if(Array.isArray(saved))selected=saved;}catch{}
      for(const site of state.schema.sites){const label=node('label',undefined,'check'),input=node('input');input.type='checkbox';input.value=site.id;input.checked=selected.includes(site.id);label.append(input,document.createTextNode(site.name));container.append(label);}
    }
    for(const input of container.querySelectorAll('input'))input.disabled=busy||batchSubmitting;
    $('collect-batch').disabled=!state.capabilities.batchCollection||Boolean(state.active)||busy||batchSubmitting||saving||!container.querySelector('input:checked');
    $('batch-status').textContent=!state.capabilities.batchCollection?'프로그램을 다시 실행한 뒤 여러 사이트 수집을 사용할 수 있습니다.':busy?(batch?.status==='stopping'?'중지 요청됨 · 현재 수집의 종료를 확인하고 남은 사이트를 취소합니다.':batch?.currentSite?`${batch.results.length+1}/${batch.sites.length} · ${state.schema.sites.find(s=>s.id===batch.currentSite)?.name} · ${state.active?.message||'수집 준비 중'}`:batch?.message||'실행 준비 중'):batch?({completed:'',partial:'일부 사이트 확인 필요',failed:'수집을 마치지 못했습니다.',stopped:'중지 확인',interrupted:'수집이 중단되었습니다.'})[batch.status]||'':'';
    if(!busy&&['running','stopping'].includes(batch?.status))$('batch-status').textContent='수집이 중단되었습니다. '+(state.storageError||'저장 상태를 확인한 뒤 프로그램을 다시 실행해주세요.');
    $('batch-results').replaceChildren();for(const result of batch?.results||[]){const status={completed:'완료',partial:'상세 확인 필요',failed:'실패',stopped:'중지 확인'}[result.status]||result.status;$('batch-results').append(node('li',state.schema.sites.find(s=>s.id===result.site)?.name+' · '+status+' · '+[C.recoveryHint(result)].filter(Boolean).join(' / ')));}
  }
  function runLabel(run){return run.status==='completed'?'완료':run.status==='partial'?'일부 확인 필요':({running:'수집 중',stopping:'중지 중',stopped:'중지됨',failed:'실패',interrupted:'중단됨'})[run.status]||run.status;}
  // 켜 둔 사이트별로 마지막 성공(완료·일부 완료) 수집 시각을 모아 '마지막 갱신'을 보여준다. 하루 넘게 갱신 안 한 사이트는 이름을 알려준다.
  function renderLastRefresh(){
    const el=$('last-refresh');if(!el)return;
    const sites=state.schema.sites.filter(s=>state.settings.sites[s.id]?.enabled),latest=id=>state.runs.find(r=>r.site===id&&['completed','partial'].includes(r.status)&&Number.isFinite(Date.parse(r.finishedAt)));
    if(!sites.length){el.textContent='';return;}
    const rows=sites.map(s=>({s,run:latest(s.id)})),times=rows.filter(x=>x.run).map(x=>Date.parse(x.run.finishedAt));
    if(!times.length){el.textContent='아직 갱신한 적이 없습니다.';return;}
    const stale=rows.filter(x=>!x.run||Date.now()-Date.parse(x.run.finishedAt)>86400000).map(x=>x.s.name);
    el.textContent='마지막 갱신 '+stamp(new Date(Math.max(...times)).toISOString())+(stale.length?' · 하루 넘게 갱신하지 않음: '+stale.join(', '):'');
  }
  let collectionProgressTask=null;
  function renderCollectionProgress(){const view=C.collectionProgress({...state,pendingCollection:batchSubmitting},collectionProgressTask),box=$('collection-progress'),bar=$('progress-bar');collectionProgressTask=view.task;box.hidden=!view.visible;if(!view.visible)return;box.dataset.status=view.status;box.classList.toggle('indeterminate',view.indeterminate);$('progress-label').textContent=view.label;$('progress-percent').textContent=view.percent===null?'':view.percent+'%';$('progress-note').textContent=view.note;bar.setAttribute('aria-valuetext',[view.label,view.percent===null?'':view.percent+'%',view.note].filter(Boolean).join(' · '));if(view.percent===null)bar.removeAttribute('value');else bar.value=view.percent;$('progress-fill').style.width=view.indeterminate?'30%':(view.percent??0)+'%';}
  function renderCollection(){
    renderSchedule();renderAlerts();renderBatch();renderLastRefresh();
    renderCollectionProgress();
    $('site-results').replaceChildren();for(const site of state.schema.sites){const row=node('div',undefined,'site-result'),run=state.runs.find(r=>r.site===site.id);row.append(node('span',site.name));row.append(badge(run?runLabel(run):'수동 수집 가능',run?.status==='failed'?'bad':run?.status==='completed'?'good':'warn'));$('site-results').append(row);}
    $('collection-status').textContent=state.active?.message||state.storageError||(state.runs[0]?.status==='partial'?C.recoveryHint(state.runs[0]):state.runs[0]&&state.runs[0].status!=='completed'?([state.runs[0].message,state.runs[0].plan?.coverage,C.recoveryHint(state.runs[0])].filter(Boolean).join(' / ')):null)||'';
    const busy=Boolean(state.active)||batchBusy()||batchSubmitting,stopping=state.active?.status==='stopping'||batchBusy()&&state.batch?.status==='stopping';
    $('import-urls').disabled=busy||saving;$('collect').disabled=busy||saving;$('stop').hidden=!state.active&&!batchBusy();$('stop').disabled=stopping;$('stop').textContent=stopping?'중지 확인 중':'수집 중지';
    $('run-history').replaceChildren();for(const run of state.runs.slice(0,8))$('run-history').append(node('li',stamp(run.startedAt)+' · '+run.message+' / 원격: '+(run.plan?.remote||[]).join(' · ')));
    $('checked').textContent='기존 표본 확인 '+stamp(state.data.collectedAt)+(state.runs.find(r=>['completed','partial'].includes(r.status))?' / 최근 수집 '+stamp(state.runs.find(r=>['completed','partial'].includes(r.status)).checkedAt):' / 새 수집 기록 없음');
  }
  function download(name,content,type){const url=URL.createObjectURL(new Blob([content],{type})),a=node('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
  function csvCell(value){let text=String(value??'');if(/^[\s]*[=+@-]/.test(text))text="'"+text;return '"'+text.replaceAll('"','""')+'"';}
  function readProfile(value){
    const result={};for(const key of Object.keys(profileLabels)){if(typeof value?.[key]!=='string'||value[key].length>1000)throw new Error('내 조건은 항목당 1,000자 이내의 텍스트여야 합니다.');result[key]=value[key];}return result;
  }
  function offerRecovery(text){conflict=true;$('restore-draft').hidden=false;message(text,true);}
  async function poll(){
    if(polling||!state)return;polling=true;
    try{
      const next=await api('/api/state');if(next.version!=='0.2.0'||next.projectId!==state.projectId){ready=false;message('서버의 버전 또는 프로젝트가 바뀌었습니다. 입력 초안은 보관했습니다. 프로젝트를 확인하고 새로고침해주세요.',true);return;}if(saving||next.revision<state.revision||(next.stateVersion||0)<(state.stateVersion||0))return;
      if(next.revision>editRevision){
        if(dirty)offerRecovery('다른 화면에서 조건이 바뀌었습니다. 내 초안을 보관한 상태입니다. 복원 버튼으로 최신 저장본을 확인한 뒤 다시 적용할 수 있습니다.');
        else{settings=structuredClone(next.settings);profile=structuredClone(next.profile);editRevision=next.revision;state=next;renderForms();}
      }
      state=next;const key=JSON.stringify([next.settings,next.profile,next.data.records,next.annotations]);
      if(key!==signature){signature=key;renderData();}else renderCollection();
    }catch(e){message('프로그램 연결을 확인해주세요. 입력 중인 조건은 이 브라우저에 임시 보관합니다. '+e.message,true);if(!$('collection-progress').hidden){$('collection-progress').dataset.status='paused';$('progress-label').textContent='연결 확인 필요';$('progress-percent').textContent='';$('progress-note').textContent='서버 연결이 회복되면 진행 상황을 다시 확인합니다.';}}finally{polling=false;}
  }
  async function restoreDraft(fromArchive=false){
    if(saving)return;
    try{
      readForms();const draft=fromArchive?pendingDraft:(dirty?{profile,settings}:pendingDraft);if(!draft)throw new Error('복원할 초안이 없습니다.');
      const restoredSettings=C.normalizeSettings(draft.settings,state.schema),restoredProfile=readProfile(draft.profile),latest=await api('/api/state');
      if(latest.revision<state.revision)throw new Error('최신 저장본을 다시 확인해주세요.');
      if(fromArchive&&dirty){pendingDraft={revision:editRevision,profile:structuredClone(profile),settings:structuredClone(settings)};localStorage.setItem(draftKey+':recovery',JSON.stringify(pendingDraft));}else if(fromArchive){pendingDraft=null;localStorage.removeItem(draftKey+':recovery');}state=latest;settings=restoredSettings;profile=restoredProfile;editRevision=latest.revision;conflict=false;renderForms();remember();$('restore-draft').hidden=true;$('restore-archive').hidden=!pendingDraft;
      message('최신 저장본을 확인하고 내 초안을 복원했습니다. 저장 버튼을 누르면 프로젝트에 적용됩니다.');
    }catch(e){message(e.message,true);}
  }
  async function start(){
    try{state=await api('/api/state');if(state.name!=='local-job-desk'||state.version!=='0.2.0'||!state.projectId)throw new Error('서버 버전이 화면과 다릅니다. 서버를 다시 실행한 뒤 새로고침해주세요.');ready=true;draftKey=legacyDraftKey+':'+state.projectId;try{$('direct-urls').value=localStorage.getItem(draftKey+':urls')||'';}catch{}try{$('import-legacy-draft').hidden=!localStorage.getItem(legacyDraftKey);}catch{}settings=structuredClone(state.settings);profile=structuredClone(state.profile);editRevision=state.revision;try{const draft=JSON.parse(localStorage.getItem(draftKey)||'null');if(draft&&draft.revision===state.revision){settings=C.normalizeSettings(draft.settings,state.schema);profile=readProfile(draft.profile);dirty=true;message('저장 전 입력을 복원했습니다. 확인 후 저장해주세요.');}else if(draft){pendingDraft=draft;localStorage.setItem(draftKey+':recovery',JSON.stringify(draft));offerRecovery('이전 입력 초안을 보관했습니다. 복원 버튼으로 최신 저장본을 확인한 뒤 적용해주세요.');}else{const archived=JSON.parse(localStorage.getItem(draftKey+':recovery')||'null');if(archived){pendingDraft=archived;offerRecovery('보관된 이전 초안이 있습니다. 복원 버튼으로 확인할 수 있습니다.');}}}catch{message('이전 입력 초안을 읽지 못했습니다. 저장된 조건을 표시합니다.',true);}
      if(!pendingDraft){try{pendingDraft=JSON.parse(localStorage.getItem(draftKey+':recovery')||'null');}catch{}}$('restore-archive').hidden=!pendingDraft;
      for(const site of state.schema.sites){const option=node('option',site.name);option.value=site.id;$('site-select').append(option);const detail=node('option',site.name);detail.value=site.id;$('detail-site').append(detail);}
      let initialSource='';try{initialSource=localStorage.getItem(draftKey+':list-source')||'';}catch{}if(!['all',...state.schema.sites.map(s=>s.id)].includes(initialSource))initialSource=state.runs.find(r=>r.trigger==='manual')?.site||'all';$('site-select').value=initialSource;if(initialSource!=='all')selectedSite=initialSource;
      for(const [id,label]of [['open','진행 중'],['new','아직 안 봄'],['urgent','마감 임박'],['closed','마감'],['all','전체']]){const b=node('button',label);b.dataset.group=id;b.addEventListener('click',()=>{group=id;resetPage();renderData();});$('groups').append(b);}
      try{if(localStorage.getItem(draftKey+':view')==='calendar'){view='calendar';for(const b of $('view-switch').children)b.setAttribute('aria-pressed',String(b.dataset.view===view));}}catch{}
      unifyConditions();renderForms();renderNativeForms();renderData();setInterval(poll,1800);
    }catch(e){message('화면을 시작하지 못했습니다. 채용공고 실행 바로가기를 사용해주세요. '+e.message,true);}
  }
  document.addEventListener('compositionstart',()=>{composing=true;});document.addEventListener('compositionend',()=>{composing=false;});document.addEventListener('focusout',()=>{composing=false;});
  $('import-legacy-draft').addEventListener('click',()=>{try{readForms();const imported=JSON.parse(localStorage.getItem(legacyDraftKey)||'null');const nextSettings=C.normalizeSettings(imported?.settings,state.schema),nextProfile=readProfile(imported?.profile);if(dirty){pendingDraft={revision:editRevision,profile:structuredClone(profile),settings:structuredClone(settings)};localStorage.setItem(draftKey+':recovery',JSON.stringify(pendingDraft));$('restore-archive').hidden=false;}settings=nextSettings;profile=nextProfile;editRevision=state.revision;renderForms();remember();message('같은 주소의 이전 버전 조건 초안을 불러왔습니다. 프로젝트를 확인한 뒤 저장해주세요. 이전 초안 원본은 그대로 보관했습니다.');}catch(e){message(e.message,true);}});
  $('direct-urls').addEventListener('input',()=>{try{localStorage.setItem(draftKey+':urls',$('direct-urls').value);}catch{message('주소 초안을 보관하지 못했습니다. 따로 복사해 보관해주세요.',true);}});$('direct-urls-form').addEventListener('submit',async event=>{event.preventDefault();if(composing)return;if(dirty){message('입력 중인 내 조건·사이트 조건을 먼저 저장해주세요.',true);return;}const urls=$('direct-urls').value.split(/\r?\n/).map(v=>v.trim()).filter(Boolean);$('import-urls').disabled=true;try{await api('/api/import-urls',{urls});message('지정한 공개 공고 주소 확인을 시작했습니다. 완료 후 목록에 적용합니다.');await poll();}catch(e){message(e.message,true);$('import-urls').disabled=false;}});
  $('read-alerts').addEventListener('click',async()=>{try{const first=state.notifications?.[0];if(!first)return;await api('/api/notifications/read',{upTo:first.id});await poll();}catch(e){message(e.message,true);}});
  $('schedule-form').addEventListener('input',rememberSchedule);$('restore-schedule').addEventListener('click',()=>{try{applyScheduleDraft(schedulePending);message('예약 초안을 불러왔습니다. 저장 전에는 실행되지 않습니다.');}catch(e){message(e.message,true);}});$('discard-schedule').addEventListener('click',()=>{schedulePending=null;scheduleDirty=false;localStorage.removeItem(draftKey+':schedule');$('restore-schedule').hidden=true;$('discard-schedule').hidden=true;for(const e of $('schedule-form').querySelectorAll('input,button'))e.disabled=false;renderSchedule();});$('schedule-form').addEventListener('submit',saveSchedule);
  $('restore-draft').addEventListener('click',()=>restoreDraft());$('restore-archive').addEventListener('click',()=>restoreDraft(true));
  $('profile-form').addEventListener('input',remember);$('site-form').addEventListener('input',remember);$('profile-form').addEventListener('submit',save);$('site-form').addEventListener('submit',save);
  $('fill-sites').addEventListener('click',()=>{readForms();for(const row of Object.values(settings.sites))for(const key of ['roles','locations','career','employment','education','exclude'])if(!row[key]&&profile[key])row[key]=profile[key];renderForms();remember();message('빈 사이트 조건을 채웠습니다. 저장 버튼을 눌러 적용해주세요.');});
  $('search').addEventListener('input',()=>{if(state){resetPage();renderData();}});$('site-select').addEventListener('change',()=>{if(state)showSource($('site-select').value);});
  $('sort-select').addEventListener('change',()=>{if(!state)return;const option=$('sort-select').selectedOptions[0];if(!option||option.disabled){$('sort-select').value=sortKey;return;}sortKey=$('sort-select').value;resetPage();renderData();});
  $('page-size').addEventListener('change',()=>{if(!state)return;pageSize=Number($('page-size').value)||20;resetPage();renderData();});
  // 내 전공·전공 단계·학력·묶기 선택은 이 브라우저에만 저장한다.
  let majorLoaded=false;
  function loadMajorPrefs(){if(majorLoaded)return;majorLoaded=true;try{const saved=JSON.parse(localStorage.getItem(draftKey+':major')||'null');if(saved&&typeof saved.input==='string'&&saved.input.trim())majorInput=saved.input.trim();majorMode=['all','exclude-other','science','chemistry'].includes(saved?.mode)?saved.mode:saved?.only?'exclude-other':'all';educationMode=['all','minimum','explicit'].includes(saved?.education)?saved.education:'all';groupOn=saved?.group!==false;}catch{}$('major-input').value=majorInput;$('major-select').value=majorMode;$('education-select').value=educationMode;$('group-on').checked=groupOn;syncMajorPicker();}
  function saveMajorPrefs(){try{localStorage.setItem(draftKey+':major',JSON.stringify({input:majorInput,mode:majorMode,education:educationMode,group:groupOn}));}catch{}}
  for(const g of MAJOR_GROUPS){const o=node('option',g.name);o.value=g.name;$('major-preset').insertBefore(o,$('major-preset').lastElementChild);}
  $('major-preset').addEventListener('change',()=>{if(!state)return;loadMajorPrefs();if($('major-preset').value==='custom'){$('major-custom').hidden=false;$('major-input').focus();return;}majorInput=$('major-preset').value;syncMajorPicker();saveMajorPrefs();resetPage();renderData();});
  $('major-input').addEventListener('input',()=>{if(!state)return;majorInput=$('major-input').value.trim()||'화학공학';saveMajorPrefs();resetPage();renderData();});
  $('major-input').addEventListener('change',()=>{if(!state)return;loadMajorPrefs();majorInput=$('major-input').value.trim()||'화학공학';$('major-input').value=majorInput;syncMajorPicker();saveMajorPrefs();resetPage();renderData();});
  $('major-select').addEventListener('change',()=>{if(!state)return;loadMajorPrefs();majorMode=$('major-select').value;saveMajorPrefs();resetPage();renderData();});
  $('education-select').addEventListener('change',()=>{if(!state)return;loadMajorPrefs();educationMode=$('education-select').value;saveMajorPrefs();resetPage();renderData();});
  $('group-on').addEventListener('change',()=>{if(!state)return;loadMajorPrefs();groupOn=$('group-on').checked;saveMajorPrefs();resetPage();renderData();});
  $('site-form').addEventListener('input',syncChoices);$('site-form').addEventListener('change',e=>{if(e.target.name==='companyType'){syncSaraminUrl();remember();syncChoices();}});
  $('choice-keyword').addEventListener('input',()=>{const input=termInput('keyword');if(!input)return;input.value=$('choice-keyword').value;remember();syncChoices();});
  $('board-save').addEventListener('click',()=>save());
  $('board-reset').addEventListener('click',resetConditions);
  for(const b of $('view-switch').children)b.addEventListener('click',()=>setView(b.dataset.view));
  const moveMonth=n=>{const [y,m]=(calMonth||ymd(Date.now()).slice(0,7)).split('-').map(Number),d=new Date(Date.UTC(y,m-1+n,1));calMonth=d.toISOString().slice(0,7);renderData();};
  $('cal-prev').addEventListener('click',()=>moveMonth(-1));$('cal-next').addEventListener('click',()=>moveMonth(1));$('cal-today').addEventListener('click',()=>{calMonth=null;renderData();});
  $('detail-site').addEventListener('change',()=>{readForms();selectedSite=$('detail-site').value;renderForms();});
  // 오른쪽 위 버튼으로 사이트 검색 양식을 접고 편다. 접은 상태는 이 브라우저에 기억한다.
  // 저장된 사이트 양식은 칩 한 줄로 요약해 보여준다(양식을 접었을 때만 표시).
  let summaryToken=0;
  async function renderCondSummary(){
    const token=++summaryToken,box=$('cond-summary'),rows=[];
    for(const id of pickedSites()){const query=settings.sites[id]?.nativeQuery;if(!query){rows.push({id,lines:null});continue;}try{const table=await nativeTable(id);rows.push({id,lines:nativeLabels(table,nativeParse(table,query))});}catch{rows.push({id,lines:['조건을 읽지 못했습니다']});}}
    if(token!==summaryToken)return;box.replaceChildren();
    for(const {id,lines} of rows){const row=node('div',undefined,'cond-row');row.append(node('strong',state.schema.sites.find(s=>s.id===id).name));if(!lines)row.append(node('span','양식 없음 · 수집 전에 고르세요','cond-chip empty'));else for(const line of lines)row.append(node('span',line.replace(': ',' · '),'cond-chip'));box.append(row);}
  }
  let boardDecided=false,boardStored=null;try{boardStored=localStorage.getItem(legacyDraftKey+':native-open');}catch{}
  function setBoardOpen(open,remember=true){$('cond-summary').hidden=open;$('native-forms').hidden=!open;$('board-toggle').setAttribute('aria-expanded',String(open));$('board-toggle').textContent=open?'세부 조건 접기':'세부 조건 펼치기';if(remember)try{localStorage.setItem(legacyDraftKey+':native-open',open?'1':'0');}catch{}}
  for(const id of ['major-preset','major-custom','major-select','education-select']){const input=$(id);$('quick-filters').append(id==='major-custom'?input:input.closest('label'));}$('quick-filters').append($('career-select').closest('label'));
  let careerLoaded=false;function loadCareerPrefs(){if(careerLoaded)return;careerLoaded=true;try{const saved=localStorage.getItem(draftKey+':career');$('career-select').value=['all','entry','explicit'].includes(saved)?saved:'all';}catch{}}
  $('career-select').addEventListener('change',()=>{try{localStorage.setItem(draftKey+':career',$('career-select').value);}catch{}resetPage();renderData();});
  const allSites=node('button','전체 출처','all-sites');allSites.id='all-sites';allSites.type='button';$('site-pick-list').prepend(allSites);allSites.addEventListener('click',async()=>{if(!state||saving)return;readForms();const enable=!state.schema.sites.every(s=>settings.sites[s.id]?.enabled);for(const site of state.schema.sites)settings.sites[site.id].enabled=enable;remember();renderSitePick();await save();showSource('all');});
  const management=$('advanced-panel');management.classList.add('card');management.append(document.querySelector('.saved-summary'),document.querySelector('.collect-box'),$('export-csv'));$('jobs-panel').append(management);
  const listHeading=document.querySelector('.list-heading'),listTools=document.querySelector('.list-tools');listHeading.append($('view-switch'),$('site-select'));for(const id of ['sort-select','page-size','group-on'])listTools.append($(id).closest('label'));$('sort-select').setAttribute('aria-label','공고 정렬');$('page-size').setAttribute('aria-label','표시 개수');
  $('board-toggle').addEventListener('click',()=>setBoardOpen($('native-forms').hidden));setBoardOpen(boardStored==='1',false);
  $('collect').addEventListener('click',async()=>{
    if(composing||saving||batchSubmitting||batchBusy()||state?.active)return;
    const sites=pickedSites();if(!sites.length){message('검색할 사이트를 하나 이상 고르고 저장해주세요.',true);return;}
    // 화면에 펼친 사이트 양식이 이번 수집 조건이다. 저장 버튼 없이도 같이 저장하고, 양식이 빈 사이트는 숨은 예전 공통 조건으로 대신 수집하지 않는다.
    if(nativeState&&nativeTables[nativeSite]&&sites.includes(nativeSite)){const query=nativeBuild(nativeTables[nativeSite],nativeState.sel);if(query!==(settings.sites[nativeSite].nativeQuery||'')){settings.sites[nativeSite].nativeQuery=query;remember();}}
    if(dirty){await save();if(dirty)return;}
    const empty=sites.filter(id=>!settings.sites[id]?.nativeQuery);if(empty.length){message('양식을 먼저 고르세요: '+empty.map(id=>state.schema.sites.find(s=>s.id===id).name).join(', ')+'. 아래 사이트 검색 양식에서 조건을 고른 뒤 다시 눌러주세요(고른 조건은 수집할 때 자동 저장됩니다).',true);return;}
    $('collect').disabled=true;
    try{
      if(sites.length===1){const site=sites[0];await api('/api/collect',{site});showSource(site);message(state.schema.sites.find(s=>s.id===site).name+' 수집을 시작했습니다. 완료 후 저장 조건을 통과한 공고를 표시합니다.');}
      else{batchSubmitting=true;renderCollection();await api('/api/collect-batch',{sites,revision:state.revision});showSource('all');message('선택한 '+sites.length+'개 사이트를 차례로 확인합니다. 중지하면 남은 사이트도 시작하지 않습니다.');}
      await poll();
    }catch(e){message(e.message,true);}finally{batchSubmitting=false;renderCollection();}
  });
  $('stop').addEventListener('click',async()=>{const id=batchBusy()?state.batch.id:state.active?.id;if(!id)return;try{await api('/api/stop',{id});await poll();}catch(e){message(e.message,true);}});
  $('batch-sites').addEventListener('change',()=>{try{localStorage.setItem(draftKey+':batch-sites',JSON.stringify([...$('batch-sites').querySelectorAll('input:checked')].map(e=>e.value)));}catch{message('수집 사이트 선택을 임시 보관하지 못했습니다.',true);}renderBatch();});
  $('batch-form').addEventListener('submit',async event=>{
    event.preventDefault();if(composing||batchSubmitting||saving||batchBusy())return;if(dirty){message('입력 중인 내 조건·사이트 조건을 먼저 저장해주세요.',true);return;}
    const sites=[...$('batch-sites').querySelectorAll('input:checked')].map(e=>e.value);if(!sites.length){message('수집할 사이트를 선택해주세요.',true);return;}
    batchSubmitting=true;renderCollection();try{await api('/api/collect-batch',{sites,revision:state.revision});message('선택한 사이트의 수집을 시작했습니다. 중지하면 남은 사이트도 시작하지 않습니다.');await poll();}catch(e){message(e.message,true);}finally{batchSubmitting=false;renderCollection();}
  });
  $('export-settings').addEventListener('click',()=>{readForms();download('search-settings.json',JSON.stringify({...settings,profile},null,2),'application/json;charset=utf-8');});
  $('import-settings').addEventListener('change',async e=>{const file=e.target.files[0];if(!file)return;try{if(file.size>200000)throw new Error('조건 파일은 200KB 이하여야 합니다.');const imported=JSON.parse(await file.text()),nextSettings=C.normalizeSettings(imported,state.schema),nextProfile=imported.profile===undefined?profile:readProfile(imported.profile);readForms();settings=nextSettings;profile=nextProfile;renderForms();remember();message('조건 파일을 불러왔습니다. 저장 버튼을 눌러 프로젝트에 적용해주세요.');}catch(error){message(error.message,true);}finally{e.target.value='';}});
  $('export-csv').addEventListener('click',()=>{const rows=[['기업','공고','지역','경력','학력','고용형태','마감 표기','마감 일시(KST 환산, 시각 미확인이면 날짜 끝값)','마감 근거','지원자격(미확인 문구 포함)','우대사항','전형절차','제출서류','자료 확인','출처'],...records().map(r=>{const list=v=>(Array.isArray(v)?v:[]).join(' / '),explicit=key=>list(r[key]);return [r.company,r.title,list(r.locations),list(r.career),r.education||'',list(r.employment),r.deadline.label,r.deadline.at?new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Seoul',dateStyle:'short',timeStyle:'medium'}).format(new Date(r.deadline.at)):'',r.deadline.basis||'',explicit('required'),explicit('preferred'),explicit('stages'),explicit('documents'),r.checkedAt,list((r.sources||[]).map(s=>s.url))];})];download('공고-현재목록.csv','\uFEFF'+rows.map(row=>row.map(csvCell).join(',')).join('\r\n'),'text/csv;charset=utf-8');});
  let historyCursor=null,historyLoading=false;
  async function loadHistory(reset=false){try{const data=await api('/api/history'+(!reset&&historyCursor?'?cursor='+encodeURIComponent(historyCursor):''));if(data.projectId!==state.projectId)throw new Error('프로젝트를 다시 확인해주세요.');if(reset)$('all-history-list').replaceChildren();for(const run of data.runs)$('all-history-list').append(node('li',[run.startedAt,run.site,run.status,run.message].filter(Boolean).join(' · ')));historyCursor=data.nextCursor;$('next-history').disabled=!historyCursor;$('history-count').textContent='전체 '+data.total+'회';}catch(e){message(e.message,true);}}
  async function requestHistory(reset){if(historyLoading)return;historyLoading=true;$('load-history').disabled=true;$('next-history').disabled=true;try{await loadHistory(reset);}finally{historyLoading=false;$('load-history').disabled=false;$('next-history').disabled=!historyCursor;}}
  $('load-history').addEventListener('click',()=>requestHistory(true));$('next-history').addEventListener('click',()=>requestHistory(false));
  void start();
})();
