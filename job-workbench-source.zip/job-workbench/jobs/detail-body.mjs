import {setTimeout as pause} from 'node:timers/promises';
import {fetchPublic} from './saramin.mjs';

// Only follow a public body explicitly referenced by this posting's own page.
export async function readPublicBody({site,id,page,html,signal,fetcher}){
  signal?.throwIfAborted();
  if(!/^\d+$/.test(id))throw new Error('상세 본문 게시물 식별자가 올바르지 않습니다.');
  let target=null;
  if(site==='catch'){
    const frame=page.locator('iframe[title="채용상세"]');if(await frame.count()){
      const src=await frame.first().getAttribute('src'),url=new URL(src,'https://www.catch.co.kr');
      if(url.protocol!=='https:'||url.hostname!=='www.catch.co.kr'||url.pathname!=='/controls/recruitDetail/'+id||url.username||url.password||url.port)throw new Error('허용한 공개 상세 본문 주소가 아닙니다.');target=url.href;
    }
  }else if(site==='jobkorea'){
    if([...html.matchAll(/GI_Read_Comt_Ifrm\?Gno=(\d+)/g)].some(m=>m[1]===id))target='https://www.jobkorea.co.kr/Recruit/GI_Read_Comt_Ifrm?Gno='+id+'&isHiringCenter=false&hideMapView=false';
  }else if(site==='jasoseol'){
    const node=page.locator('#__NEXT_DATA__');if(await node.count()){
      const data=JSON.parse(await node.textContent()).props?.pageProps?.initialEmploymentCompany;
      if(data&&String(data.id)===id&&typeof data.content==='string'&&data.content.trim())return {html:data.content,sourceUrl:null,embedded:true};
    }
  }
  if(!target)return null;
  await pause(800,undefined,{signal});const result=await fetchPublic(target,{site,signal,fetcher});return {...result,sourceUrl:target,embedded:false};
}
