import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {createHash} from 'node:crypto';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {fileURLToPath} from 'node:url';
import {setTimeout as pause} from 'node:timers/promises';
const run=promisify(execFile),helper=fileURLToPath(new URL('./windows-ocr.ps1',import.meta.url));
const suspectText=text=>/(?<![가-힣])(?:회학|화핵|화학공핵)(?![가-힣])/.test(text||'');
const hosts=['saramin.co.kr','saraminimage.co.kr','jobkorea.co.kr','catch.co.kr','jasoseol.com','gabia.com','greencrosswb.com','kyungwoo.com','recruiter.co.kr','ifh.cc','daumcdn.net','saraminbanner.co.kr','jobkorea.kr','dy354i6m86fqr.cloudfront.net','daoift3qrrnil.cloudfront.net'];
export function imageUrls(html,base){
  const found=new Set();for(const tag of String(html).matchAll(/<img\b[^>]*>/gi)){
    const attrs=[...tag[0].matchAll(/\b(?:src|data-src|data-original)\s*=\s*["']([^"']+)["']/gi)];
    for(const [,raw] of attrs){try{const u=new URL(raw.replaceAll('&amp;','&'),base);if(u.protocol==='http:')u.protocol='https:';
      if(u.protocol==='https:'&&!u.username&&!u.password&&(!u.port||u.port==='443'))found.add(u.href);
    }catch{}}
  }return [...found];
}
async function download(url,signal){
  const allowed=target=>{const u=new URL(target);if(u.protocol!=='https:'||u.username||u.password||(u.port&&u.port!=='443')||!hosts.some(h=>u.hostname===h||u.hostname.endsWith('.'+h)))throw new Error('허용 범위 밖의 이미지 호스트: '+u.hostname);};allowed(url);
  for(let attempt=0;attempt<3;attempt++){try{
  let target=url,response;for(let hops=0;hops<5;hops++){allowed(target);response=await fetch(target,{redirect:'manual',signal:signal?AbortSignal.any([signal,AbortSignal.timeout(20000)]):AbortSignal.timeout(20000)});if(![301,302,303,307,308].includes(response.status))break;target=new URL(response.headers.get('location'),target).href;await response.body?.cancel();if(hops===4)throw new Error('이미지 리디렉션 상한 초과');}
  if(!response.ok)throw new Error('이미지 HTTP '+response.status);
  if(!/^image\//i.test(response.headers.get('content-type')||''))throw new Error('이미지 형식이 아닙니다.');
  const chunks=[];let size=0;for await(const chunk of response.body){size+=chunk.length;if(size>32*1024*1024)throw new Error('이미지 32MB 상한 초과');chunks.push(chunk);}return Buffer.concat(chunks);
  }catch(e){signal?.throwIfAborted();if(attempt===2||/HTTP 4|상한|형식|허용 범위/.test(e.message))throw e;await pause(1000,undefined,{signal});}}
}
export async function recognizeImage(file,{signal}={}){
  if(process.platform!=='win32')throw new Error('Windows 한국어 OCR이 필요한 기능입니다.');
  const script=await fs.readFile(helper,'utf8');
  const command='& { '+script+' } -ImagePath '+"'"+path.resolve(file).replaceAll("'","''")+"'";
  try{const options={windowsHide:true,encoding:'utf8',timeout:120000,maxBuffer:2*1024*1024,signal};
    const {stdout}=await run('powershell.exe',['-NoProfile','-NonInteractive','-Command',command],options);
    const result=JSON.parse(stdout.replace(/^\uFEFF/,'').trim());
    // Re-read suspicious OCR words at another scale; never replace characters by guesswork.
    if(result.status==='success'&&suspectText(result.text)){
      try{const alternate=await run('powershell.exe',['-NoProfile','-NonInteractive','-Command',command.replace('@(1.0,2.0)','@(3.0)')],options),extra=JSON.parse(alternate.stdout.replace(/^\uFEFF/,'').trim());
        result.text=[...new Set([...result.text.split('\n'),...extra.text.split('\n')])].join('\n');result.method+=' + alternate-scale reread';result.needsReview=suspectText(extra.text);result.multiscaleChecked=true;
      }catch(e){signal?.throwIfAborted();result.needsReview=true;result.multiscaleChecked=true;result.reviewReason='추가 확대 인식 실패';}
    }
    return result;
  }catch(e){signal?.throwIfAborted();throw new Error(String(e.stderr||e.code||'Windows OCR 실행 실패').trim().split(/\r?\n/)[0].slice(0,300));}
}
export async function recognizeHtmlImages({html,base,cacheDir=path.join(os.tmpdir(),'job-desk-ocr-v1'),signal,recognizer=recognizeImage,fetchImage=download}){
  const urls=imageUrls(html,base),results=[];await fs.mkdir(cacheDir,{recursive:true});
  for(const url of urls.slice(0,100)){
    signal?.throwIfAborted();const key=createHash('sha256').update(url).digest('hex'),cache=path.join(cacheDir,key+'.json'),file=path.join(cacheDir,key+'.image');
    try{let result;try{const [stat,imageStat]=await Promise.all([fs.stat(cache),fs.stat(file)]);if(Date.now()-Math.min(stat.mtimeMs,imageStat.mtimeMs)<12*60*60*1000)result=JSON.parse(await fs.readFile(cache,'utf8'));}catch{}
      if(result?.status==='success'&&result.engineVersion!==2)result=null;
      if(result?.status==='success'&&suspectText(result.text)&&!result.multiscaleChecked)result=null;
      if(!result){let fresh=false;try{fresh=Date.now()-(await fs.stat(file)).mtimeMs<12*60*60*1000;}catch{}if(!fresh)await fs.writeFile(file,await fetchImage(url,signal));result=await recognizer(file,{signal});await fs.writeFile(cache,JSON.stringify({...result,url,engineVersion:2}));}
      results.push({...result,url});
    }catch(e){signal?.throwIfAborted();results.push({url,status:'failed',error:e.message,text:''});}
  }
  const successful=results.filter(r=>r.status==='success'&&r.text.trim()),failed=results.filter(r=>r.status==='failed');
  const combined=successful.map(r=>r.text).join('\n'),needsReview=failed.length>0||urls.length>100||combined.length>100000||results.some(r=>r.needsReview);
  return {version:2,checkedAt:new Date().toISOString(),status:needsReview?'partial':successful.length?'success':urls.length?'no-text':'no-images',text:combined.slice(0,100000),images:results,totalImages:urls.length,engine:'Windows OCR ko (local)',needsReview};
}
