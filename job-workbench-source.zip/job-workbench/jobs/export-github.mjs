import fs from 'node:fs/promises';import path from 'node:path';import {fileURLToPath} from 'node:url';import {createHash} from 'node:crypto';import './core.js';
const source=path.dirname(fileURLToPath(import.meta.url)),output=process.argv[2]&&path.resolve(process.argv[2]);if(!output)throw Error('사용법: node jobs/export-github.mjs 새_출력폴더');try{await fs.access(output);throw Error('기존 폴더를 덮어쓰지 않습니다.');}catch(e){if(e.code!=='ENOENT')throw e;}
const production=['server.mjs','saramin.mjs','public-sites.mjs','requirements.mjs','detail-body.mjs','browser.mjs','image-ocr.mjs','windows-ocr.ps1','core.js','ui-fonts.js','FONT-LICENSE.txt','dashboard.js','dashboard.html','dashboard.css','recover.mjs','start-jobs.ps1','stop-jobs.ps1','index.html','styles.css','app.js','schema.js','build-portable.mjs','build-setup.ps1','portable-setup.cs','check-distribution-trust.ps1','export-github.mjs'];
const unit=(await fs.readdir(source)).filter(f=>f.endsWith('.test.mjs')),browser=['campaign-check.mjs','wide-list-check.mjs','progress-browser-check.mjs'];
await fs.mkdir(path.join(output,'jobs/fixtures'),{recursive:true});for(const file of [...production,...unit,...browser])await fs.copyFile(path.join(source,file),path.join(output,'jobs',file));await fs.cp(path.join(source,'site-tables'),path.join(output,'jobs/site-tables'),{recursive:true});
const schema=JSON.parse(await fs.readFile(path.join(source,'settings-schema.json'),'utf8')),defaults=globalThis.JobsCore.defaults(schema),settings=structuredClone(defaults);for(const site of Object.values(settings.sites))site.enabled=false;
const seed={schemaVersion:1,project:schema.project,generatedAt:null,collectedAt:null,timezone:'Asia/Seoul',scope:'사용자가 직접 수집한 공개 채용공고',profile:{status:'미입력',confirmed:[],questions:[]},method:'공개 채용공고 수집',deduplication:'같은 공고 및 같은 채용의 화면 묶기',limitations:['지원 자격과 마감은 원문에서 확인하세요.'],records:[]};
for(const [name,value]of Object.entries({'settings-schema.json':schema,'search-settings.json':settings,'data.json':seed,'fixtures/test-settings.json':defaults}))await fs.writeFile(path.join(output,'jobs',name),JSON.stringify(value,null,2)+'\n');await fs.writeFile(path.join(output,'jobs/data.js'),'globalThis.JOBS_DATA = '+JSON.stringify(seed)+';\n');
let sample;try{sample=JSON.parse(await fs.readFile(path.join(source,'fixtures/public-sample.json'),'utf8'));}catch{sample=JSON.parse(await fs.readFile(path.join(source,'data.json'),'utf8'));}sample.profile={status:'미확인',confirmed:[],questions:[]};sample.scope='자동 테스트 전용 공개 예제';sample.method='테스트용 고정 자료';sample.limitations=[];
await fs.mkdir(path.join(output,'jobs/fixtures/evidence'),{recursive:true});
for(const record of sample.records)for(const [i,item]of record.sources.entries()){
 const original=path.resolve(source,'..',item.evidenceFile),base=path.resolve(source,'..')+path.sep;if(!original.startsWith(base))throw Error('예제 근거 경로 확인 실패');
 const evidence=JSON.parse(await fs.readFile(original,'utf8')),relative='jobs/fixtures/evidence/'+record.id+'-'+i+'.json';
 await fs.writeFile(path.join(output,relative),JSON.stringify({requestedUrl:evidence.requestedUrl,status:evidence.status,checkedAt:evidence.checkedAt},null,2)+'\n');
 if(item.site==='자소설닷컴'){const html=await fs.readFile(original.replace(/\.json$/,'.html'),'utf8'),next=JSON.parse(html.match(/<script[^>]+id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/)[1]);await fs.writeFile(path.join(output,relative.replace(/\.json$/,'.html')),'<!-- 고정 테스트 예제: 공개 마감 시각만 보존 -->\n<script id="__NEXT_DATA__" type="application/json">'+JSON.stringify({props:{pageProps:{initialEmploymentCompany:{end_time:next.props.pageProps.initialEmploymentCompany.end_time}}}})+'</script>\n');}
 item.evidenceFile=relative;
}
await fs.writeFile(path.join(output,'jobs/fixtures/public-sample.json'),JSON.stringify(sample,null,2)+'\n');
const template=sample.records[0];if(!template)throw Error('공개 테스트 예제가 없습니다.');const campaign=[['saramin-55289564','사람인','에스케이피유코어(주)','26년 하반기 대졸 신입 공개채용(설비관리엔지니어)','https://www.saramin.co.kr/zf_user/jobs/relay/view-detail?rec_idx=55289564'],['saramin-55289385','사람인','에스케이피유코어(주)','26년 하반기 대졸 신입 공개채용(공정엔지니어)','https://www.saramin.co.kr/zf_user/jobs/relay/view-detail?rec_idx=55289385'],['jasoseol-106670','자소설닷컴','피유코어','2026년 하반기 대졸 신입 공개채용','https://jasoseol.com/recruit/106670'],['catch-575773','캐치','피유코어',"'26년 하반기 대졸 신입 공개채용 #공채",'https://www.catch.co.kr/NCS/RecruitInfoDetails/575773']].map(([id,site,company,title,url])=>({...structuredClone(template),id,company,title,locations:['울산'],roles:[],career:['신입'],education:'대졸',employment:['정규직'],detailText:'화학공학 전공',sources:[{site,url,checkedAt:'2026-10-30T00:00:00Z',scope:'자동 테스트 예제',official:false}],deadline:{at:'2026-11-01T14:59:00Z',label:'테스트 마감'},partial:true}));
await fs.writeFile(path.join(output,'jobs/fixtures/campaign-sample.json'),JSON.stringify(campaign,null,2)+'\n');
for(const file of unit){const dest=path.join(output,'jobs',file);let text=await fs.readFile(dest,'utf8');text=text.replaceAll("new URL('./data.json',import.meta.url)","new URL('./fixtures/public-sample.json',import.meta.url)").replaceAll("new URL('data.json',source)","new URL('fixtures/public-sample.json',source)").replaceAll("new URL(name,source)","new URL(name==='data.json'?'fixtures/public-sample.json':name==='search-settings.json'?'fixtures/test-settings.json':name,source)");if(file==='jobs.test.mjs')text=text.replace("replace(/;\\s*$/,'')),data);","replace(/;\\s*$/,'')),JSON.parse(await fs.readFile(new URL('./data.json',import.meta.url),'utf8')));");if(file==='collection-progress.test.mjs'&&!text.includes('state.settings.sites.saramin.enabled=true;'))text=text.replace("state.settings.sites.saramin.keyword='검증';","state.settings.sites.saramin.enabled=true;state.settings.sites.saramin.keyword='검증';");await fs.writeFile(dest,text);}
for(const file of ['campaign-check.mjs','wide-list-check.mjs']){const dest=path.join(output,'jobs',file);let text=await fs.readFile(dest,'utf8');text=text.replace("await(await fetch('http://127.0.0.1:42637/api/state')).json()","({data:{records:JSON.parse(await fs.readFile(new URL('./fixtures/campaign-sample.json',import.meta.url),'utf8'))}})");await fs.writeFile(dest,text);}
const pack=JSON.parse(await fs.readFile(path.join(source,'package.json'),'utf8'));pack.scripts={'start':'node server.mjs','test':'node --test '+unit.join(' '),'check:wide':'node wide-list-check.mjs','check:campaign':'node campaign-check.mjs','check:progress':'node progress-browser-check.mjs'};await fs.writeFile(path.join(output,'jobs/package.json'),JSON.stringify(pack,null,2)+'\n');
const builder=path.join(output,'jobs/build-portable.mjs');let build=await fs.readFile(builder,'utf8');build=build.replace("path.join(os.homedir(),'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules')","path.join(source,'node_modules')");await fs.writeFile(builder,build);
for(const [name,action]of [['채용 공고 실행.cmd','start'],['채용 공고 종료.cmd','stop']])await fs.writeFile(path.join(output,name),'@echo off\r\npowershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0jobs\\'+action+'-jobs.ps1"'+(action==='start'?' -Open':'')+'\r\nif errorlevel 1 pause\r\n');
await fs.writeFile(path.join(output,'.gitignore'),'.runtime/\nnode_modules/\njobs/runtime/\n.env\n.env.*\n*.pem\n*.pfx\n*.p12\n*.key\n*.exe\n*.zip\n');
await fs.writeFile(path.join(output,'AGENTS.md'),'# 작업 인수인계\n\n- Codex/Claude 중 사용자가 지정한 한 명만 수정합니다. 다른 AI를 자동 호출하지 않습니다.\n- 개인 공고·경험·메모·검색조건·인증 정보는 .runtime에 보관하고 Git에 추가하지 않습니다. 배포본/공개 자료에는 빈 설정을 사용합니다.\n- 현재 UI의 브라우저 검사는 jobs/wide-list-check.mjs, campaign-check.mjs, progress-browser-check.mjs입니다. tests의 고정 예제와 사용자 저장 자료를 구분합니다.\n- 설치판은 신뢰 가능한 서명과 별도 PC 검증이 필요합니다. 보안 설정 해제나 자체 루트 인증서 설치를 요구하지 않습니다.\n');
await fs.writeFile(path.join(output,'README.md'),`# 내 공고 작업실

공개 채용공고를 모아 전공·학력·경력 표기로 거르고, 같은 공고와 같은 채용을 묶어 원문으로 바로 이동하는 로컬 프로그램입니다.

## 현재 기능

- 사람인·캐치·자소설닷컴·잡코리아 사이트별 검색 조건과 공개 공고 수집
- 전공 선택/동의어, 학력 하한, 경력 표기 필터
- 전체 너비 목록, 직무별 채용 묶음, 직접 원문 링크, 달력과 CSV
- 공고별 메모·준비 체크, 이미지 한국어 OCR, 현재 단계 진행률
- 로컬 저장 및 선택형 예약 수집(서버가 켜져 있는 동안)

## 실행

Node.js 22 이상이 필요합니다. 폴더를 내려받은 뒤:

~~~powershell
cd job-workbench/jobs
npm install
npx playwright install chromium
npm start
~~~

브라우저에서 http://127.0.0.1:42637/ 을 엽니다. Windows에서는 의존성 준비 후 상위 폴더의 ‘채용 공고 실행.cmd’를 사용할 수도 있습니다.

처음에는 공고 0건·사이트 선택 해제로 시작합니다. 전공과 사이트를 고르고 ‘세부 조건 펼치기’에서 조건을 저장한 뒤 ‘공고 가져오기’를 누르세요. Windows 한국어 OCR에는 해당 PC의 언어 인식 구성 요소가 필요합니다.

## 검증

jobs 폴더에서 실행합니다. 브라우저 검사는 임시 데이터/모의 수집기를 사용하며 실제 사이트 수집을 자동 실행하지 않습니다.

~~~powershell
npm test
npm run check:wide
npm run check:campaign
npm run check:progress
~~~

## 데이터와 범위

- 제작자의 실제 수집 공고·개인 조건·메모·로그·계정·원래 Git 이력은 포함하지 않습니다.
- jobs/fixtures는 재현 가능한 자동 검사 전용 공개/합성 예제입니다. 실행 공고 목록에는 자동으로 넣지 않습니다.
- 사용 후 생성되는 .runtime에는 개인 자료가 저장되며 Git에서 제외됩니다. 브라우저에도 필터·읽음·초안이 저장될 수 있습니다.
- 퍼센트는 현재 사이트의 처리 건수/현재 단계 기준이며 전체 수집 시간의 추정치가 아닙니다.
- 경력/전공 표기와 OCR은 지원 자격 확정이나 합격 확률이 아닙니다. 원문을 확인하세요.
- 현재 저장소는 소스 배포입니다. 서명 없는 Windows 설치기는 스마트 앱 컨트롤에 차단될 수 있으며 GitHub에 올리는 것만으로 해결되지 않습니다. 보안 기능을 끄도록 안내하지 않습니다.
- 여러 사용자가 링크로 접속하는 서비스가 아니라 같은 PC의 로컬 서버입니다.

## 개발/배포

jobs/build-portable.mjs와 build-setup.ps1은 별도 폴더에 체험 배포본을 만드는 개발 도구입니다. 기존 사용자 자료를 복사하지 않으며, 설치판 공개 전 코드 서명과 별도 PC 실행 검증이 필요합니다. 공식 회사 로고가 없는 공고에는 이니셜 마크를 사용합니다. 내장 Noto Sans KR 글꼴의 라이선스는 jobs/FONT-LICENSE.txt에 있습니다.
`);
const manifest=[];async function walk(dir){for(const entry of await fs.readdir(dir,{withFileTypes:true})){const file=path.join(dir,entry.name);if(entry.isDirectory())await walk(file);else{const bytes=await fs.readFile(file),relative=path.relative(output,file).replaceAll('\\','/');if(/(^|\/)\.runtime\/|(^|\/)node_modules\/|\.(exe|zip|pfx|pem|key)$/i.test(relative))throw Error('제외 대상 파일: '+relative);const text=bytes.toString('utf8');if(/(?:gh[pousr]_[A-Za-z0-9]{25,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|C:[\\/]+Users[\\/]+parkg)/.test(text))throw Error('개인 정보/비밀 후보 확인 필요: '+relative);manifest.push({path:relative,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')});}}}await walk(output);await fs.writeFile(path.join(output,'EXPORT-MANIFEST.json'),JSON.stringify({createdAt:new Date().toISOString(),files:manifest,privateDataIncluded:false},null,2)+'\n');console.log(JSON.stringify({output,files:manifest.length,bytes:manifest.reduce((n,f)=>n+f.bytes,0)}));
