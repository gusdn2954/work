import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import vm from 'node:vm';
const source=await fs.readFile(new URL('./dashboard.js',import.meta.url),'utf8');
function model(){const context=vm.createContext({viewUrl:s=>s.url,ymd:v=>{const t=Date.parse(v);return Number.isFinite(t)?new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Seoul'}).format(t):null;}});vm.runInContext(source.slice(source.indexOf('  let groupOn=true'),source.indexOf('  const memberIdsOf=')),context);return {run:(expression,rows)=>{context.rows=rows;return JSON.parse(JSON.stringify(vm.runInContext(expression,context)));}};}
const row=(id,site,title,company='피유코어',at='2026-11-01T23:59:00+09:00')=>({id,company,title,deadline:{at,label:'마감'},sources:[{site,url:'https://example.org/'+id}],partial:true,detailText:''});
const examples=()=>[
  row('equipment','사람인','26년 하반기 대졸 신입 공개채용(설비관리엔지니어)','에스케이피유코어(주)'),
  row('process','사람인','26년 하반기 대졸 신입 공개채용(공정엔지니어)','에스케이피유코어(주)'),
  row('summary','자소설닷컴','2026년 하반기 대졸 신입 공개채용'),
  row('catch','캐치',"'26년 하반기 대졸 신입 공개채용 #공채")
];
test('four sources keep three distinct notices inside one campaign without mutating originals',()=>{
  const rows=examples(),before=structuredClone(rows),result=model().run('campaignUnits(groupRecords(rows))',rows);
  assert.equal(result.length,1);assert.equal(result[0].campaign,true);assert.equal(result[0].company,'피유코어');assert.equal(result[0].rows.length,3);
  assert.equal(result[0].rows[0].sources.length,2);assert.deepEqual(new Set(result[0].rows.flatMap(r=>r.memberIds||[r.id])),new Set(rows.map(r=>r.id)));assert.deepEqual(rows,before);
});
test('filtered-out job is not brought back by its campaign or integrated posting',()=>{
  const rows=examples().filter(r=>r.id!=='equipment'),result=model().run('campaignUnits(groupRecords(rows))',rows);
  assert.equal(result[0].rows.length,2);assert.ok(!result.flatMap(u=>u.rows).some(r=>r.id==='equipment'));
  assert.equal(model().run('campaignUnits(rows)',[rows[0]]).length,1);assert.equal(model().run('campaignUnits(rows)',[rows[0]])[0].campaign,false);
});
test('turning grouping off preserves all four original notices',()=>{const result=model().run('campaignUnits(rows,false)',examples());assert.equal(result.length,4);assert.ok(result.every(u=>!u.campaign));});
test('company substrings and unrelated SK affiliates never create aliases',()=>{
  for(const [a,b] of [['한화','한화임팩트'],['SK하이닉스','SK이노베이션']]){const rows=[row('a','사람인','2026년 하반기 대졸 신입 공개채용(품질)',a),row('b','캐치','2026년 하반기 대졸 신입 공개채용(생산)',b)];assert.equal(model().run('campaignUnits(rows)',rows).filter(u=>u.campaign).length,0);}
});
test('different deadlines, hiring classes and seasons remain separate',()=>{
  const base=examples()[0];for(const other of [row('x','캐치','2026년 하반기 대졸 신입 공개채용','피유코어','2026-11-02T23:59:00+09:00'),row('x','캐치','2026년 상반기 대졸 신입 공개채용'),row('x','캐치','2026년 하반기 경력 공개채용'),row('x','캐치','2026년 하반기 대졸 신입 상시채용')])assert.equal(model().run('campaignUnits(rows)',[base,other]).filter(u=>u.campaign).length,0);
});
test('missing or ambiguous period and deadline do not create campaigns',()=>{
  for(const title of ['대졸 신입 공개채용(공정)','2026년 대졸 신입 공개채용(공정)','생산팀 채용(공정)']){const rows=[row('a','사람인',title),row('b','캐치',title)];assert.ok(model().run('campaignUnits(rows)',rows).every(u=>!u.campaign));}
  const rows=examples();rows.forEach(r=>r.deadline.at=null);assert.ok(model().run('campaignUnits(rows)',rows).every(u=>!u.campaign));
});
test('parent identity survives filtering and does not acquire job-specific qualifications',()=>{
  const rows=examples();rows[0].required=['기계 전공'];rows[1].required=['화학공학 전공'];const a=model().run('campaignUnits(groupRecords(rows))',rows)[0],b=model().run('campaignUnits(groupRecords(rows))',rows.filter(r=>r.id!=='equipment'))[0];assert.equal(a.key,b.key);assert.equal(a.required,undefined);assert.equal(a.rows.find(r=>r.id==='equipment').required[0],'기계 전공');assert.equal(a.rows.find(r=>r.id==='process').required[0],'화학공학 전공');
});

// ---- 2026-10-30 일반화: 피유코어 외 회사에도 같은 기준 적용(제목 근거·본문 근거), 오연결 방지
const rowD=(id,site,title,company,detailText='',at='2026-11-08T23:59:00+09:00')=>({id,company,title,deadline:{at,label:'마감'},sources:[{site,url:'https://example.org/'+id}],partial:false,detailText});
const units=(rows,expr='campaignUnits(groupRecords(rows))')=>model().run(expr,rows);
const campaigns=rows=>units(rows).filter(u=>u.campaign);
test('dash-suffixed job postings join the integrated posting of the same company and season',()=>{
  const rows=[rowD('p','자소설닷컴','2026년 하반기 공개채용','앤비젼'),rowD('p2','잡코리아','2026년 하반기 공개채용','㈜앤비젼'),...['품질관리','CS 엔지니어','광학 엔지니어(렌즈)'].map((t,i)=>rowD('c'+i,'잡코리아','2026년 하반기 공개채용 - '+t,'㈜앤비젼'))];
  const result=campaigns(rows);assert.equal(result.length,1);assert.equal(result[0].rows.length,4);assert.equal(result[0].rows[0].sources.length,2);
  assert.equal(result[0].roles.c2,'광학 엔지니어(렌즈)');assert.equal(result[0].roles.p,undefined===result[0].roles.p?result[0].roles.p:'');
});
test('same generic title and deadline at a different company is never linked',()=>{
  const rows=[rowD('a','자소설닷컴','2026년 하반기 공개채용','앤비젼'),rowD('b','잡코리아','2026년 하반기 공개채용 - 품질관리','㈜한국카본'),rowD('c','잡코리아','2026년 하반기 한국카본 관계사 공개채용','㈜한국카본'),rowD('d','잡코리아','2026년 하반기 한국카본 공개채용','㈜한국카본')];
  const found=campaigns(rows);assert.ok(found.every(u=>!u.rows.some(r=>r.id==="a")));assert.ok(found.every(u=>!(u.rows.some(r=>r.id==="c")&&u.rows.some(r=>r.id==="d"))));assert.equal(found.length,1);
});
test('temporary or rolling hiring is not bundled even with identical titles',()=>{
  for(const word of ['상시','수시']){const rows=[rowD('a','사람인','2026년 하반기 '+word+' 채용','가나다'),rowD('b','사람인','2026년 하반기 '+word+' 채용(품질)','가나다')];assert.equal(campaigns(rows).length,0);}
});
test('same site job postings of one season bundle, but a different hiring class stays outside',()=>{
  const rows=[rowD('s1','사람인','PKC(주) 2026년 하반기 신입사원 채용공고 (생산직)','피케이씨'),rowD('s2','사람인','PKC(주) 2026년 하반기 신입사원 채용공고 (총무/군산)','피케이씨'),rowD('k1','사람인','PKC(주) 2026년 하반기 경력사원 채용공고 (품질관리)','피케이씨')];
  const result=campaigns(rows);assert.equal(result.length,1);assert.deepEqual(result[0].rows.map(r=>r.id).sort(),['s1','s2']);
});
test('shared qualifiers are dropped from job labels and hyphen roles without spaces are read',()=>{
  const rows=['(화학소재 AI 기반 연구)','(바이오화학 소재 연구)'].map((t,i)=>rowD('r'+i,'사람인','2026년 하반기 정직원(연구분야) 채용'+t,'한국화학연구원'));
  const result=campaigns(rows)[0];assert.deepEqual(Object.values(result.roles),['화학소재 AI 기반 연구','바이오화학 소재 연구']);
  const dash=[rowD('d1','사람인','2026년 한국폴리아세탈 하반기 신입사원 채용-연구개발','한국폴리아세탈'),rowD('d2','사람인','2026년 한국폴리아세탈 하반기 신입사원 채용-영업','한국폴리아세탈')];
  assert.equal(campaigns(dash).length,1);
});
test('an English bracket label is removed only when the posting pairs it with the company name',()=>{
  const paired=rowD('hl','캐치','[H&L Advanced] 2026년 하반기 경영관리직 신입 채용 #공채','에이치앤엘어드밴스드','[에이치앤엘어드밴스드] [H&L Advanced] 2026년 하반기 경영관리직 신입 채용 #공채 [지원자격] 경력 : 신입','2026-11-10T23:59:00+09:00');
  const child=rowD('hc','사람인','2026년 하반기 경영관리직 신입 채용 (생산관리/화공)','에이치앤엘어드밴스드(주)','','2026-11-10T23:59:00+09:00');
  assert.equal(campaigns([paired,child]).length,1);
  assert.equal(campaigns([{...paired,detailText:'[지원자격] 경력 : 신입'},child]).length,0);
});
test('body evidence links a job posting only when the integrated posting lists its exact job name',()=>{
  const parentText='SK키파운드리 신입/경력 채용 '+'미래기술 Engineer, 제조기술 Engineer, MI Engineer, 품질 Engineer, 안전관리, Marketing '.repeat(8);
  const parent=rowD('parent','자소설닷컴','2026 각 분야 기술사무직 신입 및 경력 공개 채용','SK키파운드리',parentText);
  const child=rowD('child','캐치','품질 Engineer 분야 신입 채용','SK키파운드리','[SK키파운드리] 품질 Engineer 분야 신입 채용 [지원자격] 경력 : 신입 모집직무 : 품질관리 모집부문 : 품질 Engineer 근무지 : 충북 청주시');
  const found=campaigns([parent,child]);assert.equal(found.length,1);assert.equal(found[0].evidence.includes('본문'),true);assert.equal(found[0].roles.child,'품질 Engineer');
  assert.equal(campaigns([{...parent,detailText:'SK키파운드리 채용 '.repeat(40)},child]).length,0);
  const generic={...child,detailText:child.detailText.replaceAll('품질 Engineer','품질관리')};assert.equal(campaigns([parent,generic]).length,0);
  assert.equal(campaigns([{...parent,title:'2026 각 분야 수시 채용'},child]).length,0);
  assert.equal(campaigns([parent,{...parent,id:'parent2',title:'2026 반도체 연구소 경력 공개 채용',sources:[{site:'캐치',url:'https://example.org/p2'}]},child]).length,0);
});
test('a filtered-out parent or job never reappears through body evidence',()=>{
  const parent=rowD('parent','자소설닷컴','2026 각 분야 기술사무직 신입 및 경력 공개 채용','SK키파운드리','Engineer MI Engineer 품질 Engineer '.repeat(30));
  const child=rowD('child','캐치','MI Engineer 분야 신입 채용','SK키파운드리','모집부문 : MI Engineer 근무지 : 청주');
  assert.equal(campaigns([parent,child])[0].rows.length,2);for(const only of [[parent],[child]]){assert.equal(units(only).length,1);assert.equal(units(only)[0].campaign,false);}
});
test('same notice across sites is merged for company-in-title and group wording, but not across hiring classes',()=>{
  const isens=[rowD('i1','사람인','2026년 하반기 아이센스 대규모채용','(주)아이센스'),rowD('i2','자소설닷컴','2026 하반기 신입/경력 대규모 채용','아이센스'),rowD('i3','캐치','2026년 하반기 신입/경력 대규모 채용','아이센스')];
  assert.equal(units(isens).length,1);assert.equal(units(isens)[0].rows[0].sources.length,3);
  const group=[rowD('g1','자소설닷컴','2026년 하반기 신입사원 채용','대웅'),rowD('g2','캐치','2026년 하반기 대웅그룹 신입사원 채용 #공채','대웅')];assert.equal(units(group).length,1);
  const classes=[rowD('n1','사람인','2026년 하반기 신입 채용','가나다'),rowD('n2','캐치','2026년 하반기 경력 채용','가나다')];assert.equal(units(classes).length,2);
});
test('uncertain cases stay separate: different roles without a season, same-day roles of one company',()=>{
  const rows=[rowD('a','잡코리아','해외법인 한국인관리자 채용 (신입/경력) - 품질','유라코퍼레이션'),rowD('b','잡코리아','해외법인 한국인관리자 채용 (신입/경력) - 생산','유라코퍼레이션'),rowD('c','캐치','대졸 신입사원 채용 #공채','농심'),rowD('d','자소설닷컴','2026년 농심 신입 채용','농심')];
  assert.equal(campaigns(rows).length,0);assert.equal(units(rows).length,4);
});
