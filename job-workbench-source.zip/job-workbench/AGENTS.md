# 작업 인수인계

- Codex/Claude 중 사용자가 지정한 한 명만 수정합니다. 다른 AI를 자동 호출하지 않습니다.
- 개인 공고·경험·메모·검색조건·인증 정보는 .runtime에 보관하고 Git에 추가하지 않습니다. 배포본/공개 자료에는 빈 설정을 사용합니다.
- 현재 UI의 브라우저 검사는 jobs/wide-list-check.mjs, campaign-check.mjs, progress-browser-check.mjs입니다. tests의 고정 예제와 사용자 저장 자료를 구분합니다.
- 설치판은 신뢰 가능한 서명과 별도 PC 검증이 필요합니다. 보안 설정 해제나 자체 루트 인증서 설치를 요구하지 않습니다.
