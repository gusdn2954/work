import test from 'node:test';
import assert from 'node:assert/strict';
import './core.js';

const C=globalThis.JobsCore;
const row=(id,extra={})=>({id,company:'회사'+id,title:'공고'+id,roles:[],locations:[],career:[],employment:[],deadline:{},sources:[],...extra});

test('최신순은 처음 수집한 시각이 늦은 순서이고 시각 미확인은 뒤에 입력 순서로 둔다',()=>{
  const rows=[row('a'),row('b',{discoveredAt:'2026-10-20T00:00:00Z'}),row('c',{discoveredAt:'not-a-date'}),row('d',{discoveredAt:'2026-10-25T00:00:00Z'})];
  assert.deepEqual(C.sortRecords(rows,'latest').map(r=>r.id),['d','b','a','c']);
});

test('수정순은 저장된 확인 시각 중 가장 늦은 값을 쓰고 없으면 뒤로 보낸다',()=>{
  const rows=[row('a',{checkedAt:'2026-10-20T00:00:00Z'}),row('b'),row('c',{checkedAt:'2026-10-01T00:00:00Z',sources:[{checkedAt:'2026-10-26T00:00:00Z'}]})];
  assert.deepEqual(C.sortRecords(rows,'modified').map(r=>r.id),['c','a','b']);
});

test('마감순은 이른 마감이 먼저이고 마감 시각 미확인은 뒤에 둔다. 원본 배열은 바꾸지 않는다',()=>{
  const rows=[row('a'),row('b',{deadline:{at:'2026-11-05T00:00:00Z'}}),row('c',{deadline:{at:'2026-11-01T00:00:00Z'}})];
  assert.deepEqual(C.sortRecords(rows,'deadline').map(r=>r.id),['c','b','a']);
  assert.deepEqual(rows.map(r=>r.id),['a','b','c']);
});

test('지원하지 않는 정렬 키는 입력 순서를 그대로 둔다',()=>{
  assert.deepEqual(C.sortRecords([row('a'),row('b')],'views').map(r=>r.id),['a','b']);
});

test('페이지 범위는 필터·개수 변경 뒤에도 마지막 페이지로 보정된다',()=>{
  assert.deepEqual(C.paginate(45,1,20),{page:1,pages:3,size:20,start:0,end:20});
  assert.deepEqual(C.paginate(45,9,20),{page:3,pages:3,size:20,start:40,end:45});
  assert.deepEqual(C.paginate(0,4,50),{page:1,pages:1,size:50,start:0,end:0});
  assert.equal(C.paginate(8,0,100).page,1);
});
