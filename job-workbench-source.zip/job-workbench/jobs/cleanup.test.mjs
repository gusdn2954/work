import test from 'node:test';
import assert from 'node:assert/strict';
import {pruneCollected} from './server.mjs';
// 수집 뒤 정리 규칙: 마감 지난 공고, 사이트 검색 결과에서 사라진 공고를 지우되 안전장치가 걸리면 지우지 않는다.
const NOW=Date.parse('2026-10-30T12:00:00+09:00'),day=(d)=>({at:d,label:'x'});
const rec=(id,deadlineAt,extra={})=>({id,company:'회사',title:id,deadline:deadlineAt===undefined?{at:null,label:'채용시'}:day(deadlineAt),sources:[{site:'사이트',url:'https://example.org/'+id}],...extra});
const OPEN='2026-11-20T23:59:59+09:00',CLOSED='2026-10-29T23:59:59+09:00';
const scan=(over={})=>({complete:true,stopReason:null,siteTotal:2,unique:2,...over});
const run=(collected,over={})=>pruneCollected(collected,{site:'saramin',runId:'r2',runs:[],plan:{remoteKey:'k'},records:[rec('saramin-1',OPEN),rec('saramin-2',OPEN)],scan:scan(),nowMs:NOW,...over});
const ids=r=>r.collected.map(x=>x.id);
test('closed postings are removed, rolling postings without a deadline are kept',()=>{
  const r=run([rec('saramin-1',OPEN),rec('saramin-2',OPEN),rec('saramin-9',CLOSED),rec('catch-9',CLOSED),rec('saramin-8',undefined)],{records:[rec('saramin-1',OPEN),rec('saramin-2',OPEN),rec('saramin-8',undefined)]});
  assert.deepEqual(ids(r).sort(),['saramin-1','saramin-2','saramin-8']);assert.deepEqual(r.removed.map(x=>x.reason).sort(),['마감','마감']);
});
test('postings that vanished from a complete search are removed for that site only',()=>{
  const r=run([rec('saramin-1',OPEN),rec('saramin-2',OPEN),rec('saramin-3',OPEN),rec('catch-3',OPEN),rec('gs-2026-h2',OPEN)]);
  assert.deepEqual(ids(r).sort(),['catch-3','gs-2026-h2','saramin-1','saramin-2']);assert.equal(r.removed.length,1);assert.equal(r.removed[0].reason,'사이트 검색 결과에서 사라짐');assert.equal(r.skipped,null);
});
test('an incomplete scan, an empty result or a sudden drop never deletes vanished postings',()=>{
  const stored=[rec('saramin-1',OPEN),rec('saramin-2',OPEN),rec('saramin-3',OPEN),rec('saramin-4',OPEN)];
  for(const over of [{scan:scan({complete:false})},{scan:scan({stopReason:'limit'})},{records:[]}]){const r=run(stored,over);assert.equal(ids(r).length,4);assert.ok(r.skipped);}
  const previousRuns=[{id:'r1',site:'saramin',status:'completed',count:10,plan:{remoteKey:'k'}}];
  const dropped=run(stored,{runs:previousRuns,records:[rec('saramin-1',OPEN),rec('saramin-2',OPEN)]});assert.equal(ids(dropped).length,4);assert.match(dropped.skipped,/절반/);
  const changed=run(stored,{runs:[{...previousRuns[0],plan:{remoteKey:'other'}}],records:[rec('saramin-1',OPEN),rec('saramin-2',OPEN)]});assert.equal(ids(changed).length,2);
});
test('postings added by direct address are never treated as vanished',()=>{
  const r=run([rec('saramin-1',OPEN),rec('saramin-2',OPEN),rec('saramin-7',OPEN,{manualAdd:true})]);assert.ok(ids(r).includes('saramin-7'));
  const direct=run([rec('saramin-1',OPEN),rec('saramin-5',OPEN)],{directUrls:true,records:[rec('saramin-5',OPEN)]});assert.equal(ids(direct).length,2);assert.ok(direct.skipped);
});
test('the search result itself is kept even when its deadline already passed on the site',()=>{
  const r=run([rec('saramin-1',CLOSED),rec('saramin-2',OPEN)],{records:[rec('saramin-1',CLOSED),rec('saramin-2',OPEN)]});assert.equal(ids(r).length,2);
});
