(function () {
  'use strict';
  const fields = ['keyword','roles','locations','career','employment','hiring','education','industry','companyType','exclude','nativeUrl','nativeNotes','siteKeyword','duties','nativeQuery'];
  const parts = value => String(value || '').split(/[,，\n]/).map(x => x.trim().toLocaleLowerCase('ko')).filter(Boolean);
  const flatten = value => (Array.isArray(value) ? value.join(' ') : String(value || '')).toLocaleLowerCase('ko');
  function defaults(schema) {
    return {schemaVersion:1,project:schema.project,sites:Object.fromEntries(schema.sites.map(s => [s.id,{enabled:true,includeUnknown:true,...Object.fromEntries(fields.map(f => [f,'']))}]))};
  }
  function safeUrl(value, host) {
    try { const u = new URL(value); return u.protocol === 'https:' && !u.username && !u.password && (!u.port || u.port === '443') && (!host || u.hostname === host || u.hostname.endsWith('.' + host)) ? u.href : null; } catch { return null; }
  }
  function normalizeSettings(value, schema) {
    if (!value || value.schemaVersion !== 1 || value.project !== schema.project || !value.sites || typeof value.sites !== 'object') throw new Error('이 프로젝트의 버전 1 검색조건 JSON을 선택하세요.');
    const result = defaults(schema);
    for (const site of schema.sites) {
      const row = value.sites[site.id]; if (!row || typeof row !== 'object') continue;
      for (const f of fields) if (typeof row[f] === 'string') result.sites[site.id][f] = row[f].slice(0,4000);
      for (const f of ['enabled','includeUnknown']) if (typeof row[f] === 'boolean') result.sites[site.id][f] = row[f];
      const url = result.sites[site.id].nativeUrl;
      if (url && !safeUrl(url,site.host)) throw new Error(site.name + ': 해당 사이트의 HTTPS 검색결과 주소를 입력하세요.');
    }
    return result;
  }
  // 사람인 검색 주소(nativeUrl)를 읽는다. 공식 HTTPS 공개 검색(/zf_user/search)만 받고, 알려진 조건만 요청에 옮긴다.
  // 모르는 값이 있는 파라미터는 조용히 버리지 않고 오류로 알린다. 학력/경력 라벨은 사람인 검색 폼에서 확인한 값만 둔다.
  const sarPass = ['searchword','exp_cd','edu_min','edu_max','company_type','company_cd','recruitSort'];
  const sarIgnore = ['searchType','search_optional_item','panel_count','recruitPage','recruitPageCount','mainSearch','search_done'];
  const sarEmpty = ['inner_com_type','show_applied','quick_apply','except_read','ai_head_hunting'];
  const sarLabels = {exp_cd:{'1':'신입','2':'경력'},edu_min:{'5':'박사졸업 이상','6':'고등학교 졸업 이상','7':'대학졸업(2,3년) 이상','8':'대학교졸업(4년) 이상','9':'석사졸업 이상'},edu_max:{'9':'고등학교 졸업 이하','10':'대학졸업(2,3년) 이하','11':'대학교졸업(4년) 이하'},company_type:{scale001:'대기업',scale002:'매출1000대기업',scale003:'중견기업',scale004:'중소기업',scale005:'스타트업',scale006:'개인사업자',foreign:'외국계(법인/투자)',public:'공사/공기업',laboratory:'연구소',school:'학교/교육기관','social-welfare':'사회복지기관','banking-organ':'금융기관',nonprofit:'비영리단체/협회','medical-institution':'병원/의료기관'}};
  // 쉼표가 저장 구분자라 화면 이름에는 쉼표를 쓰지 않는다. 사람인 화면 표기와 이전 표기도 같은 코드로 읽는다.
  const sarTypeAliases = {'공사·공기업':'public','공사, 공기업':'public','학교·교육기관':'school','비영리단체·협회':'nonprofit','병원·의료기관':'medical-institution','외국계':'foreign','외국계기업':'foreign'};
  // 기업형태 선택값(쉼표로 구분한 표시 이름 또는 사람인 코드) → 사람인 company_type 코드. 알 수 없는 값은 버리지 않고 bad로 돌려준다.
  const sarTypeOrder = Object.keys(sarLabels.company_type);
  function saraminCompanyCodes(text) {
    const byLabel = {...Object.fromEntries(Object.entries(sarTypeAliases).map(([k, c]) => [k.toLocaleLowerCase('ko'), c])), ...Object.fromEntries(sarTypeOrder.map(c => [sarLabels.company_type[c].toLocaleLowerCase('ko'), c]))};
    const codes = new Set(), unknown = [];
    for (const term of String(text || '').split(/[,，\n]/).map(x => x.trim()).filter(Boolean)) {
      const code = byLabel[term.toLocaleLowerCase('ko')] || (sarTypeOrder.includes(term) ? term : null);
      if (code) codes.add(code); else unknown.push(term);
    }
    return {codes: [...codes].sort((a, b) => sarTypeOrder.indexOf(a) - sarTypeOrder.indexOf(b)), unknown};
  }
  // 화면 선택값 중 사람인 코드가 확인된 것만 요청으로 옮긴다(사용자 검색 주소 exp_cd=1·edu_min=8·edu_max=11 = 신입·대학교(4년) 졸업). 그 밖의 값은 로컬 문구 검사로 남긴다.
  const sarSelectionCodes = {career: {'신입': {exp_cd: '1'}, '경력': {exp_cd: '2'}}, education: {'대졸': {edu_min: '8', edu_max: '11'}}};
  function saraminSelection(extra) {
    const out = {}, from = [], one = v => { const t = String(v || '').split(/[,，\n]/).map(x => x.trim()).filter(Boolean); return t.length === 1 ? t[0] : null; };
    const kw = one(extra?.keyword); if (kw && kw.length <= 120) { out.searchword = kw; from.push('keyword'); }
    for (const field of ['career', 'education']) { const hit = sarSelectionCodes[field][one(extra?.[field])]; if (hit) { Object.assign(out, hit); from.push(field); } }
    return {params: out, from};
  }
  // value: 사람인 검색 주소, companyTypeText: 화면의 기업형태 선택값. 선택값이 있으면 그 값이 company_type을 정한다(주소와 다르면 notes에 알린다).
  // extra: 화면의 검색어·경력·학력 선택값. 주소에 같은 조건이 없을 때만 요청에 더한다(주소 조건이 우선).
  function saraminQuery(value, companyTypeText = '', extra = {}) {
    const text = String(value || '').trim(), typed = saraminCompanyCodes(companyTypeText), chosen = saraminSelection(extra);
    if (!text && !typed.codes.length && !typed.unknown.length && !chosen.from.length) return null;
    const bad = message => ({ok:false,error:'사람인 검색 주소: ' + message});
    let u = null;
    if (text) {
      try { u = new URL(text); } catch { return bad('주소 형식을 읽지 못했습니다.'); }
      if (u.protocol !== 'https:' || u.hostname !== 'www.saramin.co.kr' || u.username || u.password || (u.port && u.port !== '443') || u.pathname !== '/zf_user/search') return bad('www.saramin.co.kr의 공개 검색(/zf_user/search) HTTPS 주소만 사용할 수 있습니다.');
    }
    if (typed.unknown.length) return {ok:false,error:'사람인 기업형태: 사람인 코드를 확인할 수 없는 선택값이 있어 요청하지 않았습니다 (' + typed.unknown.slice(0,5).join(', ') + ')'};
    const params = {}, unknown = [], notes = [];
    for (const [rawKey, val] of u ? u.searchParams : []) {
      const key = rawKey.replace(/\[\]$/, '');
      if (sarIgnore.includes(key)) continue;
      if (sarEmpty.includes(key)) { if (val) unknown.push(key + '=' + val); continue; }
      if (!sarPass.includes(key)) { unknown.push(rawKey); continue; }
      if (!val) continue;
      params[key] = key === 'searchword' || key === 'recruitSort' ? val : [...new Set([...(params[key] ? params[key].split(',') : []), ...val.split(',')].map(x => x.trim()).filter(Boolean))].join(',');
    }
    if (unknown.length) return bad('아직 요청에 옮길 수 없는 조건이 있어 적용하지 않았습니다: ' + unknown.slice(0,5).join(', '));
    if (params.searchword && (params.searchword.length > 120 || /[,，\n]/.test(params.searchword))) return bad('검색어는 쉼표 없이 120자 이내여야 합니다.');
    for (const [key, re] of [['exp_cd',/^\d{1,2}(,\d{1,2})*$/],['edu_min',/^\d{1,2}$/],['edu_max',/^\d{1,2}$/],['company_cd',/^\d{1,2}(,\d{1,2})*$/],['company_type',/^[a-z0-9-]{3,30}(,[a-z0-9-]{3,30})*$/],['recruitSort',/^[a-z_]{1,12}$/]]) if (params[key] && !re.test(params[key])) return bad(key + ' 값을 확인할 수 없습니다.');
    const urlParsed = saraminCompanyCodes(params.company_type), urlTypes = urlParsed.codes;
    if (params.company_type && !urlParsed.unknown.length) params.company_type = urlTypes.join(','); // 알려진 코드만 있을 때만 순서를 정규화한다.
    let companyTypeSource = params.company_type ? 'url' : null;
    // 주소에만 있는(이 화면이 코드를 모르는) 기업형태 코드는 선택값과 함께 그대로 보낸다.
    const urlExtra = urlParsed.unknown;
    if (typed.codes.length) {
      if (urlTypes.length && urlTypes.join(',') !== typed.codes.join(',')) notes.push('주소의 기업형태(' + urlTypes.map(c => sarLabels.company_type[c]).join(', ') + ')와 선택값이 달라 선택값을 사용합니다.');
      params.company_type = [...typed.codes, ...urlExtra].join(','); companyTypeSource = 'selection';
    }
    if (urlExtra.length) notes.push('사람인 주소의 기업형태 코드 ' + urlExtra.join(', ') + '는 이 화면에서 이름을 확인하지 못했지만 주소대로 요청에 보냅니다.');
    const fromSelection = [];
    for (const field of chosen.from) {
      const keys = field === 'keyword' ? ['searchword'] : field === 'career' ? ['exp_cd'] : ['edu_min', 'edu_max'];
      if (keys.some(k => params[k])) continue;
      for (const k of keys) if (chosen.params[k]) params[k] = chosen.params[k];
      fromSelection.push(field);
    }
    if (!Object.keys(params).length) return bad('적용할 검색 조건이 없습니다.');
    const covered = [params.searchword && 'keyword', params.exp_cd && 'career', (params.edu_min || params.edu_max) && 'education', params.company_type && 'companyType'].filter(Boolean);
    const labelOf = (k, v) => String(v).split(',').map(x => sarLabels[k]?.[x] || x + '(코드 이름 미확인)').join(', ');
    const labels = [params.searchword && '검색어 ' + params.searchword, params.exp_cd && '경력 ' + labelOf('exp_cd', params.exp_cd), params.edu_min && '학력 최소 ' + labelOf('edu_min', params.edu_min), params.edu_max && '학력 최대 ' + labelOf('edu_max', params.edu_max), params.company_type && '기업형태 ' + labelOf('company_type', params.company_type), params.company_cd && '채용구분 코드 ' + params.company_cd, params.recruitSort && '정렬 ' + params.recruitSort].filter(Boolean);
    const key = Object.keys(params).sort().map(k => k + '=' + params[k]).join('&');
    return {ok:true,params,covered,labels,key,notes,companyTypeSource,fromSelection};
  }
  // 사이트별 검색어: 비우면 공통 검색어, '*'이면 검색어 없이 찾는다.
  function siteKeywordOf(filter) { const own = String(filter?.siteKeyword || '').trim(); return own === '*' ? '' : own || String(filter?.keyword || '').trim(); }
  // 자소설닷컴 공개 검색(/search)의 조건 코드. 화면 스크립트와 공개 직무 목록(/api/v1/duty-groups, 2026-10-28 확인)에서 가져온 값만 쓴다. [id, 이름, 상위 id]
  const jssDuties = [[91,"경영·사무",0],[92,"마케팅·광고·홍보",0],[93,"무역·유통",0],[94,"IT·인터넷",0],[95,"생산·제조",0],[96,"영업·고객상담",0],[97,"건설",0],[98,"금융",0],[99,"연구개발·설계",0],[100,"디자인",0],[101,"미디어",0],[102,"전문·특수직",0],[103,"기획·전략·경영",91],[104,"인사·노무·교육",91],[105,"재무·세무·IR",91],[106,"경리·회계·결산",91],[107,"일반사무·총무·비서",91],[108,"법무",91],[109,"경영기획",103],[110,"사업기획",103],[111,"경영전략",103],[112,"사업전략",103],[113,"경영분석·컨설턴트",103],[114,"기타",103],[115,"인사",104],[116,"노무",104],[117,"교육",104],[118,"채용",104],[119,"급여",104],[120,"보상관리",104],[121,"기타",104],[122,"재무",105],[123,"세무",105],[124,"IR",105],[125,"자금",105],[126,"기타",105],[127,"일반사무",107],[128,"총무",107],[129,"비서",107],[130,"사무보조",107],[131,"기타",107],[132,"마케팅",92],[133,"광고·홍보",92],[134,"브랜드마케팅",132],[135,"콘텐츠마케팅",132],[136,"퍼포먼스·온라인마케팅",132],[137,"마케팅전략·기획",132],[138,"상품기획",132],[139,"기타",132],[140,"광고기획·AE",133],[141,"광고제작·카피",133],[142,"언론홍보·PR",133],[143,"사내홍보",133],[144,"기타",133],[145,"유통·물류·재고",93],[146,"무역·해외영업",93],[147,"구매·자재",93],[148,"운전·운송",93],[149,"상품기획·MD",93],[150,"물류관리·기획",145],[151,"유통관리·기획",145],[152,"재고",145],[153,"기타",145],[154,"해외영업",146],[155,"무역·수출입관리",146],[156,"기타",146],[157,"구매",147],[158,"자재",147],[159,"기타",147],[160,"QA",94],[161,"앱개발",94],[162,"웹개발",94],[163,"데이터엔지니어·분석·DBA",94],[164,"시스템프로그래머",94],[165,"응용프로그래머",94],[166,"네트워크·보안·운영",94],[167,"빅데이터·AI(인공지능)",94],[168,"게임개발",94],[169,"HW·임베디드",94],[170,"SW·솔루션·ERP",94],[171,"서비스기획·PM",94],[172,"iOS개발",161],[173,"안드로이드개발",161],[174,"기타",161],[175,"프론트엔드개발",162],[176,"서버·백엔드개발",162],[177,"HTML·퍼블리싱",162],[178,"기타",162],[179,"데이터엔지니어",163],[180,"데이터분석",163],[181,"DBA",163],[182,"기타",163],[183,"생산관리·공정관리·품질관리",95],[184,"안전·환경관리",95],[185,"생산·제조·설비·조립",95],[186,"설치·정비·AS·시공·공무",95],[187,"생산관리",183],[188,"공정관리",183],[189,"품질관리",183],[190,"기타",183],[191,"안전관리",184],[192,"환경관리",184],[193,"기타",184],[194,"제품·서비스영업",96],[195,"IT·솔루션·기술영업",96],[196,"B2B영업·법인영업",96],[197,"영업관리·지원·기획",96],[198,"아웃바운드",96],[199,"인바운드",96],[200,"고객응대·CS",96],[201,"금융·보험영업",96],[202,"현장·시공·감리·공무",97],[203,"안전·품질·관리",97],[204,"전기·통신",97],[205,"기계·설비·화학",97],[206,"토목·조경·도시",97],[207,"건축·설계·인테리어",97],[208,"환경·플랜트",97],[209,"부동산·영업·견적",97],[210,"증권·투자",98],[211,"외환·펀드·자산운용",98],[212,"보험계리사·손해사정",98],[213,"채권·심사",98],[214,"은행원",98],[215,"애널리스트",98],[216,"자동차·기계",99],[217,"화학·에너지·환경",99],[218,"바이오·제약·식품",99],[219,"기계설계·CAD·CAM",99],[220,"전기·전자·제어",99],[221,"반도체·디스플레이",99],[222,"통신기술·네트워크 구축",99],[223,"금속·철강",99],[224,"조선·항공·우주",99],[225,"인문·사회과학",99],[226,"자동차",216],[227,"기계",216],[228,"기타",216],[229,"화학",217],[230,"에너지",217],[231,"환경",217],[232,"화장품",217],[233,"기타",217],[234,"바이오·제약",218],[235,"식품",218],[236,"기타",218],[237,"광고·시각디자인",100],[238,"제품·산업디자인",100],[239,"건축·인테리어디자인",100],[240,"의류·패션·잡화디자인",100],[241,"UI·UX디자인",100],[242,"광고 디자인",237],[243,"그래픽디자인·CG",237],[244,"출판·편집디자인",237],[245,"캐릭터·애니메이션",237],[246,"기타",237],[247,"연출·제작·PD·작가",101],[248,"음악·영상·사진",101],[249,"아나운서·리포터·성우·기자",101],[250,"무대·스탭·오퍼레이터",101],[251,"연예·엔터테인먼트",101],[252,"인쇄·출판·편집",101],[253,"리서치·시장조사",102],[254,"외국어·번역·통역",102],[255,"법률·특허·상표",102],[256,"회계·세무·CPA·CFA",102],[257,"보안·경비·경호",102],[258,"보건·의료",102],[259,"초·중·고 교사",102],[260,"교육개발·기획",102],[261,"외국어·자격증·기술강사",102],[262,"사회복지·요양보호·자원봉사",102],[263,"승무원·숙박·여행 서비스",102],[264,"음식서비스",102]];
  const jssDivision = {'신입':1,'경력':2,'인턴':3,'계약직':4,'교육':7}, jssDivisionLabel = {1:'신입',2:'경력',3:'인턴',4:'계약직',7:'교육'};
  // 자소설닷컴에는 정규직·경력무관 구분이 없다. 정규직은 신입/경력 공고에 포함되고, 경력무관은 신입+경력으로 본다.
  const jssDivisionExtra = {'정규직':[],'경력무관':[1,2]};
  const jssBusiness = {'대기업':'big_business','매출1000대기업':'big_business','중견기업':'middle_market','공사/공기업':'public_institution','공기업':'public_institution','공공기관':'public_institution'}, jssBusinessLabel = {big_business:'대기업',middle_market:'중견기업',public_institution:'공공기관',other_business_type:'기타기업'};
  // 고른 직무(대·중분류 포함)를 사이트와 같이 가장 아래 단계 id로 펼친다(하위가 없는 중분류는 그 id 자체).
  function jssLeafIds(ids) { const out = new Set(), walk = id => { const kids = jssDuties.filter(d => d[2] === id); if (!kids.length) out.add(id); else kids.forEach(k => walk(k[0])); }; for (const id of ids) if (jssDuties.some(d => d[0] === id)) walk(id); return [...out].sort((a, b) => a - b); }
  function jasoseolQuery(filter) {
    const split = v => String(v || '').split(/[,，\n]/).map(x => x.trim()).filter(Boolean);
    const params = {}, covered = [], notes = [], keyword = siteKeywordOf(filter);
    if (keyword) { params.keyword = keyword; covered.push('keyword'); }
    const division = new Set(), mapField = field => { const terms = split(filter?.[field]); if (!terms.length) return; let all = true; for (const t of terms) { if (jssDivision[t]) division.add(jssDivision[t]); else if (jssDivisionExtra[t]) jssDivisionExtra[t].forEach(d => division.add(d)); else all = false; } if (all) covered.push(field); else notes.push(field + '의 일부 값은 자소설닷컴 구분이 없어 받은 뒤 거릅니다.'); };
    ['career', 'employment', 'hiring'].forEach(mapField);
    if (division.size) params.division = [...division].sort((a, b) => a - b).join(',');
    const types = split(filter?.companyType);
    if (types.length) { params.businessTypes = [...new Set(types.map(t => jssBusiness[t] || 'other_business_type'))].sort().join(','); covered.push('companyType'); }
    const duties = jssLeafIds(split(filter?.duties).map(Number).filter(Number.isSafeInteger));
    if (duties.length) params.dutyGroupIds = duties.join(',');
    if (!Object.keys(params).length) return null;
    params.excludeClosed = 'true';
    const labels = [params.keyword && '검색어 ' + params.keyword, params.division && '채용형태 ' + params.division.split(',').map(d => jssDivisionLabel[d]).join(', '), params.businessTypes && '기업형태 ' + params.businessTypes.split(',').map(b => jssBusinessLabel[b]).join(', '), params.dutyGroupIds && '직무 ' + duties.length + '개', '마감 공고 제외'].filter(Boolean);
    const key = Object.keys(params).sort().map(k => k + '=' + params[k]).join('&');
    return {ok: true, params, covered, labels, key, notes};
  }
  // 사이트 양식 조건: 사이트 검색 화면과 같은 이름·코드를 주소 형식(a=1,2&b=x)으로 저장한다. 사이트마다 아는 이름만 받고, 모르는 이름·형식은 오류로 알린다.
  const nativeParams = {
    saramin: ['searchword','exp_cd','edu_min','edu_max','company_type','cat_mcls','cat_kewd','ind_cd','ind_key','loc_mcd','loc_cd'],
    catch: ['Keyword','Career','JobCode','Size','JCode','EduLevel','Sido','WorkPosition'],
    jasoseol: ['keyword','division','businessTypes','excludeClosed','dutyGroupIds'],
    jobkorea: ['duty','dutyCtgr','local','career','edu','cotype','jobtype','industry','industryCtgr']
  };
  const nativeText = {saramin: 'searchword', catch: 'Keyword', jasoseol: 'keyword'};
  function nativeQuery(siteId, value) {
    const text = String(value || '').trim(); if (!text) return null;
    const allowed = nativeParams[siteId]; if (!allowed) return {ok: false, error: '사이트 양식을 지원하지 않는 사이트입니다.'};
    const params = {}, bad = [];
    for (const [key, raw] of new URLSearchParams(text)) {
      const val = raw.trim(); if (!val) continue;
      if (!allowed.includes(key)) { bad.push(key); continue; }
      const ok = key === nativeText[siteId] ? val.length <= 120 && !/[\n\r]/.test(val) : /^[\p{L}\p{N}_-]{1,40}(,[\p{L}\p{N}_-]{1,40}){0,199}$/u.test(val);
      if (!ok) bad.push(key); else params[key] = val;
    }
    if (bad.length) return {ok: false, error: '사이트 양식 조건을 읽지 못했습니다: ' + [...new Set(bad)].join(', ')};
    if (!Object.keys(params).length) return null;
    const key = Object.keys(params).sort().map(k => k + '=' + params[k]).join('&');
    return {ok: true, params, key, native: true};
  }
  function state(record, now = Date.now()) {
    if (record.observedClosed) return 'closed';
    const at = Date.parse(record.deadline?.at);
    if (!Number.isFinite(at)) return 'unknown';
    if (at <= now) return 'closed';
    return at - now <= 7 * 86400000 ? 'urgent' : 'open';
  }
  function matches(record, filter, site) {
    if (!filter?.enabled) return false;
    const all = flatten([record.company,record.title,...record.roles,...record.locations,...record.career,...record.employment,record.education,record.industry,record.companyType]);
    // 사람인이 같은 주소 조건으로 직접 돌려준 공고는 그 조건이 덮는 항목(검색어/경력/학력/기업형태)을 로컬 문구로 다시 탈락시키지 않는다.
    const native = nativeQuery(site.id, filter.nativeQuery);
    if (native) return native.ok && (record.remoteMatches || []).some(m => m.key === native.key) && !parts(filter.exclude).some(t => flatten([record.company,record.title]).includes(t));
    const query = site.id === 'saramin' ? saraminQuery(filter.nativeUrl, filter.companyType, {...filter, keyword: siteKeywordOf(filter)}) : site.id === 'jasoseol' ? jasoseolQuery(filter) : null;
    const confirmed = query?.ok && (record.remoteMatches || []).some(m => m.key === query.key), skip = confirmed ? query.covered : [];
    // 사람인 요청 조건이 있으면 그 조건으로 사람인이 돌려준 공고만 남긴다(사람인 검색 결과와 같은 목록). 다른 조건으로 모은 기존 공고는 다시 수집해야 표시된다.
    if (query?.ok && !confirmed) return false;
    if (parts(filter.exclude).some(t => all.includes(t))) return false;
    const keyword = parts(siteKeywordOf(filter)); // 사이트별 검색어가 있으면 그것을, '*'이면 검색어 없이 본다.
    if (!skip.includes('keyword') && keyword.length && !keyword.some(t => all.includes(t))) return false;
    for (const field of new Set([...site.fields,'locations'])) {
      if (skip.includes(field)) continue;
      const terms = parts(filter[field]); if (!terms.length) continue;
      const haystack = flatten(field === 'hiring' ? [...record.career,...record.employment] : record[field]);
      if (!haystack || haystack.startsWith('미확인')) { if (!filter.includeUnknown) return false; continue; }
      if (!terms.some(t => haystack.includes(t))) return false;
    }
    return true;
  }
  function select(records, settings, schema, {site='all',group='open',search='',now=Date.now()}={}) {
    const active = schema.sites.filter(s => (site === 'all' || site === s.id) && settings.sites[s.id]?.enabled);
    return records.filter(r => {
      const status = state(r,now);
      if (group === 'closed' ? status !== 'closed' : group !== 'all' && status === 'closed') return false;
      if (group === 'urgent' && status !== 'urgent') return false;
      if (group === 'priority' && r.review !== '우선 검토') return false;
      if (group === 'check' && r.review !== '추가 확인') return false;
      if (search && !flatten([r.company,r.title,...r.roles]).includes(search.toLocaleLowerCase('ko'))) return false;
      return active.some(s => r.sources.some(source => source.site === s.name) && matches(r,settings.sites[s.id],s));
    }).sort((a,b) => (Date.parse(a.deadline.at)||Infinity) - (Date.parse(b.deadline.at)||Infinity));
  }
  // 화면 정렬용. 저장된 시각만 사용하고 시각이 없거나 읽을 수 없는 공고는 항상 뒤로 보낸다. 같은 값은 입력 순서를 유지한다.
  const time = value => { const t = Date.parse(value); return Number.isFinite(t) ? t : null; };
  const sortTimes = {
    latest: r => time(r.discoveredAt),
    modified: r => { const times = [r.detailCheckedAt,r.checkedAt,r.latestObservation?.checkedAt,...(r.sources || []).map(s => s.checkedAt)].map(time).filter(t => t !== null); return times.length ? Math.max(...times) : null; },
    deadline: r => time(r.deadline?.at)
  };
  function sortRecords(records, key='deadline') {
    const read = sortTimes[key]; if (!read) return records.slice();
    const direction = key === 'deadline' ? 1 : -1;
    return records.map((r,i) => ({r,i,t:read(r)})).sort((a,b) => (a.t === null) - (b.t === null) || (a.t === null ? 0 : direction * (a.t - b.t)) || a.i - b.i).map(x => x.r);
  }
  function paginate(total, page=1, size=20) {
    const per = Math.max(1, Math.floor(Number(size)) || 20), pages = Math.max(1, Math.ceil(Math.max(0, total) / per));
    const current = Math.min(Math.max(1, Math.floor(Number(page)) || 1), pages), start = total > 0 ? (current - 1) * per : 0;
    return {page:current,pages,size:per,start,end:Math.min(total, start + per)};
  }
  function summary(records, now=Date.now()) {
    return {unique:records.length,postings:records.flatMap(r=>r.sources).filter(s=>!s.official).length,open:records.filter(r=>state(r,now)!=='closed').length,closed:records.filter(r=>state(r,now)==='closed').length,urgent:records.filter(r=>state(r,now)==='urgent').length,bySite:Object.fromEntries(['캐치','자소설닷컴','사람인','잡코리아'].map(s=>[s,records.filter(r=>r.sources.some(x=>x.site===s)).length]))};
  }
  // 실패한 수집 메시지에 사용자가 할 수 있는 다음 행동을 붙인다. 원인을 추측하지 않고 메시지에 있는 사실만 분류한다.
  function recoveryHint(run) {
    if (!run || !['failed','partial'].includes(run.status)) return '';
    const m = String(run.message || '');
    if (/수집용 브라우저가 없습니다/.test(m)) return '조치: 브라우저 구성요소가 없습니다. README의 설치 안내를 확인한 뒤 다시 수집하세요. 기존 공고는 그대로입니다.';
    if (/응답 (?:429|403)/.test(m)) return '조치: 사이트가 요청을 제한했습니다. 잠시 뒤 다시 시도하세요. 자동으로 반복 요청하지 않습니다.';
    if (/응답 5\d\d/.test(m)) return '조치: 사이트 쪽 오류입니다. 나중에 다시 시도하세요. 기존 공고와 이전 본문은 보존됩니다.';
    if (/구조를 확인하지 못했습니다|식별자를 확인하지 못했습니다/.test(m)) return '조치: 사이트 화면 구조가 달라졌을 수 있습니다. 0건 성공으로 처리하지 않았고 기존 공고는 보존됩니다. 반복되면 사이트 원문에서 직접 확인해주세요.';
    if (/상한을 넘었습니다/.test(m)) return '조치: 응답이 너무 커서 중단했습니다. 검색어를 더 좁혀 다시 수집하세요.';
    if (/허용한 사이트 공개 주소가 아닙니다/.test(m)) return '조치: 로그인 필요 페이지로 이동하려 해 중단했습니다. 로그인 전용 자료는 자동 수집하지 않습니다.';
    if (/fetch failed|timeout|abort|ENOTFOUND|ECONN/i.test(m)) return '조치: 네트워크 연결을 확인하고 다시 수집하세요. 기존 공고는 보존됩니다.';
    return run.status === 'partial' ? '조치: 일부 공고의 상세 확인이 실패했습니다. 해당 공고는 이전 본문을 보존하며 다음 수집에서 다시 확인합니다.' : '조치: 같은 메시지가 반복되면 사이트 원문에서 직접 확인해주세요. 기존 공고는 보존됩니다.';
  }
  // 진행률은 현재 단계의 실제 처리 건수/페이지 수다. 경과시간이나 추정 전체 건수는 쓰지 않는다.
  function collectionProgress(snapshot,tracked=null){
    const active=snapshot.active,batch=snapshot.batch,batchBusy=snapshot.batchActive===true;
    if(active||batchBusy){
      const task={kind:batchBusy?'batch':'single',id:batchBusy?batch?.id:active.id};
      const totalSites=batchBusy?batch?.sites?.length||0:0,doneSites=Math.min(batch?.results?.length||0,totalSites),site=active?.site||batch?.currentSite;
      const name=snapshot.schema?.sites?.find(s=>s.id===site)?.name||site||'';
      const siteCount=totalSites?(active?Math.min(doneSites+1,totalSites)+'/'+totalSites+'사이트':doneSites+'/'+totalSites+'사이트 처리'):'';
      if(active?.status==='stopping'||batch?.status==='stopping'&&batchBusy)return {visible:true,busy:true,task,status:'stopping',label:'중지 확인 중',percent:null,indeterminate:true,note:[name,siteCount,'현재 작업 종료 대기'].filter(Boolean).join(' · ')};
      const detail=active?.progress,phase=detail?.phase,known=['list','detail'].includes(phase)&&Number.isSafeInteger(detail.total)&&detail.total>0&&Number.isSafeInteger(detail.completed)&&detail.completed>=0;
      const count=known?Math.min(detail.completed,detail.total):0,percent=known?Math.floor(count/detail.total*100):null;
      const label=phase==='saving'?'결과 저장 중':phase==='detail'?'상세 확인':phase==='list'?'목록 확인 중':phase==='prepare'?'수집 준비 중':active?'수집 중':'다음 사이트 준비 중';
      const note=known?[name,count+'/'+detail.total+(phase==='list'?'페이지':'건')+' 처리',siteCount].filter(Boolean).join(' · '):[active?.message||name,siteCount].filter(Boolean).join(' · ');
      return {visible:true,busy:true,task,status:'running',label,percent,indeterminate:!known,note};
    }
    if(snapshot.pendingCollection)return {visible:true,busy:true,task:null,status:'running',label:'수집 준비 중',percent:null,indeterminate:true,note:'요청을 보내고 있습니다.'};
    const result=tracked?.kind==='batch'&&batch?.id===tracked.id?batch:tracked?.kind==='single'?snapshot.runs?.find(r=>r.id===tracked.id):null;
    if(!result)return {visible:false,task:null};
    const completed=result.status==='completed',status=completed?'completed':['partial','failed','stopped','interrupted'].includes(result.status)?result.status:'failed';
    const label={completed:'수집 완료',partial:'일부 확인 필요',failed:'수집 실패',stopped:'수집 중지됨',interrupted:'수집 중단됨'}[status];
    return {visible:true,busy:false,task:tracked,status,label,percent:completed?100:null,indeterminate:false,note:result.message||''};
  }
  globalThis.JobsCore = Object.freeze({defaults,safeUrl,saraminQuery,jasoseolQuery,nativeQuery,nativeParams,jssDuties,jssLeafIds,siteKeywordOf,saraminCompanyCodes,sarCompanyTypes:sarLabels.company_type,normalizeSettings,state,matches,select,sortRecords,paginate,summary,recoveryHint,collectionProgress});
})();
