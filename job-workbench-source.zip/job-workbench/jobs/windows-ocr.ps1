param([Parameter(Mandatory=$true)][string]$ImagePath)
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
Add-Type -AssemblyName System.Runtime.WindowsRuntime
Add-Type -AssemblyName System.Drawing
$null=[Windows.Storage.StorageFile,Windows.Storage,ContentType=WindowsRuntime]
$null=[Windows.Graphics.Imaging.BitmapDecoder,Windows.Graphics.Imaging,ContentType=WindowsRuntime]
$null=[Windows.Media.Ocr.OcrEngine,Windows.Foundation,ContentType=WindowsRuntime]
$null=[Windows.Globalization.Language,Windows.Globalization,ContentType=WindowsRuntime]
$asTask=[System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {$_.Name -eq 'AsTask' -and $_.IsGenericMethod -and $_.GetParameters().Count -eq 1} | Select-Object -First 1
function Await($Operation,[Type]$ResultType){$task=$asTask.MakeGenericMethod($ResultType).Invoke($null,@($Operation));$task.GetAwaiter().GetResult()}
# Transparent posters must be composited onto white before OCR; otherwise black
# qualification text on transparent pixels can disappear against a black background.
$whitePath=Join-Path ([IO.Path]::GetTempPath()) ([Guid]::NewGuid().ToString()+'.png')
$decodedPath=$null
try {$drawing=[Drawing.Image]::FromFile($ImagePath)}catch {
  $original=Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($ImagePath)) ([Windows.Storage.StorageFile])
  $originalStream=Await ($original.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
  try {
    $originalDecoder=Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($originalStream)) ([Windows.Graphics.Imaging.BitmapDecoder])
    if([long]$originalDecoder.PixelWidth*$originalDecoder.PixelHeight -gt 160000000 -or $originalDecoder.PixelHeight -gt 120000){throw '이미지 크기 상한 초과'}
    $originalBitmap=Await ($originalDecoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
    $decodedPath=Join-Path ([IO.Path]::GetTempPath()) ([Guid]::NewGuid().ToString()+'.png')
    $null=[IO.File]::WriteAllBytes($decodedPath,[byte[]]@())
    $decodedFile=Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($decodedPath)) ([Windows.Storage.StorageFile])
    $decodedStream=Await ($decodedFile.OpenAsync([Windows.Storage.FileAccessMode]::ReadWrite)) ([Windows.Storage.Streams.IRandomAccessStream])
    try {$encoder=Await ([Windows.Graphics.Imaging.BitmapEncoder]::CreateAsync([Windows.Graphics.Imaging.BitmapEncoder]::PngEncoderId,$decodedStream)) ([Windows.Graphics.Imaging.BitmapEncoder]);$encoder.SetSoftwareBitmap($originalBitmap);$op=$encoder.FlushAsync();$actionMethod=[System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {$_.Name -eq 'AsTask' -and -not $_.IsGenericMethod -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncAction'} | Select-Object -First 1;$actionTask=$actionMethod.Invoke($null,@($op));$null=$actionTask.GetAwaiter().GetResult()}finally{$decodedStream.Dispose();$originalBitmap.Dispose()}
  }finally{$originalStream.Dispose()}
  $drawing=[Drawing.Image]::FromFile($decodedPath)
}
try {
  if([long]$drawing.Width*$drawing.Height -gt 160000000 -or $drawing.Height -gt 120000){throw '이미지 크기 상한 초과'}
  $canvas=[Drawing.Bitmap]::new($drawing.Width,$drawing.Height,[Drawing.Imaging.PixelFormat]::Format24bppRgb)
  $graphics=[Drawing.Graphics]::FromImage($canvas)
  try {$graphics.Clear([Drawing.Color]::White);$graphics.DrawImage($drawing,0,0,$drawing.Width,$drawing.Height);$canvas.Save($whitePath,[Drawing.Imaging.ImageFormat]::Png)}finally{$graphics.Dispose();$canvas.Dispose()}
}finally{$drawing.Dispose();if($decodedPath){[IO.File]::Delete($decodedPath)}}
$file=Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($whitePath)) ([Windows.Storage.StorageFile])
$stream=Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
try {
  $decoder=Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
  $engine=[Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage([Windows.Globalization.Language]::new('ko'))
  if(-not $engine){throw 'Windows 한국어 OCR 언어가 설치되어 있지 않습니다.'}
  $width=[int]$decoder.PixelWidth;$height=[int]$decoder.PixelHeight
  if($width -lt 180 -or $height -lt 70){@{status='skipped';text='';width=$width;height=$height} | ConvertTo-Json -Compress;exit}
  if([long]$width*$height -gt 160000000 -or $height -gt 120000){throw '이미지 크기 상한 초과'}
  $lines=[Collections.Generic.List[string]]::new()
  foreach($ocrScale in @(1.0,2.0)){
  $scale=[Math]::Min($ocrScale,2400.0/$width);$sw=[uint32]($width*$scale);$sh=[uint32]($height*$scale)
  $regions=@(@{X=0;Width=$sw});if($width -ge 600 -and $ocrScale -gt 1){$cw=[uint32][Math]::Ceiling($sw*0.60);$regions+=@{X=0;Width=$cw};$regions+=@{X=($sw-$cw);Width=$cw}}
  foreach($region in $regions){
  for($y=0;$y -lt $sh;$y+=2100){
    $transform=[Windows.Graphics.Imaging.BitmapTransform]::new();$transform.ScaledWidth=$sw;$transform.ScaledHeight=$sh
    $bounds=[Windows.Graphics.Imaging.BitmapBounds]::new();$bounds.X=[uint32]$region.X;$bounds.Y=[uint32]$y;$bounds.Width=[uint32]$region.Width;$bounds.Height=[uint32][Math]::Min(2200,$sh-$y);$transform.Bounds=$bounds
    $bitmap=Await ($decoder.GetSoftwareBitmapAsync([Windows.Graphics.Imaging.BitmapPixelFormat]::Bgra8,[Windows.Graphics.Imaging.BitmapAlphaMode]::Premultiplied,$transform,[Windows.Graphics.Imaging.ExifOrientationMode]::IgnoreExifOrientation,[Windows.Graphics.Imaging.ColorManagementMode]::DoNotColorManage)) ([Windows.Graphics.Imaging.SoftwareBitmap])
    try {$result=Await ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult]);foreach($line in $result.Lines){$lines.Add($line.Text)}}finally{$bitmap.Dispose()}
  }
  }
  }
  @{status='success';method='white-background + original/2x upscale + overlapping full/column tiles';text=(($lines | Select-Object -Unique) -join "`n");width=$width;height=$height} | ConvertTo-Json -Compress -Depth 4
} finally {$stream.Dispose();[IO.File]::Delete($whitePath)}
