@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0jobs\start-jobs.ps1" -Open
if errorlevel 1 pause
