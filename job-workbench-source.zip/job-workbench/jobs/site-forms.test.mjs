// 사이트 검색 양식(nativeQuery): 사이트별로 아는 조건 이름만 받고, 그 조건 그대로 요청하고, 그 조건으로 확인된 공고만 남는지 확인한다.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {sitePlan,readJobkoreaList} from './public-sites.mjs';
import {searchPlan} from './saramin.mjs';
import './core.js';
const C=globalThis.JobsCore;

test('사이트마다 아는 조건 이름만 받고 모르는 이름·형식은 오류로 알린다',()=>{
  assert.equal(C.nativeQuery('catch',''),null);
  const q=C.nativeQuery('catch','Size=1,3&Career=1&Sido=%EC%84%9C%EC%9A%B8');assert.equal(q.ok,true);assert.equal(q.params.Sido,'서울');assert.equal(q.key,'Career=1&Sido=서울&Size=1,3');
  assert.equal(C.nativeQuery('catch','Bad=1').ok,false);assert.equal(C.nativeQuery('jobkorea','duty=1;drop').ok,false);assert.equal(C.nativeQuery('unknown','a=1').ok,false);
  assert.equal(C.nativeQuery('saramin','searchword='+encodeURIComponent('화학 공학')).params.searchword,'화학 공학');
});

test('양식 조건 그대로 요청한다: 캐치 목록 API·자소설닷컴 검색·잡코리아 상세검색·사람인 검색',()=>{
  const c=sitePlan('catch',{enabled:true,keyword:'무시',nativeQuery:'Career=1&Size=1,3&JobCode=0401'}),cu=new URL(c.url).searchParams;
  assert.equal(cu.get('Career'),'1');assert.equal(cu.get('Size'),'1,3');assert.equal(cu.get('JobCode'),'0401');assert.equal(cu.get('Keyword'),null,'공통 검색어는 쓰지 않는다');assert.equal(cu.get('onRecruitYN'),'Y');assert.deepEqual(c.local,[]);assert.equal(c.limits.maxItems,100);
  const j=sitePlan('jasoseol',{enabled:true,nativeQuery:'division=1,3&dutyGroupIds=187&excludeClosed=true'});assert.equal(new URL(j.url).searchParams.get('dutyGroupIds'),'187');assert.equal(j.remoteKey,'division=1,3&dutyGroupIds=187&excludeClosed=true');
  const k=sitePlan('jobkorea',{enabled:true,nativeQuery:'duty=1000338&career=1'});assert.equal(new URL(k.url).pathname,'/Recruit/Home/_GI_List/');assert.deepEqual(k.params,{duty:'1000338',career:'1'});
  const s=searchPlan({enabled:true,keyword:'무시',companyType:'대기업',nativeQuery:'searchword=%ED%99%94%ED%95%99&exp_cd=1&edu_min=8&edu_max=11&loc_mcd=101000'}),su=new URL(s.url).searchParams;
  assert.equal(su.get('searchword'),'화학');assert.equal(su.get('loc_mcd'),'101000');assert.equal(su.get('company_type'),null,'공통 기업형태는 쓰지 않는다');assert.deepEqual(s.local,[]);
  assert.throws(()=>sitePlan('catch',{enabled:false,nativeQuery:'Career=1'}),/사용/);assert.throws(()=>sitePlan('jobkorea',{enabled:true,nativeQuery:'x=1'}),/읽지 못했습니다/);
});

test('양식 조건이 있으면 그 조건으로 사이트가 돌려준 공고만 남기고 문구로 다시 거르지 않는다',()=>{
  const site={id:'catch',fields:['roles','locations','career','employment','companyType']},filter={enabled:true,includeUnknown:false,keyword:'화학공학',career:'경력',locations:'부산',nativeQuery:'Career=1&Size=1,3'};
  const record={company:'회사',title:'생산',roles:['미확인'],locations:['서울'],career:['신입'],employment:[],education:'',industry:'',companyType:'미확인',sources:[{site:'캐치'}]},key=C.nativeQuery('catch',filter.nativeQuery).key;
  assert.equal(C.matches({...record,remoteMatches:[{key}]},filter,site),true,'공통 검색어·지역·경력과 달라도 사이트 결과면 남긴다');
  assert.equal(C.matches(record,filter,site),false,'이 조건으로 확인되지 않은 공고는 숨긴다');
  assert.equal(C.matches({...record,remoteMatches:[{key:'Career=2'}]},filter,site),false);
  assert.equal(C.matches({...record,remoteMatches:[{key}]},{...filter,exclude:'회사'},site),false,'제외 검색어만 적용한다');
});

test('잡코리아 상세검색 결과 표에서 공고·전체 건수·등록/마감일을 읽고 구조가 다르면 0건으로 처리하지 않는다',()=>{
  const row='<tr class="devloopArea" data-gno="501"><td class="tplCo"><a href="/x">㈜회사</a></td><td class="tplTit"><a href="/Recruit/GI_Read/501" title="생산 신입">생산 신입</a><button data-brazeinfo="생산 신입|501|9|2026-10-28|2026-12-27|㈜회사|1"></button><p class="etc"><span class="cell">신입</span><span class="cell">고졸↑</span><span class="cell">경기 안양시</span><span class="cell">정규직</span></p><p class="dsc">설비, 설치</p></td></tr>';
  const r=readJobkoreaList('<span data-text="전체">전체 <em>(3,346건)</em></span><table>'+row+'</table>');
  assert.equal(r.total,3346);assert.equal(r.rows[0].id,'501');assert.equal(r.rows[0].company,'㈜회사');assert.deepEqual(r.rows[0].career,['신입']);assert.equal(r.rows[0].deadline,'2026-12-27T23:59:59+09:00');assert.equal(r.rows[0].startAt,'2026-10-28T00:00:00+09:00');assert.deepEqual(r.rows[0].roles,['설비','설치']);
  assert.throws(()=>readJobkoreaList('<html>점검 중</html>'),/0건으로 처리하지 않았습니다/);
});

test('저장된 사이트 양식 표는 네 사이트 모두 있고 선택지 코드가 비어 있지 않다',async()=>{
  for(const site of ['saramin','catch','jasoseol','jobkorea']){
    const t=JSON.parse(await fs.readFile(new URL('./site-tables/'+site+'.json',import.meta.url),'utf8'));assert.equal(t.site,site);assert.ok(t.groups.length>=4,site);
    const params=new Set(),walk=o=>{for(const x of o){assert.ok(x.code&&x.label,site+' 빈 코드');params.add(x.param);if(x.children)walk(x.children);}};for(const g of t.groups)if(g.options)walk(g.options);
    for(const p of params)if(p!=='edu')assert.ok(C.nativeParams[site].includes(p),site+' 표의 조건 이름 '+p+'는 요청에 허용되어야 함');
  }
});
