﻿param([switch]$Open)
$ErrorActionPreference='Stop'
try { [Console]::OutputEncoding=New-Object Text.UTF8Encoding($false) } catch {}
$projectRoot=Split-Path -Parent $PSScriptRoot
$runtime=Join-Path $projectRoot '.runtime\jobs'
$url='http://127.0.0.1:42637'
New-Item -ItemType Directory -Path $runtime -Force | Out-Null
function Read-Health { try { Invoke-RestMethod -Uri ($url+'/api/health') -TimeoutSec 2 } catch { $null } }
$health=Read-Health
if($health){
  if($health.name -ne 'local-job-desk' -or [IO.Path]::GetFullPath($health.root) -ne [IO.Path]::GetFullPath($projectRoot)){throw '이 주소에서 다른 프로그램이 실행 중입니다. 기존 프로그램을 종료하지 않았습니다.'}
  $codeBytes=New-Object IO.MemoryStream
  try{
    foreach($sourceName in @('server.mjs','saramin.mjs','public-sites.mjs','requirements.mjs','detail-body.mjs','browser.mjs','image-ocr.mjs','windows-ocr.ps1','dashboard.js','dashboard.html','dashboard.css','core.js','ui-fonts.js')){
      $bytes=[IO.File]::ReadAllBytes((Join-Path $PSScriptRoot $sourceName));$codeBytes.Write($bytes,0,$bytes.Length)
    }
    $algorithm=[Security.Cryptography.SHA256]::Create()
    try{$expectedBuild=([BitConverter]::ToString($algorithm.ComputeHash($codeBytes.ToArray()))).Replace('-','').ToLowerInvariant()}finally{$algorithm.Dispose()}
  }finally{$codeBytes.Dispose()}
  if($health.buildId -ne $expectedBuild){
    $currentState=Invoke-RestMethod -Uri ($url+'/api/state') -TimeoutSec 5
    if($currentState.active -or $currentState.batchActive){
      $notice='코드가 갱신되었지만 수집 중이므로 현재 화면을 엽니다. 수집 완료 후 바로가기를 다시 실행하면 새 버전으로 시작합니다.'
      Write-Warning $notice
      $notice | Set-Content -LiteralPath (Join-Path $runtime 'launcher-notice.log') -Encoding utf8
    }else{
      # 같은 프로젝트의 유휴 서버만 정상 종료한다. 수집 중 강제 종료하지 않는다.
      & (Join-Path $PSScriptRoot 'stop-jobs.ps1')
      $health=Read-Health
      if($health){throw '이전 서버의 종료를 확인하지 못했습니다. 잠시 후 다시 실행해주세요.'}
    }
  }
}
if(-not $health){
  $nodeCommand=Get-Command node.exe -ErrorAction SilentlyContinue
  $nodeCandidates=@(
    $env:JOB_DESK_NODE_EXE
    $(if($nodeCommand){$nodeCommand.Source})
    (Join-Path $PSScriptRoot 'runtime\node.exe')
    (Join-Path $env:ProgramFiles 'nodejs\node.exe')
    (Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe')
  )
  $nodePath=$null
  foreach($candidate in ($nodeCandidates | Where-Object {$_ -and (Test-Path -LiteralPath $_ -PathType Leaf)} | Select-Object -Unique)){
    $nodeVersion=& $candidate --version
    if($LASTEXITCODE -eq 0 -and $nodeVersion -match '^v(\d+)\.' -and [int]$Matches[1] -ge 22){$nodePath=$candidate;break}
  }
  if(-not $nodePath){throw 'Node.js 22 이상이 필요합니다. 설치 후 다시 실행하거나 JOB_DESK_NODE_EXE에 실행 파일 경로를 지정해주세요.'}
  $serverFile=Join-Path $PSScriptRoot 'server.mjs'
  $process=Start-Process -FilePath $nodePath -ArgumentList ('"'+$serverFile+'"') -WorkingDirectory $projectRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $runtime 'server-stdout.log') -RedirectStandardError (Join-Path $runtime 'server-stderr.log') -PassThru
  for($attempt=0;$attempt -lt 30;$attempt++){Start-Sleep -Milliseconds 200;$health=Read-Health;if($health){break};if($process.HasExited){throw '실행이 끝났습니다. .runtime/jobs/server-stderr.log를 확인해주세요.'}}
  if(-not $health -or $health.name -ne 'local-job-desk' -or [IO.Path]::GetFullPath($health.root) -ne [IO.Path]::GetFullPath($projectRoot)){throw '프로그램 준비 상태를 확인하지 못했습니다. 기존 공고와 설정은 변경하지 않았습니다.'}
  @{pid=$process.Id;url=$url;root=$projectRoot;startedAt=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $runtime 'server.json') -Encoding utf8
}
if($Open){Start-Process $url}
Write-Output ('준비됨: '+$url)
