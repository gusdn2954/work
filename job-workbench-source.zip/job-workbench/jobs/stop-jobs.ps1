﻿$ErrorActionPreference='Stop'
try { [Console]::OutputEncoding=New-Object Text.UTF8Encoding($false) } catch {}
$projectRoot=Split-Path -Parent $PSScriptRoot
$url='http://127.0.0.1:42637'
function Read-Health { try { Invoke-RestMethod -Uri ($url+'/api/health') -TimeoutSec 2 } catch { $null } }
$health=Read-Health
if(-not $health){Write-Output '종료할 서버의 응답이 없습니다. 다른 프로세스를 종료하지 않았습니다.';return}
if($health.name -ne 'local-job-desk' -or [IO.Path]::GetFullPath($health.root) -ne [IO.Path]::GetFullPath($projectRoot)){throw '다른 프로젝트가 실행 중입니다. 종료 요청을 보내지 않았습니다.'}
$serverProcessId=$health.pid
if(-not $serverProcessId -or $serverProcessId -le 0){throw '종료 확인에 필요한 서버 프로세스 정보를 받지 못했습니다. 종료하지 않았습니다.'}
$state=Invoke-RestMethod -Uri ($url+'/api/state') -TimeoutSec 5
Invoke-RestMethod -Uri ($url+'/api/shutdown') -Method Post -ContentType 'application/json' -Headers @{'X-Job-Desk-Project'=$state.projectId} -Body '{}' -TimeoutSec 5 | Out-Null
Write-Output '종료 요청을 보냈습니다. 실행 중인 수집과 저장이 끝나기를 기다립니다.'
for($attempt=0;$attempt -lt 40;$attempt++){
  Start-Sleep -Milliseconds 250
  $current=Read-Health
  if(-not (Get-Process -Id $serverProcessId -ErrorAction SilentlyContinue)){Write-Output '종료를 확인했습니다.';return}
}
throw '종료 확인이 지연되고 있습니다. 다른 프로세스를 강제로 종료하지 않았습니다.'
