import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import './core.js';

const C=globalThis.JobsCore;
const data=JSON.parse(await fs.readFile(new URL('./fixtures/public-sample.json',import.meta.url),'utf8'));
const schema=JSON.parse(await fs.readFile(new URL('./settings-schema.json',import.meta.url),'utf8'));
const now=Date.parse('2026-10-26T06:00:00+09:00');

test('네 사이트 10개 게시물은 중복 정리 후 8건, 진행 7건·마감 1건이다',()=>{
  assert.deepEqual(C.summary(data.records,now),{unique:8,postings:10,open:7,closed:1,urgent:3,bySite:{'캐치':4,'자소설닷컴':3,'사람인':1,'잡코리아':2}});
  assert.equal(new Set(data.records.map(r=>r.id)).size,8);
  const bgf=data.records.find(r=>r.id==='bgf-2026-q4');
  assert.deepEqual(bgf.sources.filter(s=>!s.official).map(s=>s.site),['캐치','자소설닷컴','잡코리아']);
});

test('개인 자격은 보류이고 모든 공고에 조건·절차·서류·근거가 남는다',async()=>{
  for(const record of data.records){
    assert.equal(record.eligibility.status,'보류');
    for(const key of ['roles','locations','career','employment','required','preferred','stages','documents','prep','sources'])assert.ok(record[key]?.length,record.id+': '+key);
    for(const source of record.sources){
      assert.ok(C.safeUrl(source.url));assert.ok(Number.isFinite(Date.parse(source.checkedAt)));
      const evidence=JSON.parse(await fs.readFile(new URL('../'+source.evidenceFile,import.meta.url),'utf8'));
      assert.equal(evidence.requestedUrl,source.url);assert.equal(evidence.status,200);assert.equal(evidence.checkedAt,source.checkedAt);
    }
  }
  assert.deepEqual(data.profile.confirmed,[]);
});

test('시간대가 명시된 자소설 원본 마감일을 사용한다',async()=>{
  for(const r of data.records){
    const source=r.sources.find(s=>s.site==='자소설닷컴');if(!source)continue;
    const html=await fs.readFile(new URL('../'+source.evidenceFile.replace(/\.json$/,'.html'),import.meta.url),'utf8');
    const next=JSON.parse(html.match(/<script[^>]+id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/)[1]);
    assert.equal(Date.parse(next.props.pageProps.initialEmploymentCompany.end_time),Date.parse(r.deadline.at));
  }
});

test('마감시각 경계·7일 경계·확인된 마감과 미확인을 구분한다',()=>{
  const r={deadline:{at:'2026-11-02T06:00:00+09:00'}};
  assert.equal(C.state(r,now),'urgent');assert.equal(C.state(r,now-1),'open');
  assert.equal(C.state(r,Date.parse(r.deadline.at)),'closed');
  assert.equal(C.state({deadline:{at:null}},now),'unknown');
  assert.equal(C.state({...r,observedClosed:true},now),'closed');
});

test('사이트 조건은 독립적이고 전체에서는 출처 중 하나가 통과하면 보존한다',()=>{
  const settings=C.defaults(schema);settings.sites.catch.keyword='GS글로벌';
  assert.deepEqual(C.select(data.records,settings,schema,{site:'catch',now}).map(r=>r.company),['GS글로벌']);
  assert.equal(C.select(data.records,settings,schema,{site:'jasoseol',now}).length,3);
  assert.ok(C.select(data.records,settings,schema,{now}).some(r=>r.company==='BGF로지스'));
  settings.sites.jasoseol.enabled=false;settings.sites.jobkorea.enabled=false;
  assert.ok(!C.select(data.records,settings,schema,{now}).some(r=>r.company==='BGF로지스'));
});

test('다중 값 OR·항목 간 AND·제외·미확인 포함 선택이 동작한다',()=>{
  // 자소설닷컴은 채용형태를 사이트 검색에 보내므로, 로컬 문구 검사는 원격 조건이 없는 잡코리아 규칙으로 확인한다.
  const settings=C.defaults(schema),filter=settings.sites.jobkorea,site=schema.sites.find(s=>s.id==='jobkorea');
  filter.employment='인턴, 정규직';filter.roles='클라우드';
  assert.equal(C.matches(data.records.find(r=>r.company==='가비아'),filter,site),true);
  filter.locations='서울';filter.includeUnknown=false;
  assert.equal(C.matches(data.records.find(r=>r.company==='가비아'),filter,site),false);
  filter.includeUnknown=true;assert.equal(C.matches(data.records.find(r=>r.company==='가비아'),filter,site),true);
  filter.exclude='가비아';assert.equal(C.matches(data.records.find(r=>r.company==='가비아'),filter,site),false);
});

test('저장 조건 내보내기·불러오기는 사이트별 메모를 보존하고 잘못된 URL을 거부한다',()=>{
  const settings=C.defaults(schema);settings.sites.saramin.nativeNotes='재택 가능, 급여 협의';settings.sites.catch.nativeUrl='https://www.catch.co.kr/NCS/RecruitSearch';
  assert.deepEqual(C.normalizeSettings(JSON.parse(JSON.stringify(settings)),schema),settings);
  for(const url of ['javascript:alert(1)','https://catch.co.kr.attacker.example/','https://user:secret@catch.co.kr/','http://catch.co.kr/','https://catch.co.kr:9999/']){
    const invalid=structuredClone(settings);invalid.sites.catch.nativeUrl=url;assert.throws(()=>C.normalizeSettings(invalid,schema));
  }
  assert.throws(()=>C.normalizeSettings({...settings,project:'다른 프로젝트'},schema));
});

test('화면 데이터와 JSON은 같고 페이지가 원문 HTML·외부 스크립트를 실행하지 않는다',async()=>{
  const embedded=await fs.readFile(new URL('./data.js',import.meta.url),'utf8');
  assert.deepEqual(JSON.parse(embedded.replace(/^globalThis.JOBS_DATA = /,'').replace(/;\s*$/,'')),JSON.parse(await fs.readFile(new URL('./data.json',import.meta.url),'utf8')));
  const html=await fs.readFile(new URL('./index.html',import.meta.url),'utf8');
  for(const src of html.matchAll(/<script[^>]+src="([^"]+)"/g))assert.ok(!/[:/]/.test(src[1]));
  const app=await fs.readFile(new URL('./app.js',import.meta.url),'utf8');
  assert.ok(!/innerHTML|document\.write|eval\(/.test(app));
  assert.ok(html.includes("connect-src 'none'"));
});
