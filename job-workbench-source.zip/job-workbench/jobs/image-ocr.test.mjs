import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import vm from 'node:vm';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {imageUrls,recognizeHtmlImages,recognizeImage} from './image-ocr.mjs';
test('image URL extraction handles lazy attributes, relative URLs, entities and deduplication',()=>{
  assert.deepEqual(imageUrls('<img src="/a.png?x=1&amp;y=2"><img data-src="/a.png?x=1&amp;y=2"><img src="data:image/png;base64,x"><img src="javascript:x">','https://www.saramin.co.kr/detail'),['https://www.saramin.co.kr/a.png?x=1&y=2']);
});
test('OCR adds separate text, reuses successful cache and records failures without hiding them',async()=>{
  const cacheDir=await fs.mkdtemp(path.join(os.tmpdir(),'job-ocr-test-'));let calls=0;
  try{
    const args={html:'<img src="/body.png">',base:'https://www.saramin.co.kr/',cacheDir,fetchImage:async()=>Buffer.from('fixture'),recognizer:async()=>{calls++;return {status:'success',text:'화학/화학공학과',width:800,height:3000};}};
    const result=await recognizeHtmlImages(args);assert.equal(result.text,'화학/화학공학과');assert.equal(result.needsReview,false);
    await recognizeHtmlImages(args);assert.equal(calls,1);
    const imageFile=(await fs.readdir(cacheDir)).find(name=>name.endsWith('.image')),expired=new Date(Date.now()-13*60*60*1000);await fs.utimes(path.join(cacheDir,imageFile),expired,expired);await recognizeHtmlImages(args);assert.equal(calls,2);
    const failure=await recognizeHtmlImages({...args,html:'<img src="/unavailable.png">',fetchImage:async()=>{throw new Error('HTTP 403');}});
    assert.equal(failure.status,'partial');assert.equal(failure.needsReview,true);assert.match(failure.images[0].error,/403/);
  }finally{await fs.rm(cacheDir,{recursive:true,force:true});}
});
test('unsupported image hosts are reported without fetching them',async()=>{
  const cacheDir=await fs.mkdtemp(path.join(os.tmpdir(),'job-ocr-host-test-'));
  try{const result=await recognizeHtmlImages({html:'<img src="https://127.0.0.1/private.png">',base:'https://www.saramin.co.kr/',cacheDir});assert.equal(result.needsReview,true);assert.match(result.images[0].error,/허용 범위/);}finally{await fs.rm(cacheDir,{recursive:true,force:true});}
});
test('abort propagates instead of being recorded as an image failure',async()=>{
  const cacheDir=await fs.mkdtemp(path.join(os.tmpdir(),'job-ocr-abort-'));const controller=new AbortController();controller.abort();
  try{await assert.rejects(recognizeHtmlImages({html:'<img src="/a.png">',base:'https://www.saramin.co.kr/',cacheDir,signal:controller.signal}),{name:'AbortError'});}finally{await fs.rm(cacheDir,{recursive:true,force:true});}
});
test('image-only chemical engineering and shared major lists enter the major filter',async()=>{
  const source=await fs.readFile(new URL('./dashboard.js',import.meta.url),'utf8'),context=vm.createContext({});
  vm.runInContext(source.slice(source.indexOf('  const MAJOR_GROUPS='),source.indexOf('  function deadlineText(')),context);
  assert.equal(vm.runInContext("majorTag({title:'생산기술팀',detailText:''}).tag",context),'unknown');
  assert.equal(vm.runInContext("majorTag({title:'생산기술팀',imageOcr:{text:'화학공학과 전공자'}}).tag",context),'strong');
  assert.equal(vm.runInContext("majorTag({title:'생산기술팀',imageOcr:{text:'화학/신소재/재료 공학자'}}).tag",context),'chem');
  assert.equal(vm.runInContext("majorTag({title:'생산기술팀',imageOcr:{text:'기계공학 전공'}}).tag",context),'other');
  assert.equal(vm.runInContext("majorTag({imageOcr:{text:'전공: 분석화학, 유기화학 등 이공계 전공자'}}).tag",context),'chem');
  assert.equal(vm.runInContext("majorTag({imageOcr:{text:'약학, 화학, 생명공학 등 관련 전공자'}}).tag",context),'chem');
  assert.equal(vm.runInContext("majorTag({detailText:'회사 소개: 화학 사업을 수행합니다.'}).tag",context),'unknown');
});
test('image redirects follow approved hosts and reject private destinations',async()=>{
  const cacheDir=await fs.mkdtemp(path.join(os.tmpdir(),'job-ocr-redirect-')),original=globalThis.fetch,requests=[];
  try{
    globalThis.fetch=async url=>{requests.push(url);return url.endsWith('/redirect.png')?new Response(null,{status:302,headers:{location:'https://g.ifh.cc/actual.png'}}):new Response('fixture',{headers:{'content-type':'image/png'}});};
    const result=await recognizeHtmlImages({html:'<img src="https://ifh.cc/redirect.png">',base:'https://www.saramin.co.kr/',cacheDir,recognizer:async()=>({status:'success',text:'화학공학'})});
    assert.equal(result.status,'success');assert.equal(requests.length,2);
    globalThis.fetch=async url=>{requests.push(url);return new Response(null,{status:302,headers:{location:'https://127.0.0.1/private.png'}});};
    const blocked=await recognizeHtmlImages({html:'<img src="https://ifh.cc/private-redirect.png">',base:'https://www.saramin.co.kr/',cacheDir});assert.equal(blocked.needsReview,true);assert.equal(requests.length,3);assert.match(blocked.images[0].error,/허용 범위/);
  }finally{globalThis.fetch=original;await fs.rm(cacheDir,{recursive:true,force:true});}
});
test('real Windows OCR reads black major text on a transparent PNG', {skip:process.platform!=='win32',timeout:120000},async t=>{
  const dir=await fs.mkdtemp(path.join(os.tmpdir(),'job-ocr-alpha-')),file=path.join(dir,'transparent.png');
  const escaped=file.replaceAll("'","''");
  try{
    await promisify(execFile)('powershell.exe',['-NoProfile','-NonInteractive','-Command',`Add-Type -AssemblyName System.Drawing;$b=[Drawing.Bitmap]::new(800,250,[Drawing.Imaging.PixelFormat]::Format32bppArgb);$g=[Drawing.Graphics]::FromImage($b);$f=[Drawing.Font]::new('Malgun Gothic',36);try{$g.Clear([Drawing.Color]::Transparent);$g.DrawString('화학공학',$f,[Drawing.Brushes]::Black,40,40);$b.Save('${escaped}',[Drawing.Imaging.ImageFormat]::Png)}finally{$f.Dispose();$g.Dispose();$b.Dispose()}`],{windowsHide:true});
    let result;try{result=await recognizeImage(file);}catch(e){if(/OCR 언어가 설치/.test(e.message)){t.skip(e.message);return;}throw e;}
    assert.match(result.text.replace(/\s/g,''),/화학공학/);assert.match(result.method,/white-background/);
  }finally{await fs.rm(dir,{recursive:true,force:true});}
});
test('OCR execution success with uncertain text remains marked for review',async()=>{
  const cacheDir=await fs.mkdtemp(path.join(os.tmpdir(),'job-ocr-uncertain-'));
  try{const result=await recognizeHtmlImages({html:'<img src="/uncertain.png">',base:'https://www.saramin.co.kr/',cacheDir,fetchImage:async()=>Buffer.from('fixture'),recognizer:async()=>({status:'success',text:'회학',needsReview:true,multiscaleChecked:true})});assert.equal(result.status,'partial');assert.equal(result.needsReview,true);assert.equal(result.text,'회학');}finally{await fs.rm(cacheDir,{recursive:true,force:true});}
});
